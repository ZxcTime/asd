"""
Конвертер старого конфигуратора From_Los_Santos в формат инвентаря csgo_gc.

Исходные данные:
    C:\\Users\\User\\Desktop\\From_Los_Santos\\app\\selection.json   -- что выбрал пользователь
    C:\\Users\\User\\Desktop\\From_Los_Santos\\app\\catalog.json     -- справочник (категории, ножи, наклейки)

Результат:
    csgo_gc/inventory.txt (и, если найден, дубль в csgo_gc_release/csgo_gc/inventory.txt)

Формат inventory.txt -- это KeyValues 1 (как items_game.txt). Важные особенности:
  * все значения -- СТРОКИ в кавычках, даже числа;
  * ключи верхнего уровня: "items" и "default_equips";
  * ключ каждого предмета в "items" -- его уникальный item id (можно просто 2, 3, 4...),
    а поле "inventory" -- номер страницы инвентаря (в примере из csgo_gc это "1");
  * атрибут 6 = paint kit, 7 = seed, 8 = wear, 80 = StatTrak kill count;
  * equipped_state: ключ -- class_id (2 = террористы, 3 = контртеррористы),
    значение -- slot_id из items_game.txt -> player_loadout_slots.

Запуск:
    python gc_inventory.py
(в этой системе может понадобиться `py -3 gc_inventory.py`, т.к. `python` -- заглушка Store).

Модуль можно использовать и как библиотеку:
    from gc_inventory import build_inventory
    text = build_inventory(selection_dict, catalog_dict)
"""

from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Пути (всё относительно папки со скриптом, плюс явные пути старого проекта)
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
ROOT_DIR = BASE_DIR.parent
SELECTION_PATH = BASE_DIR / "selection.json"
CATALOG_PATH = BASE_DIR / "catalog.json"

# Основной выходной файл: <корень проекта>/csgo_gc/inventory.txt
OUTPUT_PATH = ROOT_DIR / "csgo_gc" / "inventory.txt"
# Распространённая раскладка архива csgo_gc_release: обновляем и его тоже,
# чтобы не приходилось копировать файл руками. Комментарий в main() поясняет.
RELEASE_OUTPUT_PATH = ROOT_DIR / "csgo_gc_release" / "csgo_gc" / "inventory.txt"
MIRROR_TO_RELEASE = True


# ---------------------------------------------------------------------------
# Слоты экипировки.
#
# ВзятоИЗ items_game.txt (CS:GO legacy), блок "player_loadout_slots":
#   0  = LOADOUT_POSITION_MELEE      (нож)
#   2  = LOADOUT_POSITION_SECONDARY0 (первый пистолет)  <-- пример из csgo_gc
#   8  = LOADOUT_POSITION_SMG0       (ПП)
#   14 = LOADOUT_POSITION_RIFLE0     (основная винтовка / снайперская)
#   20 = LOADOUT_POSITION_HEAVY0     (тяжёлое оружие)
#   44 = LOADOUT_POSITION_MISC0      (перчатки: в схеме у них нет отдельного
#                                     item_slot, поэтому это ближайший слот;
#                                     при необходимости поменяйте число ниже)
#
# Замечение: в сети встречается утверждение "слот 6 = пистолет". В реальной
# схеме 6 -- это LOADOUT_POSITION_SECONDARY4 (пятый пистолетный слот), а в
# эталонном inventory.txt из csgo_gc пистолет (def_index 61) использует слот 2.
# Поэтому по умолчанию берем 2. Если ваша сборка требует 6 -- просто поменяйте
# SLOT_BY_CATEGORY или добавьте исключение в SLOT_OVERRIDES.
# ---------------------------------------------------------------------------
SLOT_MELEE = 0
SLOT_SECONDARY = 2
SLOT_SMG = 8
SLOT_RIFLE = 14
SLOT_HEAVY = 20
SLOT_GLOVES = 44

# Ключи -- русские названия категорий из catalog.json.
SLOT_BY_CATEGORY: Dict[str, int] = {
    "Ножи": SLOT_MELEE,
    "Пистолеты": SLOT_SECONDARY,
    "ПП": SLOT_SMG,
    "Винтовки": SLOT_RIFLE,
    "Снайперские": SLOT_RIFLE,
    "Тяжёлые": SLOT_HEAVY,
    "Перчатки": SLOT_GLOVES,
    # "Агенты" намеренно отсутствует: надёжного slot_id для агентов в csgo_gc
    # нет, поэтому агенты добавляются как обычные предметы без equipped_state.
}

# Точечные исключения для конкретных def_index (если понадобится подкрутить):
# например, {1: 6} -- Desert Eagle в шестой пистолетный слот.
SLOT_OVERRIDES: Dict[int, int] = {}

# В какую команду экипировать предметы: 2 = T, 3 = CT.
# Нам нужны скины в ОБЕИХ командах — иначе половина матча ходит без скинов.
EQUIP_CLASSES: Tuple[int, ...] = (2, 3)
# Агентов экипировать не пытаемся по умолчанию (ограничение схемы csgo_gc).
EQUIP_AGENTS = False

# Атрибуты наклеек: по 4 ID на слот (id, износ, масштаб, поворот).
# StickerId0..4 = 113, 117, 121, 125, 129 — именно их и пишем.
# 114/115/116 — это износ/масштаб/поворот ПЕРВОЙ наклейки, а не ID второй.
STICKER_ATTR_IDS: Tuple[int, ...] = (113, 117, 121, 125, 129)

# Параметры предметов по умолчанию (совпадают с примером inventory.txt).
DEFAULT_LEVEL = 1
DEFAULT_FLAGS = 0
DEFAULT_ORIGIN = 24
DEFAULT_IN_USE = 0
DEFAULT_INVENTORY_PAGE = 1
DEFAULT_QUALITY = 5          # unique
DEFAULT_RARITY = 6           # covert -- как у ножа в примере
QUALITY_UNUSUAL = 99         # "★" (ножи/перчатки в примере)
QUALITY_STRANGE = 9          # StatTrak™
AGENT_QUALITY = 5
AGENT_RARITY = 1

# Ножи/перчатки: если в selection.json нет defidx, подставляем эти значения.
DEFAULT_KNIFE_DEFINDEX = 507
DEFAULT_GLOVE_DEFINDEX = 5030


# ---------------------------------------------------------------------------
# Мелкие утилиты
# ---------------------------------------------------------------------------
def _to_int(value: Any, default: int = 0) -> int:
    """Безопасное приведение к int (строки из JSON спокойно перевариваются)."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _fmt_float(value: Any) -> str:
    """Формат C++ std::to_string(float): ровно 6 знаков после точки.

    csgo_gc парсит атрибуты 6/7/8 как float, поэтому '0.000100' -- правильно.
    """
    return f"{float(value):.6f}"


def _fmt_uint(value: Any) -> str:
    """Целочисленный атрибут (StatTrak, ID наклейки) -- без плавающей точки."""
    return str(_to_int(value))


def _normalize_skin(raw: Any) -> Optional[Dict[str, Any]]:
    """Проверка и нормализация одной записи скина (аналог core._skin).

    Возвращает {"paint", "wear", "seed", "stat", "stickers"} или None,
    если запись пустая/некорректная (такой предмет просто пропускается).
    """
    if not isinstance(raw, dict):
        return None
    try:
        # GUI отдаёт уже нормализованный core.normalize_config() словарь,
        # где ключи называются paint/stat, а не paint_kit/stattrak.
        paint = int(raw.get("paint_kit", raw.get("paint")))
        wear = float(raw.get("wear", 0.0001))
        seed = int(raw.get("seed", 0))
    except (KeyError, TypeError, ValueError):
        return None
    # paint == 0 допускаем только для ножей (там это "обычный" нож без покрытия)
    if paint < 0 or not (0.0 <= wear <= 1.0) or not (0 <= seed <= 100000):
        return None

    stat = _to_int(raw.get("stattrak", raw.get("stat", -1)), -1)
    stickers: List[int] = []
    raw_stickers = raw.get("stickers") or []
    if isinstance(raw_stickers, (list, tuple)):
        for sticker in raw_stickers[:5]:
            stickers.append(max(0, min(100000, _to_int(sticker, 0))))

    return {"paint": paint, "wear": wear, "seed": seed,
            "stat": stat, "stickers": stickers}


def _load_json(path: Path) -> Dict[str, Any]:
    """Читает JSON с явной ошибкой, понятной пользователю."""
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"Ожидался JSON-объект в файле {path}")
    return data


def _category_maps(catalog: Dict[str, Any]) -> Tuple[Dict[int, str], Dict[int, str]]:
    """Строит def_index -> название категории и def_index -> имя предмета.

    catalog.json содержитcategories с вложенными списками {"defidx", "name"...}.
    """
    by_defindex: Dict[int, str] = {}
    names: Dict[int, str] = {}
    for category, weapons in (catalog.get("categories") or {}).items():
        if not isinstance(weapons, list):
            continue
        for weapon in weapons:
            if not isinstance(weapon, dict):
                continue
            idx = _to_int(weapon.get("defidx"), -1)
            if idx < 0:
                continue
            by_defindex[idx] = category
            names[idx] = str(weapon.get("name") or "")
    return by_defindex, names


def _slot_for(defindex: int, category: Optional[str], catalog: Dict[str, Any]) -> Optional[int]:
    """Подбирает слот экипировки по def_index/категории."""
    if defindex in SLOT_OVERRIDES:
        return SLOT_OVERRIDES[defindex]
    # Ножи из catalog.json -- всегда melee (даже если категория названа иначе).
    if defindex in {int(x) for x in (catalog.get("knife_ids") or [])}:
        return SLOT_MELEE
    if category:
        return SLOT_BY_CATEGORY.get(category)
    return None


# ---------------------------------------------------------------------------
# Генерация текста inventory.txt
# ---------------------------------------------------------------------------
def _item_block(item_id: int, defindex: int, skin: Dict[str, Any], *,
                quality: int = DEFAULT_QUALITY, rarity: int = DEFAULT_RARITY,
                slot: Optional[int] = None, with_attrs: bool = True,
                equip_classes: Iterable[int] = EQUIP_CLASSES) -> List[str]:
    """Формирует один блок предмета в формате KeyValues (список строк)."""
    lines: List[str] = []
    lines.append(f'\t"{item_id}"')
    lines.append("\t{")
    lines.append(f'\t\t"inventory"\t\t"{DEFAULT_INVENTORY_PAGE}"')
    lines.append(f'\t\t"def_index"\t\t"{defindex}"')
    lines.append(f'\t\t"level"\t\t"{DEFAULT_LEVEL}"')
    lines.append(f'\t\t"quality"\t\t"{quality}"')
    lines.append(f'\t\t"flags"\t\t"{DEFAULT_FLAGS}"')
    lines.append(f'\t\t"origin"\t\t"{DEFAULT_ORIGIN}"')
    lines.append(f'\t\t"in_use"\t\t"{DEFAULT_IN_USE}"')
    lines.append(f'\t\t"rarity"\t\t"{rarity}"')

    # --- атрибуты -----------------------------------------------------------
    if with_attrs:
        attrs: List[Tuple[int, str]] = [
            (6, _fmt_float(skin["paint"])),   # AttributeTexturePrefab  (finish)
            (7, _fmt_float(skin["seed"])),    # AttributeTextureSeed     (pattern)
            (8, _fmt_float(skin["wear"])),    # AttributeTextureWear     (float)
        ]
        # StatTrak: в старом конфиге stattrak >= 0 -- это счётчик killed.
        # В csgo_gc атрибут 80 (AttributeKillEater) хранит это число,
        # а качество принято ставить 9 (strange). Дополнительный атрибут 81
        # (тип счётчика) по ТЗ не требуется и поэтому не пишется.
        if skin.get("stat", -1) >= 0:
            attrs.append((80, _fmt_uint(skin["stat"])))
            attrs.append((81, "0"))   # KillEaterScoreType: 0 = оружие

        # Наклейки: по ТЗ -- атрибуты 113..117 под пять слотов.
        for sticker_id, attr_id in zip(skin.get("stickers") or [], STICKER_ATTR_IDS):
            if _to_int(sticker_id, 0) > 0:
                attrs.append((attr_id, _fmt_uint(sticker_id)))

        if attrs:
            lines.append('\t\t"attributes"')
            lines.append("\t\t{")
            for attr_id, value in attrs:
                lines.append(f'\t\t\t"{attr_id}"\t\t"{value}"')
            lines.append("\t\t}")

    # --- экипировка ---------------------------------------------------------
    if slot is not None:
        classes = list(dict.fromkeys(int(c) for c in equip_classes))
        if classes:
            lines.append('\t\t"equipped_state"')
            lines.append("\t\t{")
            for class_id in classes:
                lines.append(f'\t\t\t"{class_id}"\t\t"{slot}"')
            lines.append("\t\t}")

    lines.append("\t}")
    return lines


def _agent_entries(selection: Dict[str, Any]) -> List[Tuple[str, Dict[str, Any]]]:
    """Достаёт агентов и из нового вида {"agents": {"T":..., "CT":...}},
    и из старого вида {"agent": {...}} (совместимо с core.normalize_config)."""
    out: List[Tuple[str, Dict[str, Any]]] = []
    agents = selection.get("agents")
    if isinstance(agents, dict):
        for team in ("T", "CT"):
            agent = agents.get(team)
            if isinstance(agent, dict):
                out.append((team, agent))
    elif isinstance(selection.get("agent"), dict):
        agent = selection["agent"]
        team = "CT" if str(agent.get("team", "")).upper() == "CT" else "T"
        out.append((team, agent))
    return out


def build_inventory(selection: Dict[str, Any], catalog: Dict[str, Any]) -> str:
    """Собирает текст csgo_gc/inventory.txt из selection.json и catalog.json.

    :param selection: распарсенный selection.json (или уже нормализованный dict)
    :param catalog:   распарсенный catalog.json
    :return:          готовый текст файла (KeyValues, UTF-8, табуляция)
    """
    if not isinstance(selection, dict):
        raise TypeError("selection должен быть словарём (распарсенный JSON)")
    if not isinstance(catalog, dict):
        raise TypeError("catalog должен быть словарём (распарсенный JSON)")

    categories, names = _category_maps(catalog)
    lines: List[str] = ['"items"', "{"]

    item_id = 2  # в эталоне csgo_gc первый предмет имеет ключ "2"
    default_equips: List[Tuple[int, int, int]] = []  # defindex, class, slot

    def add_item(defindex: int, skin: Dict[str, Any], *,
                 quality: int = DEFAULT_QUALITY, rarity: int = DEFAULT_RARITY,
                 slot: Optional[int] = None, with_attrs: bool = True,
                 equip_classes: Iterable[int] = EQUIP_CLASSES,
                 default_equip: bool = True) -> None:
        """Добавляет предмет и (если нужно) запись в default_equips."""
        nonlocal item_id
        lines.extend(_item_block(item_id, defindex, skin, quality=quality,
                                 rarity=rarity, slot=slot, with_attrs=with_attrs,
                                 equip_classes=equip_classes))
        if default_equip and slot is not None:
            for class_id in dict.fromkeys(int(c) for c in equip_classes):
                default_equips.append((defindex, class_id, slot))
        item_id += 1

    # --- 1. Обычные оружия: ключ selection["skins"] -- это def_index ---------
    skins = selection.get("skins") or {}
    if isinstance(skins, dict):
        for key in sorted(skins, key=lambda k: _to_int(k, -1)):
            defindex = _to_int(key, -1)
            if defindex <= 0:
                continue
            skin = _normalize_skin(skins[key])
            if skin is None:
                continue
            # StatTrak меняет качество на strange (9)
            quality = QUALITY_STRANGE if skin["stat"] >= 0 else DEFAULT_QUALITY
            category = categories.get(defindex)
            slot = _slot_for(defindex, category, catalog)
            add_item(defindex, skin, quality=quality, slot=slot)

    # --- 2. Нож --------------------------------------------------------------
    knife_raw = selection.get("knife")
    knife = _normalize_skin(knife_raw) if isinstance(knife_raw, dict) else None
    if knife:
        knife_defindex = _to_int((knife_raw or {}).get("defidx"), DEFAULT_KNIFE_DEFINDEX) \
            or DEFAULT_KNIFE_DEFINDEX
        add_item(knife_defindex, knife, quality=QUALITY_UNUSUAL,
                 rarity=DEFAULT_RARITY, slot=SLOT_MELEE)

    # --- 3. Перчатки ---------------------------------------------------------
    glove_raw = selection.get("gloves")
    gloves = _normalize_skin(glove_raw) if isinstance(glove_raw, dict) else None
    if gloves:
        glove_defindex = _to_int((glove_raw or {}).get("defidx"), DEFAULT_GLOVE_DEFINDEX) \
            or DEFAULT_GLOVE_DEFINDEX
        add_item(glove_defindex, gloves, quality=QUALITY_UNUSUAL,
                 rarity=DEFAULT_RARITY, slot=SLOT_GLOVES)

    # --- 4. Агенты -----------------------------------------------------------
    # csgo_gc в целом понимает def_index агентов как предметы, но надёжного
    # slot_id для них нет. Поэтому добавляем их без equipped_state и без
    # default_equips; при желании включите EQUIP_AGENTS и задайте слот в
    # SLOT_OVERRIDES (например, 55 = LOADOUT_POSITION_FLAIR0).
    for team, agent in _agent_entries(selection):
        defindex = _to_int(agent.get("defidx"), -1)
        if defindex <= 0:
            continue
        agent_skin = _normalize_skin(agent)
        if agent_skin is None:
            agent_skin = {"paint": 0, "wear": 0.0, "seed": 0,
                          "stat": -1, "stickers": []}
        slot = SLOT_OVERRIDES.get(defindex)
        if EQUIP_AGENTS and slot is None:
            slot = 55  # LOADOUT_POSITION_FLAIR0 -- лучший кандидат
        add_item(defindex, agent_skin, quality=AGENT_QUALITY, rarity=AGENT_RARITY,
                 slot=slot, with_attrs=bool(agent_skin["paint"]),
                 equip_classes=EQUIP_CLASSES)

    lines.append("}")

    # --- 5. default_equips ---------------------------------------------------
    if default_equips:
        lines.append('"default_equips"')
        lines.append("{")
        for defindex, class_id, slot in default_equips:
            lines.append(f'\t"{defindex}"')
            lines.append("\t{")
            lines.append(f'\t\t"class_id"\t\t"{class_id}"')
            lines.append(f'\t\t"slot_id"\t\t"{slot}"')
            lines.append("\t}")
        lines.append("}")

    # Финальный перевод строки -- как в эталонном файле.
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Запись с резервной копией и main()
# ---------------------------------------------------------------------------
def _write_with_backup(text: str, path: Path) -> Tuple[Path, Optional[Path]]:
    """Пишет файл, сохраняя прежнюю версию в .bak (или .bak.<timestamp>)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    backup: Optional[Path] = None
    if path.exists():
        backup = path.with_name(path.name + ".bak")
        if backup.exists():
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup = path.with_name(f"{path.name}.bak.{stamp}")
        shutil.copy2(path, backup)
    path.write_text(text, encoding="utf-8", newline="\n")
    return path, backup


def main() -> int:
    """Точка входа: читает JSON, строит inventory.txt, пишет бэкап и отчёт."""
    try:
        selection = _load_json(SELECTION_PATH)
        catalog = _load_json(CATALOG_PATH)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"[ошибка] не удалось прочитать исходные JSON: {exc}", file=sys.stderr)
        return 1

    try:
        text = build_inventory(selection, catalog)
    except (TypeError, ValueError) as exc:
        print(f"[ошибка] не удалось собрать inventory.txt: {exc}", file=sys.stderr)
        return 1

    targets: List[Path] = [OUTPUT_PATH]
    if MIRROR_TO_RELEASE and RELEASE_OUTPUT_PATH.parent.exists():
        targets.append(RELEASE_OUTPUT_PATH)

    print("[gc_inventory] Generated csgo_gc inventory from old selection.json")
    for target in targets:
        written, backup = _write_with_backup(text, target)
        print(f"[gc_inventory] wrote {written} ({len(text.splitlines())} lines)")
        if backup is not None:
            print(f"[gc_inventory] backup: {backup}")

    # --- краткая сводка ------------------------------------------------------
    skins = selection.get("skins") or {}
    knife = selection.get("knife")
    gloves = selection.get("gloves")
    agents = _agent_entries(selection)
    stattrak_count = sum(
        1 for entry in (skins.values() if isinstance(skins, dict) else [])
        if isinstance(entry, dict) and _to_int(entry.get("stattrak", -1), -1) >= 0
    )
    sticker_count = sum(
        sum(1 for sticker in (entry.get("stickers") or [])
            if _to_int(sticker, 0) > 0)
        for entry in (skins.values() if isinstance(skins, dict) else [])
        if isinstance(entry, dict)
    )
    print("[gc_inventory] summary:")
    print(f"[gc_inventory]   weapons      : {len(skins) if isinstance(skins, dict) else 0}")
    print(f"[gc_inventory]   knife        : {'yes' if knife else 'no'}")
    print(f"[gc_inventory]   gloves       : {'yes' if gloves else 'no'}")
    print(f"[gc_inventory]   agents       : {len(agents)}")
    print(f"[gc_inventory]   stattrak     : {stattrak_count}")
    print(f"[gc_inventory]   stickers     : {sticker_count}")
    print(f"[gc_inventory]   equip classes: {', '.join(str(c) for c in EQUIP_CLASSES)}"
          " (2=T, 3=CT)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
