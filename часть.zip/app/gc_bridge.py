"""Мост From_Los_Santos -> csgo_gc.

Раньше GUI писал csgo_skins.json и внедрял DLL в процесс игры.
Теперь «движок» — это инвентарь самой игры: мы только пишем
inventory.txt и запускаем csgo_gc. Никаких хуков и работы с памятью.
"""
import json
import subprocess
import time
from pathlib import Path

import gc_installer

HERE = Path(__file__).resolve().parent
GAME_ROOT = Path(gc_installer.GAME)
GAME_CSGO = GAME_ROOT / "csgo"
GC_DIR = GAME_CSGO / "csgo_gc"
LIVE_INV = GC_DIR / "inventory.txt"
PROJECT_INV = HERE / "inventory.txt"
LOG = HERE / "gc_bridge.log"


def log(msg):
    try:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except OSError:
        pass


def build_text(raw, catalog=None):
    """selection.json -> текст inventory.txt. Логика лежит в gc_inventory.py."""
    import gc_inventory  # импорт отложен: файл может ещё создаваться агентом
    if catalog is None:
        catalog = json.loads((HERE / "catalog.json").read_text(encoding="utf-8"))
    return gc_inventory.build_inventory(raw, catalog)


def write_inventory(raw, catalog=None):
    """Записать инвентарь и в проект, и прямо в папку игры (если GC установлен)."""
    text = build_text(raw, catalog)
    PROJECT_INV.write_text(text, encoding="utf-8")
    written = [str(PROJECT_INV)]
    if GC_DIR.is_dir():
        LIVE_INV.write_text(text, encoding="utf-8")
        written.append(str(LIVE_INV))
    log(f"inventory written: {len(text)} bytes -> {', '.join(written)}")
    return written


def ensure_installed():
    gc_installer.cmd_install()
    log("csgo_gc installed")


def launch():
    """Установить GC, записать инвентарь и запустить игру через Steam-клиент."""
    ensure_installed()
    exe = GAME_ROOT / "csgo.exe"
    if not exe.exists():
        raise RuntimeError(f"Не найден {exe}")
    subprocess.Popen([str(exe), "-steam"], cwd=str(GAME_ROOT),
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL)
    log("csgo_gc launched with -steam")
    return True


def restore():
    """Вернуть оригинальный csgo.exe и убрать csgo_gc."""
    gc_installer.cmd_uninstall()
    log("csgo_gc uninstalled, original csgo.exe restored")


def status():
    return gc_installer.cmd_status()
