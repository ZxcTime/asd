"""Finds where the entity list REALLY is, using only the running game.

The offsets file says where dwEntityList is. After a game update that address can be stale
(then every weapon handle resolves into an empty cell). Entry for entity index i sits at
    list_base + (i - 1) * 0x10
Evidence used: the local player pointer must appear in the list, and each of its weapons
(handles from m_hMyWeapons) must resolve to an entity whose m_hOwnerEntity points back to
the local player. A candidate base is accepted only when ALL weapons pass that check.
"""
ENT = 0x10
MASK = 0xFFF
SPAN_BEFORE = 0x10000
SPAN_AFTER = 0x10000


def plausible(p):
    return 0x10000 <= p < 0xFFFF0000


def usable_handles(handles):
    return [h for h in handles if h not in (0, 0xFFFFFFFF) and (h & MASK)]


def _lp_idx_candidates(slot):
    # GetLocalPlayer is the 0-based player slot, so the entity index is slot + 1
    return (slot + 1, slot) if slot is not None and slot >= 1 else (1,)


def check_mapping(pm, true_base, lp_idx, hs, o):
    """-> [(handle, entity, defidx)] if every handle resolves to a weapon owned by lp_idx."""
    own = o.get("m_hOwnerEntity")
    out = []
    for h in hs:
        try:
            e = pm.read_uint(true_base + ((h & MASK) - 1) * ENT)
            if not plausible(e):
                return None
            d = pm.read_short(e + o["m_iItemDefinitionIndex"])
            if own is not None:
                if (pm.read_uint(e + own) & MASK) != lp_idx:
                    return None
            elif not 0 < d < 1000:
                return None
        except Exception:  # noqa: BLE001  (unreadable memory = candidate rejected)
            return None
        out.append((h, e, d))
    return out or None


def check_current(pm, true_base, slot, handles, o):
    hs = usable_handles(handles)
    return bool(hs) and any(check_mapping(pm, true_base, i, hs, o) for i in _lp_idx_candidates(slot))


def _window(pm, start, size, chunk=0x1000):
    out = bytearray()
    for off in range(0, size, chunk):
        try:
            out += pm.read_bytes(start + off, chunk)
        except Exception:  # noqa: BLE001
            out += bytes(chunk)
    return bytes(out)


def find_entity_list(pm, base, lp, slot, handles, o):
    """-> {"delta", "lp_idx", "weapons"} or None. True base = base + delta."""
    hs = usable_handles(handles)
    if not hs:
        return None  # no weapons to cross-check against: not enough evidence
    start = base - SPAN_BEFORE
    blob = _window(pm, start, SPAN_BEFORE + SPAN_AFTER)
    needle = lp.to_bytes(4, "little")
    i = blob.find(needle)
    while i != -1:
        addr = start + i
        if (addr - base) % ENT == 0:
            for lp_idx in _lp_idx_candidates(slot):
                tb = addr - (lp_idx - 1) * ENT
                w = check_mapping(pm, tb, lp_idx, hs, o)
                if w:
                    return {"delta": tb - base, "lp_idx": lp_idx, "weapons": w}
        i = blob.find(needle, i + 1)
    return None
