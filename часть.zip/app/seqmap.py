"""Knife viewmodel sequence map, derived from YOUR game files (no hard-coded sequence numbers).

The server animates the viewmodel with sequence numbers of the default knife model. Another knife model orders
its sequences differently, so draw/inspect/attack look wrong. For every sequence of the default knife we look up
the sequences of the chosen knife that have the same activity (ACT_VM_*), falling back to the same label, and
give that table to the engine DLL ("seq_map" in csgo_skins.json). Pure Python, reads pak01_dir.vpk directly.
"""
import struct
import threading
from pathlib import Path

SOURCE_MODELS = ("models/weapons/v_knife_default_ct.mdl", "models/weapons/v_knife_default_t.mdl")
_cache, _lock, _busy, _tree = {}, threading.Lock(), set(), {}
LOG_PATH = None                     # set by the UI: <app>/seqmap.log (what was parsed / why it failed)


def _log(msg):
    if LOG_PATH:
        try:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(msg + "\n")
        except OSError:
            pass


class SeqMapError(Exception):
    pass


# ---------------------------------------------------------------- VPK (v1/v2), only what is needed to read files
def _cstr(buf, pos):
    end = buf.index(b"\0", pos)
    return buf[pos:end].decode("utf-8", "replace"), end + 1


def _load_tree(dir_vpk):
    key = str(dir_vpk)
    if key in _tree:
        return _tree[key]
    data = Path(dir_vpk).read_bytes()
    sig, ver, tree_size = struct.unpack_from("<III", data, 0)
    if sig != 0x55AA1234 or ver not in (1, 2):
        raise SeqMapError(f"{dir_vpk}: not a VPK v1/v2")
    head = 12 if ver == 1 else 28
    pos, end, idx = head, head + tree_size, {}
    while pos < end:
        ext, pos = _cstr(data, pos)
        if not ext:
            break
        while True:
            path, pos = _cstr(data, pos)
            if not path:
                break
            while True:
                name, pos = _cstr(data, pos)
                if not name:
                    break
                crc, pre, arch, off, ln, term = struct.unpack_from("<IHHIIH", data, pos)
                pos += 18
                if term != 0xFFFF:
                    raise SeqMapError("VPK tree is corrupt")
                preload = data[pos:pos + pre]
                pos += pre
                full = f"{path}/{name}.{ext}".lower() if path != " " else f"{name}.{ext}".lower()
                idx[full] = (arch, off, ln, preload)
    _tree[key] = (idx, head + tree_size, Path(dir_vpk))
    return _tree[key]


def vpk_read(csgo_dir, rel):
    dir_vpk = Path(csgo_dir) / "pak01_dir.vpk"
    idx, data_start, p = _load_tree(dir_vpk)
    ent = idx.get(rel.lower())
    if ent is None:
        raise SeqMapError(f"{rel} is not in {dir_vpk.name}")
    arch, off, ln, preload = ent
    if ln == 0:
        return preload
    if arch == 0x7FFF:
        with open(p, "rb") as f:
            f.seek(data_start + off)
            return preload + f.read(ln)
    with open(p.with_name(p.name.replace("_dir", f"_{arch:03d}")), "rb") as f:
        f.seek(off)
        return preload + f.read(ln)


# ---------------------------------------------------------------- MDL (studio v44-49): sequence labels + activities
HDR_LOCALSEQ, HDR_INCLUDE = 188, 336            # studiohdr_t: numlocalseq/localseqindex, numincludemodels/includemodelindex
MAX_INCLUDE_DEPTH = 4


def _check_mdl(buf):
    if len(buf) < 344 or buf[:4] != b"IDST":
        raise SeqMapError("not an MDL (IDST) file")


def parse_mdl(buf):
    """-> [(label, activity_name)] of the sequences stored IN THIS FILE (can be empty: the knife view models keep
    their animations in included models, see includes())."""
    _check_mdl(buf)
    n, idx = struct.unpack_from("<ii", buf, HDR_LOCALSEQ)
    if n == 0:
        return []
    if not (0 < n < 2000 and 0 < idx < len(buf)):
        ver, _chk = struct.unpack_from("<ii", buf, 4)
        raise SeqMapError(f"implausible sequence table n={n} index={idx} (mdl version {ver}, size {len(buf)})")
    out = []
    for i in range(n):
        base = idx + i * 212                              # sizeof(mstudioseqdesc_t) in v49
        if base + 212 > len(buf):
            raise SeqMapError("sequence table runs past end of file")
        lab, act = struct.unpack_from("<ii", buf, base + 4)
        label, _ = _cstr(buf, base + lab)
        actname, _ = _cstr(buf, base + act) if act else ("", 0)
        if not label.isprintable() or len(label) > 80:
            raise SeqMapError("sequence names do not decode: layout differs from the expected one")
        out.append((label, actname))
    return out


def includes(buf):
    """Paths of the models this one includes ($includemodel): mstudiomodelgroup_t{szlabelindex, sznameindex}."""
    _check_mdl(buf)
    n, idx = struct.unpack_from("<ii", buf, HDR_INCLUDE)
    if n == 0:
        return []
    if not (0 < n < 64 and 0 < idx < len(buf)):
        raise SeqMapError(f"implausible include table n={n} index={idx}")
    out = []
    for i in range(n):
        base = idx + i * 8
        if base + 8 > len(buf):
            raise SeqMapError("include table runs past end of file")
        _lab, name = struct.unpack_from("<ii", buf, base)  # the name offset is relative to the group entry
        out.append(_cstr(buf, base + name)[0])
    return out


def _exists(csgo_dir, rel):
    idx, _start, _p = _load_tree(Path(csgo_dir) / "pak01_dir.vpk")
    return rel.lower() in idx


def _resolve(csgo_dir, rel):
    rel = rel.replace("\\", "/")
    for cand in (rel, "models/" + rel):
        if _exists(csgo_dir, cand):
            return cand
    raise SeqMapError(f"included model {rel} is not in pak01_dir.vpk")


def virtual_sequences(csgo_dir, model, depth=0, trail=()):
    """Sequence list in the order the engine numbers them: own sequences first, then the ones of every
    included model in order; a label that already exists (case-insensitive) is not added again."""
    buf = vpk_read(csgo_dir, model)
    seqs = list(parse_mdl(buf))
    incs = includes(buf)
    _log(f"   {model}: {len(seqs)} own sequences, includes {incs}")
    if depth >= MAX_INCLUDE_DEPTH:
        return seqs
    for inc in incs:
        path = _resolve(csgo_dir, inc)
        if path.lower() in trail or path.lower() == model.lower():
            continue
        have = {label.lower() for label, _ in seqs}
        for label, act in virtual_sequences(csgo_dir, path, depth + 1, trail + (model.lower(),)):
            if label.lower() not in have:
                seqs.append((label, act))
                have.add(label.lower())
    return seqs


def _stem(s):
    return s.lower().rstrip("0123456789_")


def build_map(src, tgt):
    """Pure function: src/tgt = [(label, activity)] -> {src_seq: [target_seqs]} (only entries that differ)."""
    res = {}
    for i, (sl, sa) in enumerate(src):
        sa_l = sa.lower()
        cands = []
        if sa_l and sa_l != "act_invalid":
            cands = [j for j, (_, ta) in enumerate(tgt) if ta.lower() == sa_l]
        if not cands:
            cands = [j for j, (tl, _) in enumerate(tgt) if tl.lower() == sl.lower()]
        if not cands:
            cands = [j for j, (tl, _) in enumerate(tgt) if _stem(tl) == _stem(sl)]
        if len(cands) > 1:                                # same activity, several variants: exact label, else same stem
            exact = [j for j in cands if tgt[j][0].lower() == sl.lower()]
            same = [j for j in cands if _stem(tgt[j][0]) == _stem(sl)]
            cands = exact or same or cands
        if cands and cands != [i]:
            res[i] = cands
    return res


def compute(csgo_dir, model):
    last = None
    for sm in SOURCE_MODELS:
        try:
            src = virtual_sequences(csgo_dir, sm)
            if not src:
                raise SeqMapError(f"{sm}: no sequences, neither its own nor in included models")
            break
        except (SeqMapError, OSError, ValueError, struct.error) as e:
            last = e
    else:
        raise SeqMapError(f"default knife model unreadable: {last}")
    tgt = virtual_sequences(csgo_dir, model)
    if not tgt:
        raise SeqMapError(f"{model}: no sequences, neither its own nor in included models")
    _log(f"== {model}: source has {len(src)} sequences, target {len(tgt)}")
    _log("source: " + "; ".join(f"{i}={l}/{a}" for i, (l, a) in enumerate(src)))
    _log("target: " + "; ".join(f"{i}={l}/{a}" for i, (l, a) in enumerate(tgt)))
    m = build_map(src, tgt)
    if not m:
        # An EMPTY map is a valid result, not an error: both models number their sequences the
        # same way, so the DLL must leave m_nSequence untouched. The old code raised here, the
        # launcher then omitted "seq_map" from the config, and the DLL used its hard-coded
        # (wrong) fallback table -> F inspect became a backstab, draw played twice, knives
        # with fewer sequences vanished. seq_map_ready=True in the config marks this as identity.
        _log("map: {}   (identity: sequence order already matches, no remap needed)")
        return {}
    _log(f"map: {m}")
    return {str(k): v for k, v in m.items()}


# ---------------------------------------------------------------- async front end (keeps the UI thread free)
def cached(model):
    with _lock:
        return _cache.get(model)


def request(csgo_dir, model, on_done):
    """Compute in a worker thread; on_done(ok: bool, message: str) is called from that thread."""
    with _lock:
        if not csgo_dir:
            _log(f"== {model}: csgo folder not found (Steam registry), identity sequence map")
            _cache[model] = {}
            # Still notify the UI so it re-exports the config with seq_map_ready=True; otherwise the
            # DLL keeps waiting for a table that never arrives.
            threading.Thread(target=on_done, args=(True, "анимации ножа: порядок совпадает, remap не нужен"),
                             daemon=True).start()
            return
        if model in _cache or model in _busy:
            return
        _busy.add(model)

    def work():
        ok, msg = False, ""
        try:
            m = compute(csgo_dir, model)
            with _lock:
                _cache[model] = m
            ok, msg = True, ("анимации ножа: порядок совпадает, remap не нужен" if not m else
                             f"анимации ножа: {len(m)} последовательностей сопоставлено")
        except Exception as e:  # noqa: BLE001  never break the UI because of animations
            import traceback
            _log(f"== {model}: FAILED csgo_dir={csgo_dir}\n" + traceback.format_exc())
            with _lock:
                _cache[model] = {}
            msg = f"анимации ножа: таблица не построена ({e}); используется запасная"
        finally:
            with _lock:
                _busy.discard(model)
        on_done(ok, msg)

    threading.Thread(target=work, daemon=True).start()
