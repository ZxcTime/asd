"""Smooth building blocks for skins_ui.py.

Every shape is drawn with Pillow at 4x size and shrunk with LANCZOS, so edges are anti-aliased.
Tk only displays the finished RGBA images (canvas image items): no pixel stairs on corners, circles
or icons. One timer (Engine) drives hover fades, the yellow glow pulse, the view fade/slide and
smooth scrolling.
"""
import atexit
import itertools
import math
import os
import sys
import time
import tkinter as tk

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageTk

try:
    LANCZOS = Image.Resampling.LANCZOS
except AttributeError:  # Pillow < 9.1
    LANCZOS = Image.LANCZOS

SS = 4                      # supersampling factor
GLOW_PAD = 22               # how far the glow reaches outside a box
YELLOW = (255, 206, 56)

# (fill RGBA, outline RGBA or None). Every button has a normal and a hover style.
GLASS = ((14, 20, 38, 200), (170, 190, 235, 96))
GLASS_H = ((36, 54, 100, 228), (205, 222, 255, 170))
ACTIVE = ((46, 76, 142, 236), (170, 200, 255, 150))
ACTIVE_H = ((68, 108, 190, 246), (210, 228, 255, 210))
GREEN = ((26, 108, 70, 236), (130, 232, 176, 160))
GREEN_H = ((40, 140, 92, 246), (170, 246, 200, 215))

_ids = itertools.count(1)
_cache = {}
_fonts = {}


# ---------------------------------------------------------------------------------------- drawing
def mix(a, b, t):
    if a is None and b is None:
        return None
    a = a or (0, 0, 0, 0)
    b = b or (0, 0, 0, 0)
    return tuple(round(x + (y - x) * t) for x, y in zip(a, b))


def rr_image(w, h, r, fill, outline=None, ow=1.3):
    """Anti-aliased rounded rectangle (RGBA). Large r gives a pill, r = w/2 = h/2 a circle."""
    w, h = max(2, int(w)), max(2, int(h))
    r = min(r, w / 2, h / 2)
    big = Image.new("RGBA", (w * SS, h * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(big)
    if outline and outline[3]:
        d.rounded_rectangle([0, 0, w * SS - 1, h * SS - 1], r * SS, fill=outline)
        k = ow * SS
        d.rounded_rectangle([k, k, w * SS - 1 - k, h * SS - 1 - k], max(0.0, r - ow) * SS, fill=fill)
    else:
        d.rounded_rectangle([0, 0, w * SS - 1, h * SS - 1], r * SS, fill=fill)
    return big.resize((w, h), LANCZOS)


def box_frames(w, h, r, base, hover, n=7):
    """n PhotoImages fading from the base style to the hover style (shared between equal boxes)."""
    key = ("box", int(w), int(h), r, base, hover, n)
    fr = _cache.get(key)
    if fr is None:
        fr = [ImageTk.PhotoImage(rr_image(w, h, r, mix(base[0], hover[0], i / (n - 1)),
                                          mix(base[1], hover[1], i / (n - 1))))
              for i in range(n)]
        _cache[key] = fr
    return fr


def glow_frames(w, h, r, color=YELLOW, levels=18, ow=2.2):
    """Soft yellow ring + halo around a w x h box, `levels` brightness steps (dim -> bright).
    Image size is (w + 2*GLOW_PAD) x (h + 2*GLOW_PAD); place it at (x - GLOW_PAD, y - GLOW_PAD)."""
    key = ("glow", int(w), int(h), r, color, levels)
    fr = _cache.get(key)
    if fr is not None:
        return fr
    pad = GLOW_PAD
    W, H = int(w) + 2 * pad, int(h) + 2 * pad
    halo = Image.new("L", (W, H), 0)
    ImageDraw.Draw(halo).rounded_rectangle([pad, pad, pad + w - 1, pad + h - 1], r, outline=255, width=7)
    halo = halo.filter(ImageFilter.GaussianBlur(pad * 0.42)).point(lambda v: min(255, int(v * 3.0)))
    inside = Image.new("L", (W * SS, H * SS), 0)
    ImageDraw.Draw(inside).rounded_rectangle([pad * SS, pad * SS, (pad + w) * SS - 1, (pad + h) * SS - 1],
                                             r * SS, fill=255)
    halo = ImageChops.multiply(halo, ImageChops.invert(inside.resize((W, H), LANCZOS)))
    ring = Image.new("L", (W * SS, H * SS), 0)
    ImageDraw.Draw(ring).rounded_rectangle([pad * SS, pad * SS, (pad + w) * SS - 1, (pad + h) * SS - 1],
                                           r * SS, outline=255, width=int(ow * SS))
    ring = ring.resize((W, H), LANCZOS)
    solid = Image.new("RGBA", (W, H), tuple(color) + (255,))
    fr = []
    for k in range(levels):
        t = k / (levels - 1)
        a = ImageChops.lighter(halo.point(lambda v, s=0.08 + 0.80 * t: int(v * s)),
                               ring.point(lambda v, s=0.40 + 0.60 * t: int(v * s)))
        img = solid.copy()
        img.putalpha(a)
        fr.append(ImageTk.PhotoImage(img))
    _cache[key] = fr
    return fr


def icon_image(kind, size, color=(255, 255, 255, 255)):
    """Vector-style icons drawn with round caps/joins: play, stop, back."""
    S = size * SS
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    lw = max(2, int(S * 0.115))

    def dot(p):
        d.ellipse([p[0] - lw / 2, p[1] - lw / 2, p[0] + lw / 2, p[1] + lw / 2], fill=color)

    def line(pts):
        d.line(pts, fill=color, width=lw, joint="curve")
        for p in pts:
            dot(p)

    if kind == "play":
        pts = [(0.37 * S, 0.27 * S), (0.37 * S, 0.73 * S), (0.72 * S, 0.50 * S)]
        d.polygon(pts, fill=color)
        line(pts + [pts[0]])
    elif kind == "stop":
        d.rounded_rectangle([0.30 * S, 0.30 * S, 0.70 * S, 0.70 * S], 0.10 * S, fill=color)
    elif kind == "back":
        line([(0.74 * S, 0.50 * S), (0.27 * S, 0.50 * S)])
        line([(0.48 * S, 0.26 * S), (0.26 * S, 0.50 * S), (0.48 * S, 0.74 * S)])
    return im.resize((size, size), LANCZOS)


def icon_photo(kind, size):
    key = ("icon", kind, size)
    if key not in _cache:
        _cache[key] = ImageTk.PhotoImage(icon_image(kind, size))
    return _cache[key]


def knob_image(d=26):
    pad = 9
    S = d + 2 * pad
    sh = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(sh).ellipse([pad, pad + 2, pad + d, pad + d + 2], fill=(0, 0, 0, 120))
    sh = sh.filter(ImageFilter.GaussianBlur(3))
    big = Image.new("RGBA", (S * SS, S * SS), (0, 0, 0, 0))
    g = ImageDraw.Draw(big)
    g.ellipse([pad * SS, pad * SS, (pad + d) * SS, (pad + d) * SS], fill=(244, 247, 255, 255))
    k = 0.30 * d * SS
    c = S * SS / 2
    g.ellipse([c - k, c - k, c + k, c + k], fill=(96, 144, 236, 255))
    return Image.alpha_composite(sh, big.resize((S, S), LANCZOS))


def track_images(w, pill_h=10, full_h=34):
    """(empty track, filled track) as full_h-high images with the pill in the middle.
    The transparent padding makes a comfortable hit area for the mouse."""
    back = rr_image(w, pill_h, pill_h / 2, (255, 255, 255, 52), (255, 255, 255, 90), ow=1)
    mask = rr_image(w, pill_h, pill_h / 2, (255, 255, 255, 255)).getchannel("A")
    grad = Image.new("RGBA", (w, pill_h))
    gd = ImageDraw.Draw(grad)
    for x in range(w):
        gd.line([(x, 0), (x, pill_h)], fill=mix((78, 124, 232, 255), (150, 198, 255, 255), x / max(1, w - 1)))
    grad.putalpha(mask)
    y = (full_h - pill_h) // 2
    t1 = Image.new("RGBA", (w, full_h), (0, 0, 0, 0))
    t1.alpha_composite(back, (0, y))
    t2 = Image.new("RGBA", (w, full_h), (0, 0, 0, 0))
    t2.alpha_composite(grad, (0, y))
    return t1, t2


def app_icon(size=64):
    """Window/taskbar icon: the From_Los_Santos logo (logo.png), generated icon only as fallback."""
    try:
        here = os.environ.get("FLS_HOME") or getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
        return Image.open(os.path.join(here, "logo.png")).convert("RGBA").resize((size, size), LANCZOS)
    except OSError:
        pass
    return _generated_icon(size)


def _generated_icon(size=64):
    img = rr_image(size, size, size * 0.26, (18, 26, 48, 255), (110, 168, 255, 255), ow=2)
    big = Image.new("RGBA", (size * SS, size * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(big)
    c, k = size * SS / 2, size * SS * 0.26
    d.ellipse([c - k, c - k, c + k, c + k], outline=(255, 206, 56, 255), width=int(size * SS * 0.07))
    img.alpha_composite(big.resize((size, size), LANCZOS))
    return img


def fallback_bg():
    """Grey-blue blurred gradient, used only when bg.png is missing."""
    rows = [[(112, 112, 138), (200, 208, 222), (178, 178, 196), (120, 118, 140)],
            [(190, 196, 216), (200, 206, 224), (196, 200, 222), (180, 184, 214)],
            [(140, 146, 184), (150, 156, 192), (130, 136, 176), (92, 96, 142)]]
    small = Image.new("RGB", (4, 3))
    for y, row in enumerate(rows):
        for x, c in enumerate(row):
            small.putpixel((x, y), c)
    return small.resize((1920, 1200), Image.BICUBIC)


# ---------------------------------------------------------------------------------------- shimmer title
def shimmer_frames(text, px=18, color=YELLOW, n=140, alpha=0.82):
    """Plain text (no background) as n RGBA frames. A yellow light travels through the letters from
    left to right: the letters it passes turn yellow and throw a soft glow. Frame 0 and the last
    frame are the resting text (light is outside), so the loop has no jump.
    Returns (frames, width, height) or None when no font file was found."""
    key = ("shim", text, px, color, n, alpha)
    if key in _cache:
        return _cache[key]
    imgs = shimmer_images(text, px, color, n, alpha)
    if imgs is None:
        return None
    res = ([ImageTk.PhotoImage(f) for f in imgs], imgs[0].width, imgs[0].height)
    _cache[key] = res
    return res


def shimmer_images(text, px=18, color=YELLOW, n=140, alpha=0.82):
    """The PIL part of shimmer_frames (separate so it can be tested without a window)."""
    font = load_font(px * SS, True)
    l, t, r, b = font.getbbox(text)
    pad = 16
    tw, th = -(-(r - l) // SS), -(-(b - t) // SS)
    W, H = tw + 2 * pad, th + 2 * pad
    big = Image.new("L", (W * SS, H * SS), 0)
    ImageDraw.Draw(big).text((pad * SS - l, pad * SS - t), text, font=font, fill=255)
    mask = big.resize((W, H), LANCZOS)
    glow_near = mask.filter(ImageFilter.GaussianBlur(2.6)).point(lambda v: min(255, int(v * 1.9)))
    glow_far = mask.filter(ImageFilter.GaussianBlur(7.5)).point(lambda v: min(255, int(v * 1.2)))
    base = Image.new("RGBA", (W, H), (255, 255, 255, 255))
    base.putalpha(mask.point(lambda v: int(v * alpha)))
    hot = tuple(color) + (255,)
    sig = W * 0.085
    frames = []
    for i in range(n):
        c = -2.0 * sig + (W + 4.0 * sig) * i / (n - 1)
        row = Image.new("L", (W, 1))
        row.putdata([int(255 * math.exp(-((x - c) / sig) ** 2)) for x in range(W)])
        band = row.resize((W, H))
        halo = ImageChops.lighter(ImageChops.multiply(glow_near, band).point(lambda v: int(v * 0.95)),
                                  ImageChops.multiply(glow_far, band).point(lambda v: int(v * 0.60)))
        lit = Image.new("RGBA", (W, H), hot)
        lit.putalpha(ImageChops.multiply(mask, band))
        under = Image.new("RGBA", (W, H), hot)
        under.putalpha(halo)
        frames.append(Image.alpha_composite(Image.alpha_composite(under, base), lit))
    return frames


# ---------------------------------------------------------------------------------------- fonts + text
def res_path(*parts):
    """Files bundled with the program (works from source and inside a PyInstaller exe)."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, *parts)


_FONT_CHAIN = {
    True: ("Inter-SemiBold.otf", "seguisb.ttf", "segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf"),
    False: ("Inter-Medium.otf", "segoeui.ttf", "arial.ttf", "DejaVuSans.ttf"),
}
TEXT_PAD = 3                    # transparent margin around every text picture
MOTION_BLUR = False             # off: blurred frames were generated on the fly and made transitions stutter
BLUR_STEPS = (0, 2, 4, 6, 9, 13, 18)    # motion blur lengths in px that exist
BLUR_K_SLIDE = 0.035            # page slide: blur px per (px/s) of speed
_timg = {}


def _font_dirs():
    here = os.path.dirname(os.path.abspath(__file__))
    return [res_path("fonts"), os.path.join(here, "fonts"),
            os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
            "/usr/share/fonts/opentype/inter", "/usr/share/fonts/truetype/dejavu"]


def load_font(px, bold=True):
    """Pillow font: Inter (fonts/ folder) first, then Segoe UI / Arial from Windows."""
    key = (px, bold)
    f = _fonts.get(key)
    if f is None:
        from PIL import ImageFont
        for name in _FONT_CHAIN[bold]:
            for d in _font_dirs():
                path = os.path.join(d, name)
                if os.path.exists(path):
                    try:
                        f = ImageFont.truetype(path, px)
                        break
                    except OSError:
                        pass
            if f:
                break
        if f is None:
            try:
                f = ImageFont.load_default(px)
            except TypeError:
                f = ImageFont.load_default()
        _fonts[key] = f
    return f


def pil_font(font):
    """Tk-style tuple (family, size_pt, 'bold') -> Pillow font."""
    size = font[1] if len(font) > 1 else 10
    bold = any("bold" in str(x) for x in font[2:])
    px = round(size * 1.28) if size > 0 else -size
    return load_font(max(8, px), bold)


def text_width(font, text):
    f = pil_font(font)
    return int(math.ceil(max((f.getlength(l) for l in text.split("\n")), default=0)))


def fit_text(font, text, maxw):
    if text_width(font, text) <= maxw:
        return text
    while text and text_width(font, text + "…") > maxw:
        text = text[:-1]
    return text + "…"


def _rgb(c):
    if isinstance(c, (tuple, list)):
        return tuple(int(v) for v in c[:3])
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def wrap_lines(font, text, maxw):
    f = pil_font(font)
    out = []
    for para in text.split("\n"):
        if not maxw:
            out.append(para)
            continue
        line = ""
        for word in para.split(" "):
            cand = word if not line else line + " " + word
            if f.getlength(cand) <= maxw:
                line = cand
                continue
            if line:
                out.append(line)
            while len(word) > 1 and f.getlength(word) > maxw:
                n = len(word)
                while n > 1 and f.getlength(word[:n]) > maxw:
                    n -= 1
                out.append(word[:n])
                word = word[n:]
            line = word
        out.append(line)
    return out or [""]


def text_image(text, font, fg="#ffffff", maxw=None, lh=1.28):
    """Text as an anti-aliased RGBA picture. Its vertical centre is the optical centre of the
    letters (middle of the capital height, or of the x-height when there are no capitals), so a word
    put at a button's centre really looks centred. Ink width = image width - 2 * TEXT_PAD."""
    key = (text, font, fg, maxw)
    hit = _timg.get(key)
    if hit is not None:
        return hit
    f = pil_font(font)
    lines = wrap_lines(font, text, maxw)
    ref = "Н" if any(ch.isupper() or ch.isdigit() for ch in text) else "х"
    cap = -f.getbbox(ref, anchor="ls")[1]
    desc = f.getbbox("р", anchor="ls")[3]
    step = round(getattr(f, "size", 12) * lh)
    n = len(lines)
    H = max(2 * math.ceil(cap / 2 + desc + 3), n * step + 6)
    W = int(math.ceil(max(f.getlength(l) for l in lines))) + 2 * TEXT_PAD
    mask = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(mask)
    for i, line in enumerate(lines):
        yb = H / 2 + (i - (n - 1) / 2) * step + cap / 2
        d.text((round((W - f.getlength(line)) / 2), round(yb)), line, font=f, fill=255, anchor="ls")
    img = Image.new("RGBA", (W, H), _rgb(fg) + (255,))
    img.putalpha(mask)
    if len(_timg) > 600:
        _timg.clear()
    _timg[key] = img
    return img


def motion_blur(img, length, axis):
    """Box blur along one axis ('x' or 'y') in premultiplied alpha. The picture grows by the same
    margin on both sides of that axis. Returns (image, pad_x, pad_y)."""
    L = int(length)
    if L < 1:
        return img, 0, 0
    p = L // 2 + 1
    w, h = img.size
    px, py = (p, 0) if axis == "x" else (0, p)
    canvas = Image.new("RGBa", (w + 2 * px, h + 2 * py))
    canvas.paste(img.convert("RGBa"), (px, py))
    stride = max(1, L // 8)
    acc = None
    for k, o in enumerate(range(-(L // 2), L // 2 + 1, stride), 1):
        sh = ImageChops.offset(canvas, o if axis == "x" else 0, o if axis == "y" else 0)
        acc = sh if acc is None else Image.blend(acc, sh, 1.0 / k)
    return acc.convert("RGBA"), px, py


def box_blur(w, h, r, style0, axis, L):
    """(PhotoImage, pad_x, pad_y) of a blurred rounded box in its resting style."""
    key = ("boxb", int(w), int(h), r, style0, axis, L)
    hit = _cache.get(key)
    if hit is None:
        img, px, py = motion_blur(rr_image(w, h, r, *style0), L, axis)
        hit = _cache[key] = (ImageTk.PhotoImage(img), px, py)
    return hit


# ---------------------------------------------------------------------------------------- engine
FPS_CAP = 1200                  # timer ceiling (>1000 Hz in practice, including Windows timer rounding)
FRAME = 1.0 / FPS_CAP
GLOW_FRAME = 1.0 / 60           # only the yellow pulse is running: 60 Hz is plenty
IDLE_FRAME = 1.0 / 30           # nothing moves: just poll hooks
AWAKE = 3.0                     # stay fast for the whole transition / scroll gesture
SUBSTEPS = 8                    # intermediate animation steps inside one timer tick


def _timer_resolution():
    """Windows rounds after(3) up to ~15.6 ms unless the 1 ms timer resolution is requested."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        winmm = ctypes.windll.winmm
        if winmm.timeBeginPeriod(1) == 0:
            atexit.register(winmm.timeEndPeriod, 1)
    except Exception:
        pass


class Engine:
    """One timer for everything that moves, capped at FPS_CAP.

    Cost control: the timer runs at FRAME only while something animates or the mouse was used in
    the last AWAKE seconds; with only the glow pulse it drops to 60 Hz, fully idle to 30 Hz.
    Every step skips canvas calls when the visible result is unchanged (integer pixels, same frame).
    """
    HOVER = 0.20        # seconds for a hover fade
    PULSE = 1.7         # seconds for one glow breath

    def __init__(self, root, cv):
        self.root, self.cv = root, cv
        self.hover, self.active = {}, set()     # item -> [pos, target, frames, last_idx]
        self.glows, self._glast = {}, {}        # item -> frames, item -> last level shown
        self.shimmers, self._slast = {}, {}     # item -> (frames, cycle, sweep), item -> last frame
        self.freeze_glow = False                # True while scrolling: the pulse waits (less to repaint)
        self.blurables, self.blur_hold = [], set()   # widgets that can swap to motion-blurred pictures
        self.blur_len, self.blur_axis, self._want = 0, "y", None
        self._pend, self._bscan = [], 0.0
        self.slides, self.veils, self.hooks = [], [], []
        self.windows = []                       # (Toplevel, duration, start, last alpha level)
        self.t0 = self.last = self._next = time.perf_counter()
        self.wake_until = 0.0
        self.fps = 0.0
        self.renders = 0
        self.render_fps = 0.0
        self._fc, self._ft = 0, self.t0
        _timer_resolution()
        for ev in ("<Motion>", "<MouseWheel>", "<Button-4>", "<Button-5>", "<ButtonPress>", "<Configure>"):
            cv.bind(ev, self._on_input, add="+")
        self._dead, self._after = False, None
        self._after = root.after(1, self._tick)

    def shutdown(self):
        """Stop the timer for good and drop every canvas item (call before root.destroy())."""
        self._dead = True
        self.hooks.clear()
        for name in ("_after",):
            aid = getattr(self, name, None)
            if aid:
                try:
                    self.root.after_cancel(aid)
                except Exception:
                    pass
        self.hover.clear(); self.active.clear(); self.glows.clear(); self.shimmers.clear()
        self.blurables.clear(); self.blur_hold.clear(); self._pend = []
        self.slides.clear(); self.veils.clear(); self.windows.clear()
        try:
            self.cv.delete("all")
        except Exception:
            pass

    def _on_input(self, _e=None):
        self.wake_until = time.perf_counter() + AWAKE

    def wake(self, seconds=AWAKE):
        """Keep the timer fast for `seconds` (toasts, scroll inertia in hooks, ...)."""
        self.wake_until = max(self.wake_until, time.perf_counter() + seconds)

    def _alive(self, item):
        return bool(self.cv.type(item))

    # -- registration
    def fade(self, item, frames, target):
        st = self.hover.setdefault(item, [0.0, 0, frames, -1])
        st[1], st[2] = target, frames
        self.active.add(item)

    def restyle(self, item, frames):
        st = self.hover.get(item)
        if st:
            st[2], st[3] = frames, -1
            self.active.add(item)
        else:
            self.cv.itemconfigure(item, image=frames[0])

    def add_glow(self, item, frames):
        self.glows[item] = frames

    def add_shimmer(self, item, frames, cycle=3.4, sweep=0.62):
        """Light travels through `frames` during `sweep` of every `cycle` seconds, then rests."""
        self.shimmers[item] = (frames, cycle, sweep)

    # -- motion blur
    def register(self, widget):
        self.blurables.append(widget)

    def reset_blur(self):
        self.blurables.clear()
        self.blur_hold.clear()
        self._pend = []

    def set_blur(self, axis, length):
        """Ask for `length` px of motion blur this tick (call every tick while something moves)."""
        if not MOTION_BLUR:
            return
        self._want = (axis, length)

    def _blur_scan(self):
        tgt, cv = self.blur_len, self.cv
        W, H = cv.winfo_width(), cv.winfo_height()
        keep, pend = [], []
        for b in self.blurables:
            if not b.alive:
                continue
            keep.append(b)
            if b.level == tgt:
                continue
            if tgt == 0:
                pend.append(b)
                continue
            bb = cv.bbox(b.item)
            if bb and bb[3] > -140 and bb[1] < H + 140 and bb[2] > -140 and bb[0] < W + 140:
                pend.append(b)
        self.blurables[:] = keep
        self._pend = pend

    def _step_blur(self, now):
        want, self._want = self._want, None
        axis, L = (self.blur_axis, 0.0) if want is None else want
        cur = self.blur_len
        if cur:
            axis = self.blur_axis                 # one direction at a time
        best = 0 if want is None else min(BLUR_STEPS, key=lambda v: abs(v - L))
        if best != cur and (best == 0 or abs(L - cur) > 0.6 * abs(best - cur)):
            self.blur_len, self.blur_axis = best, axis
            self._blur_scan()
            self._bscan = now
        elif self.blur_len and now - self._bscan >= 0.08:     # cards that scrolled into view
            self._blur_scan()
            self._bscan = now
        t0 = time.perf_counter()
        while self._pend and time.perf_counter() - t0 < 0.004:      # few ms per tick: no hitch
            b = self._pend.pop()
            if b.alive and b.level != self.blur_len:
                b.apply(self.blur_axis, self.blur_len)
                self.mark()
        return bool(self.blur_len or self._pend)

    def slide(self, tag, dist, dur):
        d = int(round(dist))
        self.cv.move(tag, d, 0)
        self.slides.append({"tag": tag, "dist": d, "off": d, "t0": time.perf_counter(), "dur": dur})

    def veil(self, item, frames, dur):
        """frames[i] has alpha i/(n-1); the veil goes from opaque to clear and is then deleted."""
        self.veils.append({"item": item, "frames": frames, "t0": time.perf_counter(), "dur": dur,
                           "last": -1})

    def veil_window(self, win, dur):
        """Fade a transparent Toplevel from opaque to clear (256 alpha levels, not 14 frames)."""
        self.windows.append({"win": win, "t0": time.perf_counter(), "dur": dur, "last": -1})

    def mark(self):
        """One real visual change (used for the render-rate counter)."""
        self.renders += 1

    # -- the timer
    def _tick(self):
        if self._dead:
            return
        t = time.perf_counter()
        busy = False
        try:
            dt = min(0.1, t - self.last)
            self.last = t
            self._want = None
            busy |= self._step_hover(dt)
            self._step_glow(t)
            self._step_shimmer(t)
            for i in range(SUBSTEPS):
                st = t - (SUBSTEPS - 1 - i) * (dt / SUBSTEPS)
                busy |= self._step_slides(st)
                busy |= self._step_veils(st)
                busy |= self._step_windows(st)
            for h in self.hooks:
                h(dt)
            busy |= self._step_blur(t)
            self._count(t)
        finally:
            try:
                if busy or t < self.wake_until:
                    frame = FRAME
                elif self.glows or self.shimmers:
                    frame = GLOW_FRAME
                else:
                    frame = IDLE_FRAME
                # fixed schedule, but never slower than the requested rate: a zero-ms timer
                # catches up when Windows rounds the 1 ms sleep up, so the rate stays >1000 Hz.
                self._next += frame
                now = time.perf_counter()
                delay_ms = 0 if self._next - now <= 0.0012 else max(1, int((self._next - now) * 1000))
                if not self._dead:
                    self._after = self.root.after(delay_ms, self._tick)
            except tk.TclError:
                pass

    def _count(self, t):
        self._fc += 1
        if t - self._ft >= 1.0:
            self.fps = self._fc / (t - self._ft)
            self.render_fps = self.renders / (t - self._ft)
            self._fc, self._ft, self.renders = 0, t, 0

    def _step_hover(self, dt):
        if not self.active:
            return False
        step = dt / self.HOVER
        for item in list(self.active):
            st = self.hover.get(item)
            if st is None or not self._alive(item):
                self.hover.pop(item, None)
                self.active.discard(item)
                continue
            if st[0] < st[1]:
                st[0] = min(st[1], st[0] + step)
            else:
                st[0] = max(st[1], st[0] - step)
            s = st[0] * st[0] * (3 - 2 * st[0])
            idx = round(s * (len(st[2]) - 1))
            if idx != st[3]:
                st[3] = idx
                if item not in self.blur_hold:
                    self.cv.itemconfigure(item, image=st[2][idx])
            if st[0] == st[1]:
                self.active.discard(item)
        return bool(self.active)

    def _step_glow(self, now):
        if not self.glows or self.freeze_glow:
            return
        k = 0.5 - 0.5 * math.cos(2 * math.pi * (now - self.t0) / self.PULSE)
        for item in list(self.glows):
            fr = self.glows[item]
            if not self._alive(item):
                del self.glows[item]
                self._glast.pop(item, None)
                continue
            lvl = round(k * (len(fr) - 1))
            if self._glast.get(item) != lvl:
                self._glast[item] = lvl
                self.cv.itemconfigure(item, image=fr[lvl])

    def _step_shimmer(self, now):
        for item, (fr, cycle, sweep) in list(self.shimmers.items()):
            if not self._alive(item):
                del self.shimmers[item]
                self._slast.pop(item, None)
                continue
            s = min(1.0, ((now - self.t0) % cycle) / cycle / sweep)
            e = s * s * (3 - 2 * s)                   # slow start, quick middle, soft end
            idx = round(e * (len(fr) - 1))
            if self._slast.get(item) != idx:
                self._slast[item] = idx
                self.cv.itemconfigure(item, image=fr[idx])

    def _step_slides(self, now):
        if not self.slides:
            return False
        for s in list(self.slides):
            if not self.cv.find_withtag(s["tag"]):
                self.slides.remove(s)
                continue
            t = min(1.0, (now - s["t0"]) / s["dur"])
            if t < 1:
                self.set_blur("x", abs(s["dist"]) * 4 * (1 - t) ** 3 / s["dur"] * BLUR_K_SLIDE)
            e = 1 - (1 - t) ** 4                      # ease-out quart: fast start, long soft landing
            off = round(s["dist"] * (1 - e))          # whole pixels only: sub-pixel moves draw nothing new
            if off != s["off"]:
                self.cv.move(s["tag"], off - s["off"], 0)
                s["off"] = off
                self.mark()
            if t >= 1:
                self.slides.remove(s)
        return bool(self.slides)

    def _step_veils(self, now):
        if not self.veils:
            return False
        for v in list(self.veils):
            if not self._alive(v["item"]):
                self.veils.remove(v)
                continue
            t = min(1.0, (now - v["t0"]) / v["dur"])
            a = 1 - t * t * (3 - 2 * t)               # smoothstep 1 -> 0
            idx = round(a * (len(v["frames"]) - 1))
            if idx != v["last"]:
                v["last"] = idx
                self.cv.itemconfigure(v["item"], image=v["frames"][idx])
                self.mark()
            if t >= 1:
                self.cv.delete(v["item"])
                self.veils.remove(v)
        return bool(self.veils)

    def _step_windows(self, now):
        if not self.windows:
            return False
        for w in list(self.windows):
            win = w["win"]
            try:
                alive = bool(win.winfo_exists())
            except tk.TclError:
                alive = False
            if not alive:
                self.windows.remove(w)
                continue
            t = min(1.0, max(0.0, (now - w["t0"]) / w["dur"]))
            a = 1 - t * t * (3 - 2 * t)                 # smoothstep 1 -> 0
            level = max(0, min(255, round(a * 255)))
            if level != w["last"]:
                w["last"] = level
                try:
                    win.attributes("-alpha", str(level / 255.0))
                except tk.TclError:
                    pass
                self.mark()
            if t >= 1:
                try:
                    win.withdraw()
                    win.destroy()
                except tk.TclError:
                    pass
                self.windows.remove(w)
        return bool(self.windows)


# ---------------------------------------------------------------------------------------- widgets
class Button:
    """Rounded anti-aliased button / panel. Items it owns carry self.tags, so extra canvas items
    created with those tags join its hover and click area. cmd=None makes it a plain panel."""

    def __init__(self, ui, x, y, w, h, r, *, text="", font=("Segoe UI", 11), fg="#ffffff", icon=None,
                 isz=22, cmd=None, style=(GLASS, GLASS_H), glow=False, tags=(), gap=9):
        self.ui, self.cv, self.cmd = ui, ui.cv, cmd
        self.style, self.level, self._pad, self._txt, self._tvars = style, 0, (0, 0), None, {}
        self.x, self.y, self.w, self.h, self.r = int(x), int(y), int(w), int(h), r
        self.font, self.fg, self.isz, self.gap = font, fg, isz, gap
        self.tag = "btn%d" % next(_ids)
        self.tags = (self.tag,) + tuple(tags) + (() if cmd else ("drag",))
        self.frames = box_frames(self.w, self.h, r, *style)
        self.base = self.cv.create_image(self.x, self.y, image=self.frames[0], anchor="nw", tags=self.tags)
        self.glow = None
        if glow:
            gf = glow_frames(self.w, self.h, r)
            self.glow = self.cv.create_image(self.x - GLOW_PAD, self.y - GLOW_PAD, image=gf[0],
                                             anchor="nw", tags=self.tags)
            ui.engine.add_glow(self.glow, gf)
        self.items, self._down = [], False
        self.text, self.icon = text, icon
        self._content()
        ui.engine.register(self)
        if cmd:
            for ev, fn in (("<Enter>", self._enter), ("<Leave>", self._leave),
                           ("<ButtonPress-1>", self._press), ("<ButtonRelease-1>", self._release)):
                self.cv.tag_bind(self.tag, ev, fn)

    @property
    def alive(self):
        return bool(self.cv.type(self.base))

    @property
    def item(self):
        return self.base

    def _content(self):
        for i in self.items:
            self.cv.delete(i)
        self.items, self._txt, self._tvars = [], None, {}
        tags = self.tags + (("view",) if "view" in self.cv.gettags(self.base) else ())
        cx, cy = self.x + self.w / 2, self.y + self.h / 2
        timg = text_image(self.text, self.font, self.fg) if self.text else None
        tw = timg.width - 2 * TEXT_PAD if timg else 0
        tx = cx
        if self.icon and self.text:
            sx = cx - (self.isz + self.gap + tw) / 2
            self.items.append(self.cv.create_image(sx, cy, image=icon_photo(self.icon, self.isz),
                                                   anchor="w", tags=tags))
            tx = sx + self.isz + self.gap + tw / 2
        elif self.icon:
            self.items.append(self.cv.create_image(cx, cy, image=icon_photo(self.icon, self.isz),
                                                   anchor="center", tags=tags))
        if timg is not None:
            ph = ImageTk.PhotoImage(timg)
            it = self.cv.create_image(tx, cy, image=ph, anchor="center", tags=tags)
            self.items.append(it)
            self._txt = (it, timg, ph)

    def apply(self, axis, step):
        """Swap to motion-blurred pictures (step = blur length in px) or back to sharp (0)."""
        if not self.alive:
            return
        cv, eng = self.cv, self.ui.engine
        if step == 0:
            eng.blur_hold.discard(self.base)
            eng.restyle(self.base, self.frames)
            pad = (0, 0)
            if self._txt:
                cv.itemconfigure(self._txt[0], image=self._txt[2])
            if self.glow:
                cv.itemconfigure(self.glow, state="normal")
        else:
            ph, px, py = box_blur(self.w, self.h, self.r, self.style[0], axis, step)
            eng.blur_hold.add(self.base)
            cv.itemconfigure(self.base, image=ph)
            pad = (px, py)
            if self._txt:
                tv = self._tvars.get((axis, step))
                if tv is None:
                    tv = self._tvars[(axis, step)] = ImageTk.PhotoImage(motion_blur(self._txt[1], step, axis)[0])
                cv.itemconfigure(self._txt[0], image=tv)
            if self.glow:
                cv.itemconfigure(self.glow, state="hidden")
        if pad != self._pad:
            cv.move(self.base, self._pad[0] - pad[0], self._pad[1] - pad[1])
            self._pad = pad
        self.level = step

    def update(self, text=None, icon=None, style=None, fg=None):
        if style is not None:
            self.style = style
            self.frames = box_frames(self.w, self.h, self.r, *style)
            self.ui.engine.restyle(self.base, self.frames)
        new = (self.text if text is None else text, self.icon if icon is None else icon,
               self.fg if fg is None else fg)
        if new != (self.text, self.icon, self.fg):
            self.text, self.icon, self.fg = new
            self._content()

    def _inside(self, e):
        b = self.cv.bbox(self.base)
        return bool(b) and b[0] <= e.x <= b[2] and b[1] <= e.y <= b[3]

    def _enter(self, _e):
        self.cv.configure(cursor="hand2")
        self.ui.engine.fade(self.base, self.frames, 1)

    def _leave(self, _e):
        self.cv.configure(cursor="")
        self.ui.engine.fade(self.base, self.frames, 0)
        self._down = False

    def _press(self, _e):
        self._down = True

    def _release(self, e):
        down, self._down = self._down, False
        if down and self.cmd and self._inside(e):
            self.cmd()


class Label:
    """Text widget drawn with Pillow (Inter font), centred on the letters, can be motion-blurred.
    anchor: "center" (x is the middle), "w" (x is the left edge) or "e" (x is the right edge)."""

    def __init__(self, ui, x, y, text, font, fg="#ffffff", anchor="center", maxw=None, tags=()):
        self.ui, self.cv = ui, ui.cv
        self.x, self.y, self.font, self.fg, self.anchor, self.maxw = x, y, font, fg, anchor, maxw
        self.text, self.level = text, 0
        self.item = self.cv.create_image(x, y, image="", anchor="center", tags=tuple(tags))
        self._render()
        ui.engine.register(self)

    @property
    def alive(self):
        return bool(self.cv.type(self.item))

    def _render(self):
        self.pil = text_image(self.text, self.font, self.fg, self.maxw)
        self.ph, self._var, self.level = ImageTk.PhotoImage(self.pil), {}, 0
        half = self.pil.width / 2 - TEXT_PAD
        cx = self.x + (0 if self.anchor == "center" else half if self.anchor == "w" else -half)
        cur = self.cv.coords(self.item)
        if cur and (cur[0] != cx or cur[1] != self.y):
            self.cv.coords(self.item, cx, cur[1])
        self.cv.itemconfigure(self.item, image=self.ph)

    def set(self, text=None, fg=None):
        text = self.text if text is None else text
        fg = self.fg if fg is None else fg
        if (text, fg) != (self.text, self.fg):
            self.text, self.fg = text, fg
            self._render()

    def delete(self):
        self.cv.delete(self.item)

    def apply(self, axis, step):
        if not self.alive:
            return
        if step == 0:
            self.cv.itemconfigure(self.item, image=self.ph)
        else:
            v = self._var.get((axis, step))
            if v is None:
                v = self._var[(axis, step)] = ImageTk.PhotoImage(motion_blur(self.pil, step, axis)[0])
            self.cv.itemconfigure(self.item, image=v)
        self.level = step


class Pic:
    """Picture slot (skin photo) that fills in later and can be motion-blurred."""

    def __init__(self, ui, cx, cy, tags=()):
        self.ui, self.cv = ui, ui.cv
        self.item = self.cv.create_image(cx, cy, image="", anchor="center", tags=tuple(tags))
        self.pil = self.ph = None
        self.level, self._var = 0, {}
        ui.engine.register(self)

    @property
    def alive(self):
        return bool(self.cv.type(self.item))

    def set(self, pil, ph):
        self.pil, self.ph, self._var, self.level = pil, ph, {}, 0
        self.cv.itemconfigure(self.item, image=ph)

    def apply(self, axis, step):
        if not self.alive:
            return
        if self.pil is None:
            self.level = step
            return
        if step == 0:
            self.cv.itemconfigure(self.item, image=self.ph)
        else:
            v = self._var.get((axis, step))
            if v is None:
                v = self._var[(axis, step)] = ImageTk.PhotoImage(motion_blur(self.pil, step, axis)[0])
            self.cv.itemconfigure(self.item, image=v)
        self.level = step


class ShimmerText:
    """Plain title text without a background; a yellow glowing light keeps travelling through it.
    Falls back to ordinary canvas text when no font file is found."""

    def __init__(self, ui, cx, cy, text, px=18, fallback_font=("Segoe UI", 12, "bold"), tags=()):
        cv = ui.cv
        res = shimmer_frames(text, px)
        if res is None:
            self.item = cv.create_text(cx, cy, text=text, fill="#e6e9f2", font=fallback_font, tags=tags)
            return
        frames = res[0]
        self.item = cv.create_image(cx, cy, image=frames[0], anchor="center", tags=tags)
        ui.engine.add_shimmer(self.item, frames)


class Slider:
    """Thin rounded track, filled part, round knob. Left mouse button drags it."""
    KR = 13

    def __init__(self, ui, x, cy, w, vmin, vmax, step, value, on_change=None, tags=()):
        self.ui, self.cv = ui, ui.cv
        self.x, self.cy, self.w = int(x), int(cy), int(w)
        self.vmin, self.vmax, self.step, self.on_change = vmin, vmax, step, on_change
        self.tag = "sld%d" % next(_ids)
        t = (self.tag,) + tuple(tags)
        back, self._fill_src = track_images(self.w)
        self._back_ph = ImageTk.PhotoImage(back)
        self._knob_ph = ImageTk.PhotoImage(knob_image(2 * self.KR))
        self.track = self.cv.create_image(self.x, self.cy, image=self._back_ph, anchor="w", tags=t)
        self.fill = self.cv.create_image(self.x, self.cy, image="", anchor="w", tags=t)
        self.knob = self.cv.create_image(self.x, self.cy, image=self._knob_ph, anchor="center", tags=t)
        self._fill_ph, self._fill_w = None, -1
        self.value = value
        self.set(value, notify=False)
        self.cv.tag_bind(self.tag, "<ButtonPress-1>", self._drag)
        self.cv.tag_bind(self.tag, "<B1-Motion>", self._drag)
        self.cv.tag_bind(self.tag, "<Enter>", lambda e: self.cv.configure(cursor="hand2"))
        self.cv.tag_bind(self.tag, "<Leave>", lambda e: self.cv.configure(cursor=""))

    def _drag(self, e):
        span = self.w - 2 * self.KR
        t = min(1.0, max(0.0, (e.x - self.x - self.KR) / span))
        self.set(self.vmin + t * (self.vmax - self.vmin))

    def set(self, v, notify=True):
        v = min(self.vmax, max(self.vmin, v))
        v = round(self.vmin + round((v - self.vmin) / self.step) * self.step, 6)
        self.value = v
        t = (v - self.vmin) / (self.vmax - self.vmin)
        kx = self.x + self.KR + (self.w - 2 * self.KR) * t
        fw = max(1, int(kx - self.x))
        if fw != self._fill_w:
            self._fill_w = fw
            self._fill_ph = ImageTk.PhotoImage(self._fill_src.crop((0, 0, fw, self._fill_src.height)))
            self.cv.itemconfigure(self.fill, image=self._fill_ph)
        self.cv.coords(self.knob, kx, self.cy)
        if notify and self.on_change:
            self.on_change(v)


# ---------------------------------------------------------------------------------------- window dots
DOT_COLORS = {"min": (255, 189, 46), "max": (39, 201, 63), "close": (255, 95, 86)}


def dot_image(kind, d, glyph_alpha=150, lift=0.0):
    """Round traffic-light dot with a glyph: min = bar, max = ring, close = cross.
    The glyph is a darker shade of the dot with glyph_alpha (0..255), so it looks slightly see-through."""
    S = d * SS
    col = mix(DOT_COLORS[kind] + (255,), (255, 255, 255, 255), lift)
    big = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(big).ellipse([0, 0, S - 1, S - 1], fill=col)
    glyph = Image.new("L", (S, S), 0)
    g = ImageDraw.Draw(glyph)
    lw = max(2, int(S * 0.115))
    c, k = S / 2, S * 0.17

    def cap(p):
        g.ellipse([p[0] - lw / 2, p[1] - lw / 2, p[0] + lw / 2, p[1] + lw / 2], fill=255)

    def seg(p, q):
        g.line([p, q], fill=255, width=lw)
        cap(p)
        cap(q)

    if kind == "close":
        seg((c - k, c - k), (c + k, c + k))
        seg((c - k, c + k), (c + k, c - k))
    elif kind == "max":
        r = S * 0.215
        g.ellipse([c - r, c - r, c + r, c + r], outline=255, width=lw)
    else:
        seg((c - k * 1.25, c), (c + k * 1.25, c))
    shade = tuple(mix(col, (0, 0, 0, 255), 0.66)[:3])
    layer = Image.new("RGBA", (S, S), shade + (255,))
    layer.putalpha(glyph.point(lambda v: v * glyph_alpha // 255))
    return Image.alpha_composite(big, layer).resize((d, d), LANCZOS)


def dot_frames(kind, d, n=6):
    """Rest (translucent glyph) -> hover (solid glyph, a bit brighter)."""
    key = ("dot", kind, d, n)
    fr = _cache.get(key)
    if fr is None:
        fr = [ImageTk.PhotoImage(dot_image(kind, d, round(150 + 105 * i / (n - 1)), 0.12 * i / (n - 1)))
              for i in range(n)]
        _cache[key] = fr
    return fr


class WindowDots:
    """Yellow bar (minimise), green ring (maximise), red cross (close), right edge at `right`.
    Pass the same callbacks the old dots used; cmd=None leaves a dot inert."""

    def __init__(self, ui, right, cy, d=20, gap=9, on_min=None, on_max=None, on_close=None, tags=()):
        self.ui, self.cv, self.d = ui, ui.cv, d
        self.items = {}
        x = right - (3 * d + 2 * gap)
        for kind, cmd in (("min", on_min), ("max", on_max), ("close", on_close)):
            fr = dot_frames(kind, d)
            it = self.cv.create_image(x, cy, image=fr[0], anchor="w", tags=tuple(tags) + ("wdot",))
            self.items[kind] = it
            self.cv.tag_bind(it, "<Enter>", lambda e, i=it, f=fr: self._hover(i, f, 1))
            self.cv.tag_bind(it, "<Leave>", lambda e, i=it, f=fr: self._hover(i, f, 0))
            if cmd:
                self.cv.tag_bind(it, "<ButtonRelease-1>", lambda e, c=cmd: c())
            x += d + gap

    def _hover(self, item, frames, target):
        self.cv.configure(cursor="hand2" if target else "")
        self.ui.engine.fade(item, frames, target)


# ---------------------------------------------------------------------------------------- toast
class Toast:
    """Small pill message (e.g. at the bottom of the window). show(text) displays it, keeps it for
    `hold` seconds (1.5 by default), then fades it out and deletes the canvas items.
    A new show() replaces the old text and restarts the timer."""
    N = 8

    def __init__(self, ui, cx, cy, h=38, font=("Segoe UI", 11, "bold"), fg="#ffffff", hold=1.5,
                 fade=0.35, pad=26, style=GLASS, tags=()):
        self.ui, self.cv = ui, ui.cv
        self.cx, self.cy, self.h, self.font, self.fg = cx, cy, h, font, fg
        self.hold, self.fade, self.pad, self.style, self.tags = hold, fade, pad, style, tuple(tags)
        self.img = None
        self.frames = []
        self.t0 = 0.0
        self.last = -1
        ui.engine.hooks.append(self._step)

    def _build(self, text):
        timg = text_image(text, self.font, self.fg)
        w = timg.width - 2 * TEXT_PAD + 2 * self.pad
        fill, line = self.style
        self.frames = []
        for i in range(self.N):
            k = i / (self.N - 1)
            img = rr_image(w, self.h, self.h / 2, fill[:3] + (round(fill[3] * k),),
                           line[:3] + (round(line[3] * k),))
            t = timg.copy()
            t.putalpha(t.getchannel("A").point(lambda v, k=k: int(v * k)))
            img.alpha_composite(t, ((w - t.width) // 2, (self.h - t.height) // 2))
            self.frames.append(ImageTk.PhotoImage(img))

    def show(self, text, hold=None):
        self.clear()
        self._build(text)
        self.hold_now = self.hold if hold is None else hold
        self.img = self.cv.create_image(self.cx, self.cy, image=self.frames[-1], anchor="center", tags=self.tags)
        self.t0 = time.perf_counter()
        self.last = -1
        self.ui.engine.wake(self.hold_now + self.fade + 0.1)

    def clear(self):
        if self.img is not None:
            self.cv.delete(self.img)
        self.img = None

    def _step(self, _dt):
        if self.img is None:
            return
        t = time.perf_counter() - self.t0
        if t < self.hold_now:
            return
        k = (t - self.hold_now) / self.fade
        if k >= 1:
            self.clear()
            return
        idx = round((1 - k) * (self.N - 1))
        if idx != self.last:
            self.last = idx
            self.cv.itemconfigure(self.img, image=self.frames[idx])


# ---------------------------------------------------------------------------------------- shutdown
def close_app(root, engine=None):
    """Close without the 'Fatal Error / alloc: invalid block' dialog.
    Order matters: stop the timer, delete canvas items, free every PhotoImage while Tcl is still
    alive, destroy the window, then leave with os._exit(0) so no PhotoImage.__del__ runs against
    the dead interpreter. Save settings BEFORE calling this: os._exit skips atexit and flushes."""
    try:
        if engine is not None:
            engine.shutdown()
        _cache.clear()
        _fonts.clear()
        _timg.clear()
        root.update_idletasks()
        root.destroy()
    except Exception:
        pass
    finally:
        for st in (sys.stdout, sys.stderr):
            try:
                st.flush()
            except Exception:
                pass
        os._exit(0)


# ---------------------------------------------------------------------------------------- rounded window
def round_window(root, radius=46):
    """Very round window corners (Windows): clips the top-level to a rounded rectangle with
    SetWindowRgn and re-applies it on every resize. radius is in pixels. Returns True if applied.
    The region edge is not anti-aliased (a Windows limitation of window regions)."""
    if sys.platform != "win32":
        return False
    import ctypes
    from ctypes import wintypes
    u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32

    def hwnd_of():
        root.update_idletasks()
        h = u32.GetParent(root.winfo_id()) or root.winfo_id()
        return h

    state = {"size": None}

    def apply(_e=None):
        h = hwnd_of()
        r = wintypes.RECT()
        if not u32.GetWindowRect(h, ctypes.byref(r)):
            return
        w, hgt = r.right - r.left, r.bottom - r.top
        if w < 2 or hgt < 2 or state["size"] == (w, hgt):
            return
        state["size"] = (w, hgt)
        d = int(2 * min(radius, w // 2, hgt // 2))
        rgn = g32.CreateRoundRectRgn(0, 0, w + 1, hgt + 1, d, d)
        u32.SetWindowRgn(h, rgn, True)          # the system owns rgn now: do not delete it

    root.bind("<Configure>", lambda e: apply() if e.widget is root else None, add="+")
    root.after(30, apply)
    return True
