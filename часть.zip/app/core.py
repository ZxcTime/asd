"""
Engine for the CS:GO (legacy, x86) skin changer. Used by gui.py or standalone:
    python core.py --offsets csgo.json --skins skins.json
    python core.py --offsets csgo.json --diag [--account 123456789]

Offsets are never hardcoded; they come from a hazedumper-style csgo.json for
YOUR build (patch it with scan_offsets.py). Everything that can be derived from the
running game is derived and validated there:
  * the local player is taken from dwLocalPlayer, else from the entity list through the
    client's local slot, else from the m_bIsLocalPlayer flag;
  * the account id comes from the owner xuid of the weapon itself;
  * the model-precache table (knife models) is searched in the live engine and accepted
    only when it yields real "models/*.mdl" strings.
Anything missing disables that feature loudly (see the log), never silently.
"""
import argparse
import hashlib
import json
import struct
import threading
import time
from array import array
from pathlib import Path

try:  # the module must import even without pymem, so the GUI can report it
    import pymem
    import pymem.exception
    import pymem.process
    PymemError = pymem.exception.PymemError
except Exception:  # noqa: BLE001  (ImportError, or no windll on a non-Windows host)
    pymem = None

    class PymemError(Exception):
        pass

import calib

CORE_SIGS = ["dwLocalPlayer", "dwEntityList", "dwClientState", "clientstate_delta_ticks"]
CORE_NETVARS = [
    "m_hMyWeapons", "m_iItemDefinitionIndex", "m_iItemIDHigh", "m_nFallbackPaintKit",
    "m_nFallbackSeed", "m_flFallbackWear", "m_nFallbackStatTrak", "m_iAccountID",
    "m_OriginalOwnerXuidLow", "m_iEntityQuality",
]
KNIFE_NETVARS = ["m_hActiveWeapon", "m_hViewModel", "m_nModelIndex"]
GLOVE_NETVARS = ["m_hMyWearables", "m_nModelIndex"]
SANITY_NETVARS = ["m_iHealth", "m_iTeamNum", "m_hOwnerEntity", "m_lifeState"]
OPTIONAL_SIGS = ["dwClientState_State", "dwClientState_GetLocalPlayer", "dwClientState_MaxPlayer",
                 "dwClientState_PlayerInfo", "m_bIsLocalPlayer", "dwGetAllClasses"]

ENTITY_STRIDE = 0x10
HANDLE_MASK = 0xFFF
WEAPON_SLOTS = 64  # m_hMyWeapons is a 64-entry handle array; a weapon can sit in any index
QUALITY_STRANGE = 9
QUALITY_UNUSUAL = 3
TICK_SLEEP = 0.005
FORCE_BUDGET = 3           # full updates per config/player; stops endless refresh loops
VERIFY_DELAY = 1.5         # seconds after a full update until the values are re-read
EQUIP_COOLDOWN = 4.0         # min seconds between automatic Q,Q re-equips
BURST_SECONDS = 3.0          # after a full update: poll every ~1 ms so our values land right after the entities are recreated
FORCE_MIN_INTERVAL = 1.0   # at most one forced full update per second
DIAG_EVERY = 5.0
CALIB_RETRY = 5.0
MP_RETRY = 5.0
DISC_RETRY = 30.0          # the client.dll scan takes seconds: not more often than this
DISC_AFTER = 3.0           # only after this long without a local player (not during loads)
FLOAT_EPS = 1e-5
SIGNON_FULL = 6
MAX_FAILED_TICKS = 150

FIELDS = [
    ("m_iItemDefinitionIndex", "short"), ("m_iItemIDHigh", "int"), ("m_iAccountID", "uint"),
    ("m_nFallbackPaintKit", "int"), ("m_nFallbackSeed", "int"), ("m_flFallbackWear", "float"),
    ("m_nFallbackStatTrak", "int"), ("m_iEntityQuality", "int"),
    ("m_OriginalOwnerXuidLow", "uint"),
]

# search grid for the modelprecache string table (validated by real model names)
MP_TABLE_WINDOW = range(0x5000, 0x5400, 4)   # pointer slots inside CClientState
MP_NSD = (0x38, 0x3C, 0x40, 0x44, 0x48)
MP_NSDI = (0x8, 0xC, 0x10)
MP_FIRST = (0x0, 0xC, 0x10)
MP_STRIDE = (0x30, 0x34, 0x38)
MP_COUNT = 1024
MP_MIN_MODELS = 30


def plausible(p: int) -> bool:
    # csgo.exe is 32-bit; with 4 GB address space (large-address-aware) heap objects can sit above 2 GB
    return 0x10000 <= p < 0xFFFF0000


# ----------------------------------------------------------------- loading
def load_offsets(path, need_knife=False, need_gloves=False):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise ValueError(f"cannot read offsets file {path!r}: {e}")
    sigs, nets = data.get("signatures", {}), data.get("netvars", {})
    req_nets = list(CORE_NETVARS)
    if need_knife:
        req_nets += KNIFE_NETVARS
    if need_gloves:
        req_nets += GLOVE_NETVARS
    missing = [k for k in CORE_SIGS if k not in sigs] + [k for k in req_nets if k not in nets]
    if missing:
        raise ValueError("offsets file is missing: " + ", ".join(sorted(set(missing))))
    off = {k: sigs[k] for k in CORE_SIGS}
    for k in OPTIONAL_SIGS:
        if isinstance(sigs.get(k), int):
            off[k] = sigs[k]
    # optional knife/glove/sanity netvars are kept when present; features turn off if absent
    off.update({k: nets[k] for k in set(CORE_NETVARS + KNIFE_NETVARS + GLOVE_NETVARS + SANITY_NETVARS)
                if k in nets})
    for k, v in off.items():
        if not isinstance(v, int) or isinstance(v, bool) or not (0 < v < 0x10000000):
            raise ValueError(f"implausible offset {k}={v!r}")
    mp = data.get("model_precache")
    if mp is not None:
        ok = (isinstance(mp.get("steps"), list) and mp["steps"]
              and all(isinstance(x, int) and 0 <= x < 0x100000 for x in mp["steps"])
              and all(isinstance(mp.get(k), int) for k in ("first", "stride", "count")))
        if not ok:
            raise ValueError("model_precache section is malformed")
    off["model_precache"] = mp
    return off


class LiveConfig:
    """Thread-safe holder: the GUI swaps in a new validated config while the engine runs."""

    def __init__(self, raw):
        self._lock = threading.Lock()
        self._cfg = normalize_config(raw)
        self._refresh = 0

    def request_refresh(self):
        with self._lock:
            self._refresh += 1

    def refresh_seq(self):
        with self._lock:
            return self._refresh

    def update(self, raw):
        cfg = normalize_config(raw)  # raises before anything is replaced
        with self._lock:
            self._cfg = cfg

    def get(self):
        with self._lock:
            return self._cfg


def normalize_config(raw):
    acct = int(raw.get("account_id", 0) or 0)
    if not 0 <= acct < 2 ** 32:
        raise ValueError(f"account_id out of range: {acct}")
    cfg = {
        "account_id": acct,
        "expected_client_sha256": raw.get("expected_client_sha256", "") or "",
        "knife_ids": {int(x) for x in raw.get("knife_ids", [])},
        "skins": {}, "knife": None, "gloves": None, "agent": None,
        "agents": {"T": None, "CT": None},
        "auto_reequip": bool(raw.get("auto_reequip", False)),
    }
    for key, s in raw.get("skins", {}).items():
        cfg["skins"][int(key)] = _skin(s)
    if raw.get("knife"):
        cfg["knife"] = _skin(raw["knife"], allow_zero_paint=True)
        cfg["knife"]["defidx"] = int(raw["knife"]["defidx"])
        cfg["knife"]["model"] = raw["knife"].get("model")
    if raw.get("gloves"):
        cfg["gloves"] = _skin(raw["gloves"])
        cfg["gloves"]["defidx"] = int(raw["gloves"]["defidx"])
        cfg["gloves"]["model"] = raw["gloves"].get("model")
    def _agent(a, team):
        e = {"defidx": int(a["defidx"]), "model": str(a.get("model") or ""),
             "name": str(a.get("name") or ""), "team": team}
        if e["defidx"] <= 0 or not e["model"]:
            raise ValueError("invalid agent entry")
        return e

    agents = raw.get("agents")
    if isinstance(agents, dict):
        for team in ("T", "CT"):
            a = agents.get(team)
            if isinstance(a, dict):
                cfg["agents"][team] = _agent(a, team)
    else:
        a = raw.get("agent")
        if isinstance(a, dict):
            team = "CT" if str(a.get("team", "")).upper() == "CT" else "T"
            cfg["agents"][team] = _agent(a, team)
    cfg["agent"] = cfg["agents"].get("CT") or cfg["agents"].get("T")
    if cfg["knife"] and not cfg["knife_ids"]:
        raise ValueError("knife selected but knife_ids is empty")
    return cfg


def _skin(s, allow_zero_paint=False):
    paint, wear, seed = int(s["paint_kit"]), float(s.get("wear", 0.0001)), int(s.get("seed", 0))
    if (paint < 0 or (paint == 0 and not allow_zero_paint)
            or not 0.0 <= wear <= 1.0 or not 0 <= seed <= 100000):
        raise ValueError(f"invalid skin entry: {s}")
    st = [0] * 5
    raw_st = s.get("stickers") or []
    if isinstance(raw_st, (list, tuple)):
        for i, v in enumerate(raw_st[:5]):
            try:
                st[i] = max(0, min(100000, int(v)))
            except (TypeError, ValueError):
                pass
    return {"paint": paint, "wear": wear, "seed": seed, "stat": int(s.get("stattrak", -1)),
            "stickers": st}


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ------------------------------------------------------- model precache search
def _model_names(pm, base, first, stride, count=MP_COUNT, limit=None):
    """{index: name} for entries whose string looks like 'models/....mdl'."""
    out = {}
    for i in range(limit or count):
        try:
            sp = pm.read_uint(base + first + i * stride)
        except PymemError:
            break
        if not plausible(sp):
            continue
        try:
            s = pm.read_string(sp, 128).split("\x00")[0]
        except (PymemError, UnicodeDecodeError):
            continue
        if s.startswith("models/") and s.endswith(".mdl"):
            out[i] = s
    return out


def find_model_precache(pm, engine_base, o):
    """Searches CClientState for the 'modelprecache' string table. Returns the same dict shape
    as the optional "model_precache" file section, or None. A candidate counts only when it
    yields >= MP_MIN_MODELS distinct 'models/*.mdl' strings; the best one must be unique."""
    cs = pm.read_uint(engine_base + o["dwClientState"])
    if not plausible(cs):
        return None
    found = []
    for k in MP_TABLE_WINDOW:
        try:
            tbl = pm.read_uint(cs + k)
        except PymemError:
            continue
        if not plausible(tbl):
            continue
        for a in MP_NSD:
            try:
                nsd = pm.read_uint(tbl + a)
            except PymemError:
                continue
            if not plausible(nsd):
                continue
            for b in MP_NSDI:
                try:
                    nsdi = pm.read_uint(nsd + b)
                except PymemError:
                    continue
                if not plausible(nsdi):
                    continue
                for first in MP_FIRST:
                    for stride in MP_STRIDE:
                        if len(_model_names(pm, nsdi, first, stride, limit=64)) < 5:
                            continue
                        names = _model_names(pm, nsdi, first, stride)
                        if len(names) >= MP_MIN_MODELS:
                            found.append((len(names), k, a, b, first, stride))
    if not found:
        return None
    found.sort(reverse=True)
    best = found[0]
    _, k, a, b, first, stride = best
    return {"steps": [k, a, b], "first": first, "stride": stride, "count": MP_COUNT,
            "models": best[0]}


# ------------------------------------------------ re-equip helper (keyboard, Windows only)
def csgo_foreground(pid):
    """True only when the foreground window belongs to the game process (keys never leak elsewhere)."""
    try:
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        p = wintypes.DWORD()
        u.GetWindowThreadProcessId(u.GetForegroundWindow(), ctypes.byref(p))
        return bool(pid) and p.value == pid
    except Exception:  # noqa: BLE001
        return False


def tap_key(scan):
    """Press and release one key by scan code (0x10 = Q) with SendInput."""
    import ctypes
    from ctypes import wintypes

    class KI(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]

    class MI(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]

    class U(ctypes.Union):
        _fields_ = [("ki", KI), ("mi", MI)]

    class INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("u", U)]

    def send(flags):
        i = INPUT(1, U(ki=KI(0, scan, 0x0008 | flags, 0, 0)))   # KEYEVENTF_SCANCODE
        ctypes.windll.user32.SendInput(1, ctypes.byref(i), ctypes.sizeof(INPUT))

    send(0)
    time.sleep(0.04)
    send(0x0002)   # KEYEVENTF_KEYUP


# ----------------------------------------- netvar offsets from the game's own RecvTables
# x86 layouts: ClientClass{name@8, table@0xC, next@0x10}  RecvTable{props@0, count@4, name@0xC}
# RecvProp (0x3C bytes){name@0, table@0x28, offset@0x2C}
CC_NAME, CC_TABLE, CC_NEXT = 0x8, 0xC, 0x10
RT_PROPS, RT_COUNT = 0x0, 0x4
RP_NAME, RP_TABLE, RP_OFFSET, RP_SIZE = 0x0, 0x28, 0x2C, 0x3C


def _cstr(pm, a, n=64):
    if not plausible(a):
        return ""
    try:
        return pm.read_string(a, n).split("\x00")[0]
    except (PymemError, UnicodeDecodeError):
        return ""


def _table_offset(pm, table, prop, depth=0):
    """Offset of `prop` in a RecvTable, summed through sub-tables like a netvar dumper does."""
    if depth > 8 or not plausible(table):
        return None
    props, n = pm.read_uint(table + RT_PROPS), pm.read_int(table + RT_COUNT)
    if not plausible(props) or not 0 < n < 4096:
        return None
    for i in range(n):
        a = props + i * RP_SIZE
        off = pm.read_int(a + RP_OFFSET)
        if _cstr(pm, pm.read_uint(a + RP_NAME)) == prop:
            return off
        sub = pm.read_uint(a + RP_TABLE)
        if plausible(sub):
            r = _table_offset(pm, sub, prop, depth + 1)
            if r is not None:
                return off + r
    return None


def resolve_netvar(pm, head, cls, prop):
    """head = ClientClass* list head. -> offset of cls.prop or None."""
    c, guard = head, 0
    while plausible(c) and guard < 1024:
        if _cstr(pm, pm.read_uint(c + CC_NAME)) == cls:
            return _table_offset(pm, pm.read_uint(c + CC_TABLE), prop)
        c, guard = pm.read_uint(c + CC_NEXT), guard + 1
    return None


# ------------------------------------------- entity list search without any offset
def read_image(pm, base, size, chunk=0x400000):
    """Whole module image; unreadable pages become zeros (client.dll has a huge .bss)."""
    out = bytearray()
    for off in range(0, size, chunk):
        n = min(chunk, size - off)
        try:
            out += pm.read_bytes(base + off, n)
        except PymemError:
            for po in range(0, n, 0x1000):
                m = min(0x1000, n - po)
                try:
                    out += pm.read_bytes(base + off + po, m)
                except PymemError:
                    out += bytes(m)
    return bytes(out)


def discover_entity_list(pm, client_base, client_size, o, slot=None):
    """Finds the entity list in the RUNNING game, trusting neither dwEntityList nor dwLocalPlayer.

    Evidence chain (all of it must hold for a layout to be accepted):
      1. an entity-list entry is {entity*, serial, prev, next}: serial is small, the links are 0 or
         point back into the image;
      2. the entity's first dword (vtable) lies inside client.dll and it reads as a player
         (team 1..3, health 0..500);
      3. for a hypothesised entity index i the list base is T = entry - i*0x10, and EVERY weapon
         handle in the object's m_hMyWeapons must resolve through T to an entity whose
         m_hOwnerEntity points back to index i.
    Returns {"entity_list_rel", "players", "local"} (local may be None) or None.
    entity_list_rel is in the engine's convention: the address of the entry of entity index 1."""
    need = ("m_hOwnerEntity", "m_hMyWeapons", "m_iTeamNum", "m_iHealth")
    if any(k not in o for k in need) or not client_size:
        return None
    raw = read_image(pm, client_base, client_size)
    n = len(raw) // 4
    a = array("I")
    a.frombytes(raw[:n * 4])
    if a.itemsize != 4:  # pragma: no cover  (never on the Windows builds this targets)
        return None
    hi = client_base + n * 4
    cands = []
    for i in range(n - 3):
        s = a[i + 1]
        if not 0 < s < 0x8000:
            continue
        p = a[i]
        if p < 0x10000 or p >= 0xFFFF0000:
            continue
        pv, nx = a[i + 2], a[i + 3]
        if (pv and not client_base <= pv < hi) or (nx and not client_base <= nx < hi):
            continue
        cands.append((client_base + i * 4, p))
    del a, raw

    players = []
    for ea, p in cands:
        try:
            vt = pm.read_uint(p)
            if not client_base <= vt < hi:
                continue
            team, hp = pm.read_int(p + o["m_iTeamNum"]), pm.read_int(p + o["m_iHealth"])
        except PymemError:
            continue
        if team in (1, 2, 3) and 0 <= hp <= 500:
            players.append((ea, p))

    found = []
    for ea, p in players:
        try:
            hs = [pm.read_uint(p + o["m_hMyWeapons"] + 4 * k) for k in range(WEAPON_SLOTS)]
        except PymemError:
            continue
        hs = [h for h in hs if h not in (0, 0xFFFFFFFF) and (h & HANDLE_MASK)]
        if not hs or len(hs) > 40:
            continue
        for idx in range(1, 65):
            t = ea - idx * ENTITY_STRIDE
            ok = True
            for h in hs:
                try:
                    w = pm.read_uint(t + (h & HANDLE_MASK) * ENTITY_STRIDE)
                    if not plausible(w) or (pm.read_uint(w + o["m_hOwnerEntity"]) & HANDLE_MASK) != idx:
                        ok = False
                        break
                except PymemError:
                    ok = False
                    break
            if ok:
                found.append({"t": t, "idx": idx, "ptr": p, "weapons": len(hs)})
                break
    if not found:
        return None
    counts = {}
    for f in found:
        counts[f["t"]] = counts.get(f["t"], 0) + 1
    best_t = max(counts, key=lambda k: counts[k])
    mine = [f for f in found if f["t"] == best_t]
    local = None
    if slot is not None and 0 <= slot < 64:
        local = next((f for f in mine if f["idx"] == slot + 1), None)
    flag = o.get("m_bIsLocalPlayer")
    if local is None and flag is not None:
        for f in mine:
            try:
                if pm.read_bytes(f["ptr"] + flag, 1)[0] == 1:
                    local = f
                    break
            except PymemError:
                continue
    return {"entity_list_rel": best_t + ENTITY_STRIDE - client_base, "players": mine, "local": local}


def patch_offsets_file(path, updates):
    """Writes validated values into the offsets file; the first original is kept as .bak."""
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    data = json.loads(text)
    bak = p.with_suffix(p.suffix + ".bak")
    if not bak.exists():
        bak.write_text(text, encoding="utf-8")
    data.setdefault("signatures", {}).update(updates)
    p.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ------------------------------------------------------------------ engine
class Engine:
    def __init__(self, pm, client, engine, off, live, log=print, client_size=0):
        self.pm, self.client, self.engine = pm, client, engine
        self.client_size = client_size
        self._disc_t = -1e9
        self._noplayer_since = None
        self.o, self.live, self.log = off, live, log
        self.cfg = live.get()
        self.originals = {}      # addr -> {"vals", "expect", "key"}
        self.applied = {}        # addr -> signature we last wrote there
        self.forced_sig = {}     # key -> signature a full update was already sent for (NOT per address:
                                 # our own full update recreates entities at new addresses)
        self.model_cache = {}
        self.warned = set()
        self.last_lp = 0
        self.has_knife = all(k in off for k in KNIFE_NETVARS)
        self.has_gloves = all(k in off for k in GLOVE_NETVARS)
        self.pending_force = False
        self.last_force = -1e9
        self.list_delta = 0      # corrects a stale dwEntityList (found at runtime)
        self.list_ok = False
        self._calib_t = -1e9
        self.mp = off.get("model_precache")
        self.kx, self._kx_t, self._kd_t = None, -1e9, -1e9
        self._equip_at, self._equip_last, self._equip_busy, self.last_fresh = None, -1e9, False, False   # knife view/world model netvars
        self._mp_t = -1e9
        self.stats = {"writes": 0, "reverts": 0, "forced": 0}
        self._diag_t = -1e9
        self._status_key = None
        self.lp_method = None
        self.force_budget = FORCE_BUDGET
        self._refresh_seen = live.refresh_seq()
        self._verify = None
        self.now = time.monotonic

    def _warn_once(self, key, msg):
        if key not in self.warned:
            self.warned.add(key)
            self.log("[warn] " + msg)

    def _status(self, key, msg):
        if key != self._status_key:
            self._status_key = key
            self.log(msg)

    # -- memory helpers
    def _r(self, kind, a):
        return {"int": self.pm.read_int, "uint": self.pm.read_uint, "short": self.pm.read_short,
                "float": self.pm.read_float}[kind](a)

    def _w(self, kind, a, v):
        {"int": self.pm.write_int, "uint": self.pm.write_uint, "short": self.pm.write_short,
         "float": self.pm.write_float}[kind](a, v)

    def _u32(self, a):
        """Tolerant read: 0 instead of an exception (used where 'not there' is a valid answer)."""
        try:
            return self.pm.read_uint(a)
        except PymemError:
            return 0

    def entity(self, handle):
        # dwEntityList points at the entry of entity index 1, hence the "- 1"
        if handle in (0, 0xFFFFFFFF) or (handle & HANDLE_MASK) == 0:
            return 0
        a = self._u32(self.client + self.o["dwEntityList"] + self.list_delta
                      + ((handle & HANDLE_MASK) - 1) * ENTITY_STRIDE)
        return a if plausible(a) else 0

    def _handles(self, p):
        """The 64 m_hMyWeapons handles of player object p in ONE read."""
        try:
            raw = self.pm.read_bytes(p + self.o["m_hMyWeapons"], WEAPON_SLOTS * 4)
        except PymemError:
            return []
        return list(struct.unpack("<%dI" % WEAPON_SLOTS, raw))

    def _verified(self, p):
        """True when every weapon of p says 'I belong to entity i' and the list maps i back to p."""
        o = self.o
        if "m_hOwnerEntity" not in o:
            return False
        hs = [h for h in self._handles(p) if h not in (0, 0xFFFFFFFF) and (h & HANDLE_MASK)]
        if not hs:
            return False
        idxs = set()
        for h in hs:
            w = self.entity(h)
            if not w:
                return False
            idxs.add(self._u32(w + o["m_hOwnerEntity"]) & HANDLE_MASK)
        if len(idxs) != 1:
            return False
        idx = idxs.pop()
        return idx != 0 and self.entity_at(idx - 1) == p

    def entity_at(self, pos):
        """Entity pointer stored at array position `pos` (entity index pos + 1)."""
        a = self._u32(self.client + self.o["dwEntityList"] + self.list_delta + pos * ENTITY_STRIDE)
        return a if plausible(a) else 0

    def player_info(self, p):
        """(team, health, lifeState or None) or None when the memory is not readable."""
        o = self.o
        if not plausible(p) or "m_iTeamNum" not in o or "m_iHealth" not in o:
            return None
        try:
            team, hp = self.pm.read_int(p + o["m_iTeamNum"]), self.pm.read_int(p + o["m_iHealth"])
        except PymemError:
            return None
        life = None
        if "m_lifeState" in o:
            try:
                life = self.pm.read_bytes(p + o["m_lifeState"], 1)[0]
            except PymemError:
                life = None
        return team, hp, life

    def _looks_like_player(self, p):
        o = self.o
        if not plausible(p):
            return False
        if "m_iTeamNum" not in o or "m_iHealth" not in o:
            return True
        info = self.player_info(p)
        return bool(info) and info[0] in (1, 2, 3) and 0 <= info[1] <= 500

    def signon_state(self):
        o = self.o
        if "dwClientState_State" not in o:
            return None
        cs = self._u32(self.engine + o["dwClientState"])
        if not plausible(cs):
            return None
        try:
            return self.pm.read_int(cs + o["dwClientState_State"])
        except PymemError:
            return None

    def local_slot(self):
        o = self.o
        if "dwClientState_GetLocalPlayer" not in o:
            return None
        cs = self._u32(self.engine + o["dwClientState"])
        if not plausible(cs):
            return None
        try:
            return self.pm.read_int(cs + o["dwClientState_GetLocalPlayer"])
        except PymemError:
            return None

    def flagged_local(self):
        """Entity of the list whose m_bIsLocalPlayer byte is 1 (third, independent way)."""
        off = self.o.get("m_bIsLocalPlayer")
        if off is None:
            return 0
        for i in range(64):
            e = self.entity_at(i)
            if not e or not self._looks_like_player(e):
                continue
            try:
                if self.pm.read_bytes(e + off, 1)[0] == 1:
                    return e
            except PymemError:
                continue
        return 0

    def local_candidates(self):
        """[(method, pointer)] for every method that currently yields a player-like object."""
        o, out = self.o, []
        direct = self._u32(self.client + o["dwLocalPlayer"])
        if self._looks_like_player(direct):
            out.append(("dwLocalPlayer", direct))
        slot = self.local_slot()
        if slot is not None and 0 <= slot < 64:
            via = self.entity_at(slot)
            if via and self._looks_like_player(via):
                flag = self.o.get("m_bIsLocalPlayer")
                if flag is not None:
                    # the slot says "you", the object itself may say "not me" (wrong list convention)
                    try:
                        mine = self.pm.read_bytes(via + flag, 1)[0] == 1
                    except PymemError:
                        mine = True
                    if not mine:
                        f = self.flagged_local()
                        via = f or via
                out.append(("entity-list[slot]", via))
        return out

    def _discover(self):
        """Searches client.dll for the entity list when no player can be found with the file's
        offsets. Slow (seconds): rate-limited, and only after a few seconds without a player."""
        now = self.now()
        if not self.client_size:
            return False
        if self._noplayer_since is None:
            self._noplayer_since = now
        if now - self._noplayer_since < DISC_AFTER or now - self._disc_t < DISC_RETRY:
            return False
        self._disc_t = now
        self.log("[discover] игрока нет по оффсетам из файла: ищу entity list прямо в client.dll "
                 "(несколько секунд) ...")
        try:
            res = discover_entity_list(self.pm, self.client, self.client_size, self.o, self.local_slot())
        except PymemError as e:
            self.log(f"[discover] ошибка чтения памяти: {e}")
            return False
        if not res:
            self.log("[discover] игроков с оружием не найдено: ты в меню/не заспавнился "
                     "(повторю через 30 с) или netvar-оффсеты не от этой сборки")
            return False
        rel = res["entity_list_rel"]
        self.list_delta, self.list_ok = rel - self.o["dwEntityList"], True
        loc = res["local"]
        self.log(f"[discover] entity list найден: client+{rel} ({rel:#x}), в файле "
                 f"{self.o['dwEntityList']} ({self.o['dwEntityList']:#x}), сдвиг {self.list_delta:+#x}; "
                 f"игроков с проверенным оружием: {len(res['players'])}; "
                 + (f"ты = entity {loc['idx']} ({loc['ptr']:#x})" if loc else "тебя среди них не определил"))
        return True

    def local_player(self):
        """dwLocalPlayer wins whenever it points at a player. When it reads 0 (stale offset)
        the entity list + the client's own slot is used, then the m_bIsLocalPlayer flag, so a
        drifted dwLocalPlayer alone no longer disables the changer."""
        cands = self.local_candidates()
        if not cands:
            e = self.flagged_local()
            if e:
                cands = [("m_bIsLocalPlayer", e)]
        if not cands:
            self.lp_method = None
            return 0
        method, p = cands[0]
        if len(cands) > 1 and cands[1][1] != p:
            first = cands[0]
            for m, c in cands:
                if self._verified(c):
                    method, p = m, c
                    break
            self._warn_once("lpmis", f"{first[0]}={first[1]:#x} but {cands[1][0]}={cands[1][1]:#x}: "
                                     f"using {method} ({p:#x}), the one whose weapons point back to it")
        self.lp_method = method
        if method != "dwLocalPlayer":
            self._warn_once("lp:" + method, f"dwLocalPlayer does not give a player; the local player "
                                            f"({p:#x}) was found via {method}. The offset in the file "
                                            "is stale but the changer works anyway")
        return p

    def _ensure_list(self, lp):
        """Verifies the entity list base with the player's own weapons; if it does not hold,
        searches for the real base (retried every few seconds, never blocks applying)."""
        if self.list_ok:
            return
        o = self.o
        handles = [self._u32(lp + o["m_hMyWeapons"] + 4 * i) for i in range(WEAPON_SLOTS)]
        slot = self.local_slot()
        base = self.client + o["dwEntityList"]
        if calib.check_current(self.pm, base + self.list_delta, slot, handles, o):
            self.list_ok = True
            return
        if self.now() - self._calib_t < CALIB_RETRY:
            return
        self._calib_t = self.now()
        res = calib.find_entity_list(self.pm, base, lp, slot, handles, o)
        if res:
            self.list_delta, self.list_ok = res["delta"], True
            new = o["dwEntityList"] + res["delta"]
            self.log(f"[calib] dwEntityList in the file is stale; the real one is {new} ({new:#x}) "
                     f"= file {res['delta']:+#x}. Using it. Weapons: "
                     + ", ".join(f"defidx={d}" for _, _, d in res["weapons"]))
        else:
            self._warn_once("calib", "could not verify the entity list (no weapon of yours points "
                                     "back to you). Is dwEntityList stale? Press Диагностика")

    def force_full_update(self):
        cs = self.pm.read_uint(self.engine + self.o["dwClientState"])
        if plausible(cs):
            self.pm.write_int(cs + self.o["clientstate_delta_ticks"], -1)

    def snapshot(self, addr, expect, key):
        if addr not in self.originals:
            vals = {n: (k, self._r(k, addr + self.o[n])) for n, k in FIELDS}
            self.originals[addr] = {"vals": vals, "expect": expect, "key": key}
        self.originals[addr]["expect"] = expect

    def put(self, addr, defidx, skin, account, quality):
        o = self.o
        self._w("short", addr + o["m_iItemDefinitionIndex"], defidx)
        self._w("int", addr + o["m_iItemIDHigh"], -1)
        self._w("uint", addr + o["m_iAccountID"], account)
        # the client shows a fallback skin only when the item's account id equals the weapon's
        # original owner; offline/bot weapons often have owner 0, so make them equal
        self._w("uint", addr + o["m_OriginalOwnerXuidLow"], account)
        self._w("int", addr + o["m_nFallbackPaintKit"], skin["paint"])
        self._w("int", addr + o["m_nFallbackSeed"], skin["seed"])
        self._w("float", addr + o["m_flFallbackWear"], skin["wear"])
        if skin["stat"] >= 0:
            self._w("int", addr + o["m_nFallbackStatTrak"], skin["stat"])
        self._w("int", addr + o["m_iEntityQuality"], quality)

    def _matches(self, a, defidx, skin, account, quality):
        o, r = self.o, self._r
        return (r("short", a + o["m_iItemDefinitionIndex"]) == defidx
                and r("int", a + o["m_iItemIDHigh"]) == -1
                and r("uint", a + o["m_iAccountID"]) == account
                and r("uint", a + o["m_OriginalOwnerXuidLow"]) == account
                and r("int", a + o["m_nFallbackPaintKit"]) == skin["paint"]
                and r("int", a + o["m_nFallbackSeed"]) == skin["seed"]
                and abs(r("float", a + o["m_flFallbackWear"]) - skin["wear"]) <= FLOAT_EPS
                and (skin["stat"] < 0 or r("int", a + o["m_nFallbackStatTrak"]) == skin["stat"])
                and r("int", a + o["m_iEntityQuality"]) == quality)

    def account_for(self, addr):
        """The game compares the item's account id with the weapon's own original owner, so the
        owner xuid of the weapon is the value that always matches. The configured Account ID is
        only used when the weapon has no owner (knife, wearables, offline defaults)."""
        owner = self.pm.read_uint(addr + self.o["m_OriginalOwnerXuidLow"])
        cfg = self.cfg["account_id"]
        if owner:
            if cfg and cfg != owner:
                self._warn_once("acctmis", f"Account ID in the window ({cfg}) differs from the owner "
                                           f"xuid of your weapon ({owner}); using {owner}")
            return owner
        return cfg

    def _apply(self, addr, key, defidx, skin, quality):
        """Writes the skin if ANY field differs. Forces a full update only for a NEW
        (entity, skin) combination; if the game reverts our values we silently rewrite them
        and count it, instead of triggering a full update on every tick."""
        acct = self.account_for(addr)
        if acct == 0:
            self._warn_once("acct", "weapon has no owner xuid and Account ID is 0: put your Account ID "
                                    "(Steam/userdata/<number>) into the window")
            return False
        q = QUALITY_STRANGE if skin["stat"] >= 0 else quality
        if self._matches(addr, defidx, skin, acct, q):
            return False
        owner_was = self.pm.read_uint(addr + self.o["m_OriginalOwnerXuidLow"])
        sig = (defidx, skin["paint"], skin["wear"], skin["seed"], skin["stat"], acct)
        self.last_fresh = self.applied.get(addr) != sig   # False = the game only reverted our values
        if self.applied.get(addr) == sig:
            self.stats["reverts"] += 1
        elif self.forced_sig.get(key) == sig:
            self.stats["reverts"] += 1  # entity recreated by the game/our own full update: rewrite only,
                                        # forcing again would recreate it again (endless loop)
        else:
            self.forced_sig[key] = sig
            self.pending_force = True
            self.log(f"[apply] {addr:#x} defidx={defidx} paint={skin['paint']} wear={skin['wear']} "
                     f"seed={skin['seed']} stattrak={skin['stat']} account={acct} owner_was={owner_was}")
        self.snapshot(addr, defidx, key)
        self.put(addr, defidx, skin, acct, q)
        self.applied[addr] = sig
        self.stats["writes"] += 1
        if not self._matches(addr, defidx, skin, acct, q):
            self._warn_once("verify", f"wrote the skin to {addr:#x} but reading it back gives other "
                                      "values: wrong netvar offsets or something rewrites them")
        return True

    # -- model index through the modelprecache string table
    def _ensure_mp(self):
        if self.mp:
            return True
        if self.now() - self._mp_t < MP_RETRY:
            return False
        self._mp_t = self.now()
        try:
            mp = find_model_precache(self.pm, self.engine, self.o)
        except PymemError:
            mp = None
        if mp:
            self.mp = mp
            self.log(f"[model] modelprecache table found in the running game: steps="
                     f"{[hex(s) for s in mp['steps']]} first={mp['first']:#x} stride={mp['stride']:#x} "
                     f"({mp['models']} models)")
            return True
        self._warn_once("nomp", "model_precache table not found (need to be in a loaded map): knife/"
                                "glove MODELS cannot be changed, a skin on your current knife still applies")
        return False

    def model_index(self, path):
        if not path:
            return None
        if path in self.model_cache:
            return self.model_cache[path]
        if not self._ensure_mp():
            return None
        mp = self.mp
        ptr = self._u32(self.engine + self.o["dwClientState"])
        for step in mp["steps"]:
            if not plausible(ptr):
                return None
            ptr = self._u32(ptr + step)
        if not plausible(ptr):
            return None
        for i in range(mp["count"]):
            sp = self._u32(ptr + mp["first"] + i * mp["stride"])
            if not plausible(sp):
                continue
            try:
                s = self.pm.read_string(sp, 128).split("\x00")[0]
            except (PymemError, UnicodeDecodeError):
                continue
            if s == path:
                self.model_cache[path] = i
                return i
        return None

    def knife_netvars(self):
        """m_iViewModelIndex / m_iWorldModelIndex of the knife entity, read from the game's own
        RecvTables (they are not in hazedumper files). None until resolved."""
        if self.kx is not None:
            return self.kx
        if self.now() - self._kx_t < MP_RETRY or "dwGetAllClasses" not in self.o:
            return None
        self._kx_t = self.now()
        try:
            head = self.pm.read_uint(self.client + self.o["dwGetAllClasses"])
            vi = resolve_netvar(self.pm, head, "CKnife", "m_iViewModelIndex")
            wi = resolve_netvar(self.pm, head, "CKnife", "m_iWorldModelIndex")
        except PymemError:
            vi = wi = None
        if vi and wi and 0 < vi < 0x10000 and 0 < wi < 0x10000:
            self.kx = {"view": vi, "world": wi}
            self.log(f"[knife] m_iViewModelIndex={vi:#x} m_iWorldModelIndex={wi:#x} (from the game's "
                     "own RecvTables)")
            return self.kx
        self._warn_once("nokx", "could not read m_iViewModelIndex/m_iWorldModelIndex from the game "
                                "(dwGetAllClasses stale?): only the viewmodel entity is switched")
        return None

    def _set_int(self, a, v):
        if self._r("int", a) != v:
            self._w("int", a, v)

    def apply_knife(self, w, defidx):
        k, o = self.cfg["knife"], self.o
        target = k["defidx"]
        mi = self.model_index(k.get("model"))
        if target != defidx and mi is None:
            # Changing the definition index without the matching model index gives a broken
            # knife, so keep the type and only apply the skin until the model index is known.
            self._warn_once("knifetype", "knife model index unavailable yet: the knife TYPE is not "
                                         "changed (skin goes onto your current knife)")
            target = defidx
        changed = self._apply(w, ("knife",), target, k, QUALITY_UNUSUAL)
        if mi is not None and target == k["defidx"]:
            self._set_int(w + o["m_nModelIndex"], mi)
            kx = self.knife_netvars()
            if kx:
                self._set_int(w + kx["view"], mi)
                path = k.get("model") or ""
                wmi = self.model_index(path.replace("/v_", "/w_", 1)) if "/v_" in path else None
                if wmi is not None:
                    self._set_int(w + kx["world"], wmi)
        return changed

    def apply_knife_viewmodel(self, lp):
        k, o = self.cfg["knife"], self.o
        mi = self.model_index(k.get("model"))
        if mi is None:
            return
        aw = self.entity(self._u32(lp + o["m_hActiveWeapon"]))
        if not aw or self._r("short", aw + o["m_iItemDefinitionIndex"]) != k["defidx"]:
            return
        for i in range(2):  # the player has two viewmodel slots
            vm = self.entity(self._u32(lp + o["m_hViewModel"] + 4 * i))
            if vm:
                self._set_int(vm + o["m_nModelIndex"], mi)

    def _knife_diag(self, lp):
        """One line every 5 s while a knife is selected: shows exactly which link is missing."""
        if self.now() - self._kd_t < 5.0:
            return
        self._kd_t = self.now()
        k, o = self.cfg["knife"], self.o
        mi = self.model_index(k.get("model"))
        aw = self.entity(self._u32(lp + o["m_hActiveWeapon"]))
        vm = self.entity(self._u32(lp + o["m_hViewModel"]))
        self.log(f"[knife] want defidx={k['defidx']} model={k.get('model')} | model_index={mi} "
                 f"(precache table {'found' if self.mp else 'NOT found'}) | active weapon defidx="
                 f"{self._r('short', aw + o['m_iItemDefinitionIndex']) if aw else None} | viewmodel "
                 f"model index={self._r('int', vm + o['m_nModelIndex']) if vm else None}")

    def apply_gloves(self, lp):
        g, o = self.cfg["gloves"], self.o
        ent = self.entity(self._u32(lp + o["m_hMyWearables"]))
        if not ent:
            raw = [self._u32(lp + o["m_hMyWearables"] + 4 * i) for i in range(3)]
            self._warn_once("nogl", "gloves: your player has no wearable entity (m_hMyWearables raw="
                                    f"{[hex(x) for x in raw]}); an external program cannot create one, "
                                    "gloves stay unchanged")
            return False
        changed = self._apply(ent, ("gloves",), g["defidx"], g, QUALITY_UNUSUAL)
        mi = self.model_index(g.get("model"))
        if mi is not None and self._r("int", ent + o["m_nModelIndex"]) != mi:
            self._w("int", ent + o["m_nModelIndex"], mi)
        return changed

    # -- bookkeeping
    @staticmethod
    def _wanted(key, cfg):
        if key[0] == "skin":
            return key[1] in cfg["skins"]
        return bool(cfg.get(key[0]))

    def _restore_one(self, addr, rec):
        o = self.o
        try:
            if self._r("short", addr + o["m_iItemDefinitionIndex"]) != rec["expect"]:
                return False
            for n, (k, v) in rec["vals"].items():
                self._w(k, addr + o[n], v)
            return True
        except PymemError:
            return False

    def _on_config_change(self, cfg):
        """The GUI changed something: forget signatures (so new values force an update) and
        put back weapons whose skin was removed."""
        self.cfg = cfg
        self.applied.clear()
        self.force_budget = FORCE_BUDGET
        for addr, rec in list(self.originals.items()):
            if not self._wanted(rec["key"], cfg):
                if self._restore_one(addr, rec):
                    self.pending_force = True
                del self.originals[addr]

    def _diag(self, lp, state, seen):
        now = self.now()
        if now - self._diag_t < DIAG_EVERY:
            return
        self._diag_t = now
        ws = " ".join(f"{s}:{d}:{p}:{h}" for s, d, p, h in seen) or "none"
        self.log(f"[diag] state={state} lp={lp:#x} via={self.lp_method} list_delta={self.list_delta:+#x} "
                 f"weapons(slot:defidx:paint:idhigh)={ws} wanted={sorted(self.cfg['skins'])} "
                 f"writes={self.stats['writes']} reverts={self.stats['reverts']} "
                 f"forced={self.stats['forced']}")

    # -- main loop body
    def tick(self):
        o = self.o
        cfg = self.live.get()
        if cfg is not self.cfg:
            self._on_config_change(cfg)
        cfg = self.cfg
        use_knife, use_gloves = bool(cfg["knife"]), bool(cfg["gloves"])
        if use_knife and not self.has_knife:
            self._warn_once("nok", "offsets file lacks knife netvars: knife disabled")
            use_knife = False
        if use_gloves and not self.has_gloves:
            self._warn_once("nog", "offsets file lacks glove netvars: gloves disabled")
            use_gloves = False
        state = self.signon_state()
        lp = self.local_player()
        if not plausible(lp) and (state is None or state == SIGNON_FULL):
            if self._discover():
                lp = self.local_player()
        if plausible(lp):
            self._noplayer_since = None
        if not plausible(lp):
            if state is not None and state != SIGNON_FULL:
                self._status("nogame", f"[state] signon={state}: ты не в игре (меню/загрузка). "
                                       "Зайди в матч с ботами")
            else:
                self._status("noplayer", "[state] в игре (signon=6), но игрока нет: главное меню "
                                         "(фоновая карта), наблюдатель или ещё не заспавнился. "
                                         "Зайди в матч с ботами и дождись спавна")
            self._diag(lp, state, [])
            if self.last_lp:
                self.model_cache.clear()
                self.originals.clear()
                self.applied.clear()
            self.last_lp = 0
            return
        if lp != self.last_lp:  # new map / respawn: entity addresses are different now
            self.model_cache.clear()
            self.originals.clear()
            self.applied.clear()
            self.list_ok = False
            self.forced_sig.clear()
            self.force_budget = FORCE_BUDGET
        self.last_lp = lp
        self._status("ok", f"[state] игрок найден ({self.lp_method}, {lp:#x}): скины применяются")
        self._ensure_list(lp)
        seq = self.live.refresh_seq()
        if seq != self._refresh_seen:
            self._refresh_seen = seq
            self.pending_force = True
            self.force_budget = FORCE_BUDGET
            self.applied.clear()
            self.forced_sig.clear()
            self.log("[refresh] запрошено принудительное обновление")
        seen, pre = [], {}
        act = self._u32(lp + o["m_hActiveWeapon"]) if "m_hActiveWeapon" in o else 0
        for i, h in enumerate(self._handles(lp)):
            if h in (0, 0xFFFFFFFF):
                continue
            w = self.entity(h)
            if not w:
                continue
            defidx = self._r("short", w + o["m_iItemDefinitionIndex"])
            paint, idh = self._r("int", w + o["m_nFallbackPaintKit"]), self._r("int", w + o["m_iItemIDHigh"])
            seen.append((i, defidx, paint, idh))
            pre[w] = (defidx, paint, idh)   # values BEFORE this tick writes anything
            if defidx in cfg["knife_ids"] or (use_knife and defidx == cfg["knife"]["defidx"]):
                if use_knife:
                    self.last_fresh = False
                    if self.apply_knife(w, defidx) and self.last_fresh and h == act:
                        self._equip_at = self.now() + 0.3
            else:
                skin = cfg["skins"].get(defidx)
                if skin:
                    self.last_fresh = False
                    if self._apply(w, ("skin", defidx), defidx, skin, 0) and self.last_fresh and h == act:
                        self._equip_at = self.now() + 0.3   # it is in your hands: rebuild its model
        if use_knife:
            self.apply_knife_viewmodel(lp)
            self._knife_diag(lp)
        if use_gloves:
            self.apply_gloves(lp)
        self._check_verify(pre)
        self._do_reequip(cfg)
        self._diag(lp, state, seen)
        if self.pending_force and self.now() - self.last_force >= FORCE_MIN_INTERVAL:
            self.pending_force = False
            if self.force_budget > 0:
                self.force_budget -= 1
                self.force_full_update()
                self.last_force = self.now()
                self.stats["forced"] += 1
                self._verify = {"t": self.last_force + VERIFY_DELAY,
                                "exp": {a: (sig[0], sig[1]) for a, sig in self.applied.items()}}
                self.log(f"[force] full update #{self.stats['forced']} отправлен; проверю значения "
                         f"через {VERIFY_DELAY} с")
            else:
                self._warn_once("budget", "лимит принудительных full update исчерпан (сущности "
                                          "пересоздаются или сервер сбрасывает значения): дальше только "
                                          "запись значений. Смени оружие или нажми «Обновить скины»")

    def _do_reequip(self, cfg):
        """A weapon that was created/changed while in your hands gets its skin model only when it is
        equipped again. Taps Q twice (switch away and back) once, only while the game window has focus."""
        if self._equip_at is None or self.now() < self._equip_at:
            return
        self._equip_at = None
        if (not cfg.get("auto_reequip") or self._equip_busy
                or self.now() - self._equip_last < EQUIP_COOLDOWN):
            return
        pid = getattr(self.pm, "process_id", None)
        if not csgo_foreground(pid):
            self._warn_once("equipfg", "авто-экипировка пропущена: окно CS:GO не в фокусе "
                                       "(переключи оружие сама: Q или 1→2→1)")
            return
        self._equip_last, self._equip_busy = self.now(), True
        threading.Thread(target=self._equip_worker, args=(pid,), daemon=True).start()

    def _equip_worker(self, pid):
        try:
            self.log("[equip] авто-экипировка: Q, Q (оружие туда и обратно, чтобы модель скина построилась)")
            for _ in range(2):
                if not csgo_foreground(pid):
                    break
                tap_key(0x10)
                time.sleep(0.6)
        except Exception as e:  # noqa: BLE001
            self.log(f"[equip] не удалось отправить клавишу: {e}")
        finally:
            self._equip_busy = False

    def _check_verify(self, pre):
        """After a full update: did our values survive in the entities the game now has?"""
        v = self._verify
        if not v or self.now() < v["t"]:
            return
        self._verify = None
        kept = reset = gone = 0
        for addr, (_, paint) in v["exp"].items():
            cur = pre.get(addr)
            if cur is None:
                gone += 1
            elif cur[1] == paint and cur[2] == -1:
                kept += 1
            else:
                reset += 1
        tail = ""
        if v["exp"] and kept == len(v["exp"]):
            tail = (" -> данные в памяти верные. ТЕПЕРЬ переключи оружие: Q (или 1→2→1) и подожди "
                    "секунду — модель скина строится при экипировке, не при записи в память")
        elif gone or reset:
            tail = (" -> игра пересоздала/сбросила оружие после full update; движок пишет значения "
                    "заново, смотри, станут ли они держаться")
        self.log(f"[verify] после full update: значения сохранились у {kept}, сброшены сервером у "
                 f"{reset}, сущность пересоздана (новый адрес) у {gone}{tail}")

    def restore(self):
        any_ = False
        for addr, rec in self.originals.items():
            any_ |= self._restore_one(addr, rec)
        if any_:
            try:
                self.force_full_update()
            except PymemError:
                pass


# ------------------------------------------------------------------- attach/run
def attach(log=print):
    if pymem is None:
        raise RuntimeError("модуль pymem недоступен (нужен Windows и  python -m pip install pymem)")
    try:
        pm = pymem.Pymem("csgo.exe")
        cm = pymem.process.module_from_name(pm.process_handle, "client.dll")
        em = pymem.process.module_from_name(pm.process_handle, "engine.dll")
    except PymemError as e:
        raise RuntimeError(f"не могу подключиться к csgo.exe: {e}. Запусти legacy-игру (процесс "
                           "csgo.exe) и, если она уже идёт, запусти эту программу от администратора")
    if cm is None or em is None:
        raise RuntimeError("client.dll/engine.dll ещё не загружены: дождись главного меню")
    return pm, cm, em


def run(offsets_path, raw_cfg, stop: threading.Event, log=print, live=None):
    live = live or LiveConfig(raw_cfg)
    cfg = live.get()
    off = load_offsets(offsets_path)
    pm, cm, em = attach(log)
    log(f"[attach] client.dll={cm.lpBaseOfDll:#x} engine.dll={em.lpBaseOfDll:#x}")
    path = getattr(cm, "filename", None)
    if path:
        digest = sha256_file(path)
        log(f"[build] client.dll sha256 = {digest}")
        exp = cfg["expected_client_sha256"]
        if exp and digest.lower() != exp.lower():
            raise RuntimeError("client.dll hash differs from expected_client_sha256: "
                               "offsets belong to another build")
    if not cfg["account_id"]:
        log("[warn] Account ID = 0: возьму owner xuid с твоего оружия (если он там есть)")
    eng = Engine(pm, cm.lpBaseOfDll, em.lpBaseOfDll, off, live, log,
                 client_size=getattr(cm, "SizeOfImage", 0))
    log("[run] active: скины применяются, пока ты ЖИВ в матче (запуск игры с -insecure, офлайн/боты)")
    fails, last_err = 0, None
    hires = False
    try:
        import ctypes
        ctypes.windll.winmm.timeBeginPeriod(1)   # time.sleep(0.005) really sleeps ~5 ms, not 15
        hires = True
    except Exception:  # noqa: BLE001  (not Windows / no winmm)
        pass
    try:
        while not stop.is_set():
            try:
                eng.tick()
                fails = 0
            except PymemError as e:
                fails += 1
                msg = f"{type(e).__name__}: {e}"
                if msg != last_err:  # say WHAT failed, once, instead of a vague timeout later
                    last_err = msg
                    hint = (" (ошибка записи: запусти программу от администратора)"
                            if "Write" in type(e).__name__ else "")
                    log(f"[error] {msg}{hint}")
                if fails >= MAX_FAILED_TICKS:
                    raise RuntimeError(f"giving up after {MAX_FAILED_TICKS} failed ticks; "
                                       f"last error: {last_err}")
            time.sleep(0.001 if eng.now() - eng.last_force < BURST_SECONDS else TICK_SLEEP)
    finally:
        eng.restore()
        if hires:
            try:
                ctypes.windll.winmm.timeEndPeriod(1)
            except Exception:  # noqa: BLE001
                pass
        log("[run] stopped, originals restored where possible")


# ------------------------------------------------------------------- diagnostics
def diagnose(offsets_path, log=print, account=0, attach_fn=None, fix=False):
    """One report that answers 'why do my skins not show'. Read-only, except one harmless
    write of the SAME value back to a weapon field to prove that writing works.
    Returns {"ok": bool, "verdict": [str], ...}."""
    verdict = []
    o = load_offsets(offsets_path)
    pm, cm, em = (attach_fn or attach)()
    cbase, ebase = cm.lpBaseOfDll, em.lpBaseOfDll
    log(f"[diag] offsets file: {offsets_path}")
    log(f"[diag] client.dll base={cbase:#x} size={getattr(cm, 'SizeOfImage', 0):#x}  "
        f"engine.dll base={ebase:#x}")
    path = getattr(cm, "filename", None)
    if path:
        try:
            log(f"[diag] client.dll sha256 = {sha256_file(path)}")
        except OSError as e:
            log(f"[diag] cannot hash client.dll: {e}")
    eng = Engine(pm, cbase, ebase, o, LiveConfig({"account_id": account}), log=log,
                 client_size=getattr(cm, "SizeOfImage", 0))

    cs = eng._u32(ebase + o["dwClientState"])
    if not plausible(cs):
        verdict.append("dwClientState не указывает на память: оффсет engine.dll неверный для этой "
                       "сборки — нажми «Сканировать» (игра запущена) и повтори")
        return _finish(log, verdict, False)
    state, slot = eng.signon_state(), eng.local_slot()
    maxp = None
    if "dwClientState_MaxPlayer" in o:
        try:
            maxp = pm.read_int(cs + o["dwClientState_MaxPlayer"])
        except PymemError:
            maxp = None
    log(f"[diag] clientstate={cs:#x} signon={state} (6 = в игре) local slot={slot} maxplayers={maxp}")

    def collect():
        rows = []
        for i in range(64):
            e = eng.entity_at(i)
            if e:
                rows.append((i, e, eng.player_info(e)))
        pl = [(i, e, inf) for i, e, inf in rows if inf and inf[0] in (1, 2, 3) and 0 <= inf[1] <= 500]
        base_now = o["dwEntityList"] + eng.list_delta
        log(f"[diag] entity list client+{base_now:#x}: непустых {len(rows)} из первых 64, "
            f"похожих на игроков {len(pl)}")
        for i, e, inf in pl[:12]:
            log(f"[diag]   entry {i} (entity index {i + 1}) {e:#x} team={inf[0]} health={inf[1]} life={inf[2]}")
        return pl

    def local_report():
        d = eng._u32(cbase + o["dwLocalPlayer"])
        v = eng.entity_at(slot) if slot is not None and 0 <= slot < 64 else 0
        fl = eng.flagged_local()
        inf = eng.player_info(d) if plausible(d) else None
        log(f"[diag] dwLocalPlayer client+{o['dwLocalPlayer']:#x} -> {d:#x} "
            f"player-like={eng._looks_like_player(d)} raw team/health/life={inf}")
        log(f"[diag] entity list[slot {slot}] -> {v:#x} player-like={eng._looks_like_player(v)}")
        log("[diag] m_bIsLocalPlayer scan -> " + (f"{fl:#x}" if "m_bIsLocalPlayer" in o
                                                  else "нет оффсета в файле"))
        p = eng.local_player()
        log(f"[diag] выбран локальный игрок: {p:#x} via {eng.lp_method}")
        return d, v, p

    players = collect()
    direct, via, lp = local_report()

    csize = getattr(cm, "SizeOfImage", 0)
    if (not players or not lp) and csize and (state is None or state == SIGNON_FULL):
        log("[diag] игрока нет по оффсетам файла: ищу entity list прямо в памяти client.dll "
            "(несколько секунд) ...")
        try:
            disc = discover_entity_list(pm, cbase, csize, o, slot)
        except PymemError as e:
            disc = None
            log(f"[diag] ошибка чтения памяти при поиске: {e}")
        if disc:
            rel = disc["entity_list_rel"]
            eng.list_delta, eng.list_ok = rel - o["dwEntityList"], True
            loc = disc["local"]
            log(f"[diag] НАЙДЕН entity list: client+{rel} ({rel:#x}); в файле {o['dwEntityList']} "
                f"({o['dwEntityList']:#x}); сдвиг {eng.list_delta:+#x}; игроков с проверенным оружием "
                f"{len(disc['players'])}; " + (f"ты = entity {loc['idx']} ({loc['ptr']:#x})" if loc
                                               else "тебя среди них определить не удалось"))
            verdict.append(f"dwEntityList в файле устарел, настоящий {rel} ({rel:#x}); движок "
                           "находит его сам")
            if fix:
                try:
                    patch_offsets_file(offsets_path, {"dwEntityList": rel})
                    log(f"[diag] dwEntityList={rel} записан в {offsets_path} (оригинал: .bak)")
                except (OSError, ValueError) as e:
                    log(f"[diag] не смог записать файл оффсетов: {e}")
            players = collect()
            direct, via, lp = local_report()
        else:
            log("[diag] поиск в памяти ничего не дал: нет живого игрока с оружием в памяти client.dll, "
                "либо netvar-оффсеты (m_hMyWeapons/m_hOwnerEntity/m_iTeamNum/m_iHealth) не от этой сборки")

    if state is not None and state != SIGNON_FULL:
        verdict.append(f"signon={state}: ты сейчас не в игре. Зайди в матч (офлайн с ботами) и повтори")
    if not players:
        verdict.append("В entity list нет ни одного игрока. Чаще всего это главное меню (фоновая карта "
                       "даёт signon=6, но игрока нет), загрузка карты или наблюдатель. Запусти матч с "
                       "ботами, дождись спавна и нажми «Диагностика» ещё раз. Если игроки так и не "
                       "появятся — dwEntityList устарел: пришли отчёт целиком")
    elif not lp:
        verdict.append("Игроки в списке есть, но ни один из трёх способов не нашёл ТЕБЯ. Возможно, ты "
                       "наблюдатель или мёртв без объекта игрока. Заспавнись и повтори; если не "
                       "помогло — пришли отчёт")
    else:
        if not direct and lp:
            verdict.append("dwLocalPlayer читается как 0, но игрок найден через "
                           f"{eng.lp_method}: движок работает и с таким оффсетом")
            for d in range(-0x800, 0x801, 4):
                if eng._u32(cbase + o["dwLocalPlayer"] + d) == lp:
                    new = o["dwLocalPlayer"] + d
                    log(f"[diag] указатель на игрока лежит в client+{new} ({new:#x}) = файл {d:+#x}")
                    verdict.append(f"настоящий dwLocalPlayer, вероятно, {new} ({new:#x}) "
                                   f"(сдвиг {d:+#x} от файла)")
                    break
        elif direct and via and direct != via:
            verdict.append(f"dwLocalPlayer ({direct:#x}) и entity list[slot] ({via:#x}) расходятся: "
                           "используется dwLocalPlayer")
        eng._ensure_list(lp)
        log(f"[diag] проверка entity list по твоему оружию: list_ok={eng.list_ok} "
            f"delta={eng.list_delta:+#x}")
        weapons = []
        log("[diag] оружие (slot, handle, entity, defidx, paint, itemIDHigh, accountID, ownerXuidLow, quality)")
        for i in range(WEAPON_SLOTS):
            h = eng._u32(lp + o["m_hMyWeapons"] + i * 4)
            if h in (0, 0xFFFFFFFF):
                continue
            w = eng.entity(h)
            if not w:
                log(f"[diag]   slot {i} handle {h:#x}: не резолвится через entity list")
                continue
            try:
                row = (eng._r("short", w + o["m_iItemDefinitionIndex"]),
                       eng._r("int", w + o["m_nFallbackPaintKit"]),
                       eng._r("int", w + o["m_iItemIDHigh"]),
                       eng._r("uint", w + o["m_iAccountID"]),
                       eng._r("uint", w + o["m_OriginalOwnerXuidLow"]),
                       eng._r("int", w + o["m_iEntityQuality"]))
            except PymemError as e:
                log(f"[diag]   slot {i} {w:#x}: ошибка чтения {e}")
                continue
            weapons.append((w, row))
            log(f"[diag]   slot {i} {h:#010x} {w:#x} def={row[0]} paint={row[1]} idhigh={row[2]} "
                f"acct={row[3]} owner={row[4]} q={row[5]}")
        if not weapons:
            verdict.append("Ни одно оружие не резолвится: неверен m_hMyWeapons или формула entity list. "
                           "Ты должен быть ЖИВ и с оружием в руках")
        else:
            bad = [r[0] for _, r in weapons if not (1 <= r[0] <= 700 or 5000 <= r[0] <= 5100)]
            if bad:
                verdict.append(f"defidx {bad} выглядят мусором: netvar-оффсеты не от этой сборки")
            owners = {r[4] for _, r in weapons if r[4]}
            if owners and account and account not in owners:
                verdict.append(f"Account ID в окне ({account}) не совпадает с owner xuid оружия "
                               f"{sorted(owners)}: движок возьмёт xuid оружия, но проверь число в окне")
            if not owners:
                verdict.append("У оружия owner xuid = 0: нужен Account ID в окне (Steam/userdata/<число>)")
            # write test: same value back, proves that WriteProcessMemory is allowed
            w = weapons[0][0]
            try:
                cur = pm.read_int(w + o["m_nFallbackSeed"])
                pm.write_int(w + o["m_nFallbackSeed"], cur)
                back = pm.read_int(w + o["m_nFallbackSeed"])
                if back == cur:
                    log("[diag] тест записи: OK (записал то же значение обратно)")
                else:
                    verdict.append("тест записи: значение после записи другое — что-то перезаписывает "
                                   "память или оффсет m_nFallbackSeed неверен")
            except PymemError as e:
                verdict.append(f"ЗАПИСЬ В ПАМЯТЬ ЗАПРЕЩЕНА ({e}): запусти программу от администратора "
                               "(и игру/Steam без повышения прав, либо обе с одинаковыми правами)")
            if not o.get("model_precache"):
                try:
                    mp = find_model_precache(pm, ebase, o)
                except PymemError:
                    mp = None
                if mp:
                    log(f"[diag] таблица моделей найдена: steps={[hex(s) for s in mp['steps']]} "
                        f"first={mp['first']:#x} stride={mp['stride']:#x} моделей={mp['models']} "
                        "(ножи будут менять модель)")
                else:
                    log("[diag] таблица моделей не найдена: смена ТИПА ножа/перчаток недоступна, "
                        "скин на текущем ноже работает")
    ok = bool(lp) and not any(v.startswith(("ЗАПИСЬ", "Ни одно", "defidx", "В entity")) for v in verdict)
    return _finish(log, verdict, ok)


def _finish(log, verdict, ok):
    log("[diag] === ВЕРДИКТ ===")
    for v in verdict or ["всё в цепочке читается и пишется нормально: скины должны применяться"]:
        log("[diag] - " + v)
    return {"ok": ok, "verdict": verdict}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--offsets", required=True)
    ap.add_argument("--skins")
    ap.add_argument("--diag", action="store_true")
    ap.add_argument("--account", type=int, default=0)
    ap.add_argument("--fix", action="store_true", help="with --diag: write a validated dwEntityList into the file")
    a = ap.parse_args()
    if a.diag:
        diagnose(a.offsets, account=a.account, fix=a.fix)
    else:
        if not a.skins:
            ap.error("--skins is required unless --diag")
        ev = threading.Event()
        try:
            run(a.offsets, json.loads(Path(a.skins).read_text(encoding="utf-8")), ev)
        except KeyboardInterrupt:
            ev.set()
