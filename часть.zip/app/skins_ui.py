"""New UI for the CS:GO Legacy skin changer (gui.py stays as it is).

    run_skins_ui.pyw          double click: starts without a console window
    python skins_ui.py        same thing from a terminal

Needs Pillow:  pip install pillow      (smooth rounded shapes, icons and downscaled pictures)
Everything is clicked with the LEFT mouse button.
"""
import ctypes
import hashlib
import json
import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog

try:
    from PIL import Image, ImageTk
except ImportError:
    _r = tk.Tk()
    _r.withdraw()
    messagebox.showerror("Pillow", "Нужен Pillow. Установи командой:\n\npip install pillow")
    sys.exit(1)

import build_catalog
import core
import gc_bridge
import seqmap
import steam
import ui_smooth as sm
from model import AGENT_CAT, GLOVE_CAT, KNIFE_CAT, Selection

HERE = Path(os.environ.get("FLS_HOME") or Path(__file__).resolve().parent)
CATALOG, SELECTION = HERE / "catalog.json", HERE / "selection.json"
SYNC_SETTINGS = HERE / "sync.json"              # shared-file auto sync (path + last seen hash)
# Раньше здесь был DLL-движок. Теперь «движок» — csgo_gc: он отдаёт инвентарь
# самой игре, поэтому никаких csgo_skins.json / DLL / инжектора больше нет.
ICON_DIR, BG_FILE = HERE / "icons", HERE / "bg.png"

FONT = "Segoe UI"
FG, MUTED, OKC = "#f2f5fb", "#9fb0d4", "#4cd08a"
TABS = {"Ножи": [KNIFE_CAT],
        "Оружия": ["Винтовки", "Пистолеты", "ПП", "Снайперские", "Тяжёлые"],
        "Агенты": [AGENT_CAT],
        "Перчатки": [GLOVE_CAT]}
WEAR = [("FN", 0.0001), ("MW", 0.10), ("FT", 0.25), ("WW", 0.40), ("BS", 0.60)]

# window shape: "auto" = smooth Windows 11 corners, falls back to a cut-out region on older Windows;
# "region" = always the cut-out region (not anti-aliased); "off" = square window
CORNER_MODE = "region"
WIN_R = 64
HDR = 86                    # height of the top strip that scrolled content hides under
MASK_SOLID = 44             # top fade: fully hidden above this y ...
MASK_END = 94               # ... and fully visible below this y (smooth curve in between)
MASK_BOT = 34               # bottom fade height (small): content melts into the background
CHROME_SHIFT = 18           # run button + window dots are moved this many px to the left
TITLE_PX = 18               # size of the "Выберите что хотите" text (was 33 px inside a big pill)
HOME_W, HOME_H = 0.88, 0.55 # home buttons: width factor / height factor against the old size
BLUR_K_SCROLL = 0             # scroll motion blur OFF: regenerating blurred frames mid-scroll caused 10-FPS stutter
TRANSITION = 0.75           # seconds for a page change (fade + slide)
STYLE_GLASS, STYLE_ACTIVE, STYLE_GREEN = (sm.GLASS, sm.GLASS_H), (sm.ACTIVE, sm.ACTIVE_H), (sm.GREEN, sm.GREEN_H)


# ------------------------------------------------------------------------------ Windows helpers
def hide_console():
    """Hide the console only when it belongs to this process alone (double-clicked .py)."""
    if sys.platform != "win32":
        return
    k32 = ctypes.windll.kernel32
    hwnd = k32.GetConsoleWindow()
    if hwnd:
        buf = (ctypes.c_uint * 4)()
        if k32.GetConsoleProcessList(buf, 4) <= 1:
            ctypes.windll.user32.ShowWindow(hwnd, 0)


def _win32():
    from ctypes import wintypes
    u = ctypes.WinDLL("user32", use_last_error=True)
    g = ctypes.WinDLL("gdi32", use_last_error=True)
    d = ctypes.WinDLL("dwmapi", use_last_error=True)
    u.GetParent.argtypes, u.GetParent.restype = [wintypes.HWND], wintypes.HWND
    u.GetWindowLongPtrW.argtypes, u.GetWindowLongPtrW.restype = [wintypes.HWND, ctypes.c_int], ctypes.c_ssize_t
    u.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
    u.SetWindowLongPtrW.restype = ctypes.c_ssize_t
    u.SetWindowRgn.argtypes = [wintypes.HWND, wintypes.HRGN, wintypes.BOOL]
    g.CreateRoundRectRgn.argtypes, g.CreateRoundRectRgn.restype = [ctypes.c_int] * 6, wintypes.HRGN
    d.DwmSetWindowAttribute.argtypes = [wintypes.HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]
    d.DwmSetWindowAttribute.restype = ctypes.c_long
    return u, g, d


class Icons:
    """Skin pictures come from YOUR game files (pak01_dir.vpk). One worker thread reads and resizes
    them with Pillow (LANCZOS = smooth, no pixel stairs); PhotoImage objects are created on the Tk
    thread only. Paths tried are CANDIDATES (not verified on this build); the first failure is
    reported in the status line."""
    SUFFIX = ("_large.png", ".png", "_medium.png")

    def __init__(self, csgo_dir, ui):
        self.dir, self.ui, self.mem, self.pak = csgo_dir, ui, {}, None
        self.q, self.failed = queue.Queue(), 0
        ICON_DIR.mkdir(exist_ok=True)
        threading.Thread(target=self._work, daemon=True).start()

    def _read(self, icon):
        cached = ICON_DIR / (icon.replace("/", "_") + ".png")
        if cached.exists():
            return cached
        if self.dir is None:
            return None
        try:
            if self.pak is None:
                import vpk
                self.pak = vpk.open(str(Path(self.dir) / "pak01_dir.vpk"))
        except Exception:  # noqa: BLE001  (module or archive missing)
            return None
        for suf in self.SUFFIX:
            try:
                data = self.pak[f"resource/flash/{icon}{suf}"].read()
            except Exception:  # noqa: BLE001
                continue
            if data[:4] == b"\x89PNG":
                cached.write_bytes(data)
                return cached
        return None

    def _work(self):
        while True:
            icon, box, cb = self.q.get()
            img = None
            path = self._read(icon)
            if path:
                try:
                    src = Image.open(path).convert("RGBA")
                    k = min(box[0] / src.width, box[1] / src.height)
                    img = src.resize((max(1, round(src.width * k)), max(1, round(src.height * k))),
                                     sm.LANCZOS)
                except OSError:
                    img = None
            self.ui.post(lambda i=icon, b=box, p=img, c=cb: self._done(i, b, p, c))

    def _done(self, icon, box, pil, cb):
        ph = ImageTk.PhotoImage(pil) if pil is not None else None
        if ph is None:
            self.failed += 1
            self.ui.status(f"нет картинки для {icon} (путь в VPK не подошёл)")
        self.mem[(icon, box)] = (ph, pil)
        cb(ph, pil)

    def get(self, icon, box, cb):
        if not icon:
            return cb(None, None)
        if (icon, box) in self.mem:
            return cb(*self.mem[(icon, box)])
        self.q.put((icon, box, cb))


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.overrideredirect(True)
        w, h = 1120, 700
        self.geometry(f"{w}x{h}+{(self.winfo_screenwidth() - w) // 2}+{(self.winfo_screenheight() - h) // 2}")
        self.minsize(940, 620)
        self.configure(bg="#7f86a0")
        self.uiq, self.tab, self.builder = queue.Queue(), None, None
        self.sel, self.cat, self.engine_on, self.refresh_n = Selection(), None, False, 0
        self._agent_team = "T"               # active filter in the agents block at the bottom of Weapons
        self.zoomed, self._min, self._normal, self._dragging = False, False, None, False
        self.W, self.H, self._applied, self._rz, self._ready = w, h, None, None, False
        self.scroll_cur = self.scroll_tgt = 0.0
        self.content_h, self.chip, self.view_run, self.dot_item, self.status_text = 0, None, [], None, ""
        self._veils, self._masks = {}, {}
        self.toast = None
        self._fps_item, self._fps_t = None, 0.0
        self.load_catalog()
        folder, _ = steam.find_csgo_dir()
        self.csgo_dir = folder
        seqmap.LOG_PATH = HERE / "seqmap.log"
        self.icons = Icons(folder, self)
        self.account = steam.active_account_id() or 0
        self._load_selection()
        self._sync_path, self._sync_last = "", ""
        self._load_sync()
        self.after(1500, self._sync_tick)
        self.bg_src = self._load_bg()
        self._app_icon = ImageTk.PhotoImage(sm.app_icon())
        self.iconphoto(True, self._app_icon)
        try:                                   # crisp multi-size .ico for title/taskbar/Alt-Tab (Windows)
            if sys.platform == "win32" and (HERE / "From_Los_Santos.ico").exists():
                self.iconbitmap(default=str(HERE / "From_Los_Santos.ico"))
        except tk.TclError:
            pass
        self.cv = tk.Canvas(self, bg="#7f86a0", highlightthickness=0, bd=0)
        self.cv.pack(fill="both", expand=True)
        self.engine = sm.Engine(self, self.cv)
        self.engine.hooks.append(self._scroll_step)
        self.cv.bind("<Configure>", self._on_cfg)
        self.cv.bind("<ButtonPress-1>", lambda e: self.cv.focus_set(), add="+")
        self.bind_all("<F2>", self._toggle_fps)
        self.cv.bind("<ButtonPress-1>", self._drag0, add="+")
        self.cv.bind("<B1-Motion>", self._drag)
        self.bind("<Map>", self._restore)
        self.bind_all("<MouseWheel>", self._wheel)
        self.after(50, self._drain)
        self.after(150, self._native)
        self.protocol("WM_DELETE_WINDOW", self.quit_app)

    # ------------------------------------------------------------------ infrastructure
    def post(self, fn):
        self.uiq.put(fn)

    def _drain(self):
        try:
            while True:
                self.uiq.get_nowait()()
        except queue.Empty:
            pass
        self.after(50, self._drain)

    def status(self, msg):
        self.status_text = msg
        self._draw_status()

    def _draw_status(self):
        """Bottom message: shown as a pill, kept 1.5 s, then it fades out and disappears."""
        if not self._ready or self.toast is None or not self.status_text:
            return
        f = (FONT, 10, "bold")
        self.toast.show(sm.fit_text(f, self.status_text, self.W - 160), hold=1.5)
        self.status_text = ""

    def load_catalog(self):
        cat = None
        try:
            cat = json.loads(CATALOG.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass
        has_icons = cat and any("icon" in s for c in cat["categories"].values() for w in c for s in w["skins"])
        if not has_icons:
            folder, _ = steam.find_csgo_dir()
            if folder is None:
                picked = filedialog.askdirectory(title="Папка CS:GO Legacy (где csgo.exe)")
                folder = steam.resolve_csgo_dir(picked) if picked else None
            if folder and messagebox.askyesno("Каталог", f"Пересобрать каталог скинов (с картинками) из\n{folder}?"):
                try:
                    cat = build_catalog.build_catalog(csgo=str(folder))
                    build_catalog.write_catalog(cat, CATALOG)
                except build_catalog.CatalogError as e:
                    messagebox.showerror("Каталог", str(e))
        if not cat:
            sys.exit("catalog.json is missing and could not be built")
        self.cat = cat

    def _load_selection(self):
        try:
            raw = json.loads(SELECTION.read_text(encoding="utf-8"))
            self.sel.load(raw)
            self.account = self.account or int(raw.get("account_id", 0))
        except (OSError, ValueError):
            pass

    def autosave(self):
        try:
            SELECTION.write_text(json.dumps(self.sel.raw(self.account, self.cat["knife_ids"]), indent=1),
                                 encoding="utf-8")
        except OSError:
            pass

    # ------------------------------------------------------------------ window: shape, taskbar, drag
    def _hwnd(self, u):
        return u.GetParent(self.winfo_id())

    def _native(self):
        """Taskbar button for the frameless window + smooth rounded corners."""
        if sys.platform != "win32":
            return
        try:
            u, _g, _d = _win32()
            hwnd = self._hwnd(u)
            ex = u.GetWindowLongPtrW(hwnd, -20)                       # GWL_EXSTYLE
            ex = (ex & ~0x00000080) | 0x00040000                      # - TOOLWINDOW + APPWINDOW
            u.SetWindowLongPtrW(hwnd, -20, ex)
            self.withdraw()                                           # re-map so the taskbar notices
            self.after(30, self._after_remap)
        except (OSError, AttributeError) as e:
            self.status(f"панель задач/углы окна: {e}")

    def _after_remap(self):
        self.deiconify()
        self.after(40, self._round_window)

    def _round_window(self):
        if sys.platform != "win32" or CORNER_MODE == "off":
            return
        try:
            u, g, d = _win32()
            hwnd = self._hwnd(u)
            ok = False
            if CORNER_MODE == "auto":
                pref = ctypes.c_int(2)                                # DWMWCP_ROUND
                ok = d.DwmSetWindowAttribute(hwnd, 33, ctypes.byref(pref), 4) == 0
            if not ok:
                r = 0 if self.zoomed else 2 * WIN_R
                u.SetWindowRgn(hwnd, g.CreateRoundRectRgn(0, 0, self.winfo_width() + 1,
                                                         self.winfo_height() + 1, r, r), True)
        except (OSError, AttributeError) as e:
            self.status(f"углы окна: {e}")

    def _drag0(self, e):
        tags = self.cv.gettags("current")
        self._dragging = e.y < 72 and any(t in tags for t in ("bg", "mask", "drag"))
        self._dx, self._dy = e.x_root - self.winfo_x(), e.y_root - self.winfo_y()

    def _drag(self, e):
        if self._dragging and not self.zoomed:
            self.geometry(f"+{e.x_root - self._dx}+{e.y_root - self._dy}")

    def minimize(self):
        self._min = True
        self.overrideredirect(False)
        self.iconify()

    def _restore(self, _e=None):
        if self._min:
            self._min = False
            self.after(30, self._reframe)

    def _reframe(self):
        self.overrideredirect(True)
        self.after(30, self._native)

    def maximize(self):
        if self.zoomed:
            self.geometry(self._normal)
        else:
            self._normal = self.geometry()
            self.geometry(f"{self.winfo_screenwidth()}x{self.winfo_screenheight() - 40}+0+0")
        self.zoomed = not self.zoomed
        self.after(160, self._round_window)

    def quit_app(self):
        self.autosave()
        sm.close_app(self, self.engine)

    # ------------------------------------------------------------------ background, layout, chrome
    def _load_bg(self):
        try:
            return Image.open(BG_FILE).convert("RGB")
        except OSError:
            return sm.fallback_bg()

    def _on_cfg(self, e):
        if (e.width, e.height) == self._applied or e.width < 100:
            return
        self.W, self.H = e.width, e.height
        if self._rz:
            self.after_cancel(self._rz)
        self._rz = self.after(90, self._relayout)

    def _relayout(self):
        self._rz = None
        self._applied = (self.W, self.H)
        self._paint_bg()
        self._ready = True
        self._chrome()
        if self.builder:
            self.show(self.builder, animate=False)
        else:
            self.home()
        self._round_window()
        self.after(250, self._veil_frames)          # build the fade frames now, not on the first click

    def _paint_bg(self):
        W, H, src = self.W, self.H, self.bg_src
        k = max(W / src.width, H / src.height)
        im = src.resize((max(W, round(src.width * k)), max(H, round(src.height * k))), sm.LANCZOS)
        ox, oy = (im.width - W) // 2, (im.height - H) // 2
        self.bg_pil = im.crop((ox, oy, ox + W, oy + H))
        self.bg_ph = ImageTk.PhotoImage(self.bg_pil)
        self.cv.delete("bg")
        self.cv.create_image(0, 0, image=self.bg_ph, anchor="nw", tags="bg")
        self.cv.tag_lower("bg")

    def _veil_frames(self):
        key = (self.W, self.H)
        if key not in self._veils:
            base = self.bg_pil.convert("RGBA")
            frames = []
            for i in range(14):
                im = base.copy()
                im.putalpha(round(255 * i / 13))
                frames.append(ImageTk.PhotoImage(im))
            self._veils = {key: frames}
        return self._veils[key]

    @staticmethod
    def _smooth(t):
        t = min(1.0, max(0.0, t))
        return t * t * t * (t * (6 * t - 15) + 10)          # smootherstep: no visible start/end of the fade

    def _mask_ph(self):
        """(top, bottom) fade strips cut from the background. The top one hides scrolled content
        slowly (MASK_SOLID..MASK_END), the bottom one is a short fade (MASK_BOT)."""
        key = (self.W, self.H)
        if key not in self._masks:
            W, H = self.W, self.H
            top = self.bg_pil.crop((0, 0, W, MASK_END)).convert("RGBA")
            a = Image.new("L", (1, MASK_END))
            a.putdata([round(255 * (1 - self._smooth((y - MASK_SOLID) / (MASK_END - MASK_SOLID))))
                       for y in range(MASK_END)])
            top.putalpha(a.resize((W, MASK_END)))
            bot = self.bg_pil.crop((0, H - MASK_BOT, W, H)).convert("RGBA")
            b = Image.new("L", (1, MASK_BOT))
            b.putdata([round(255 * self._smooth(y / (MASK_BOT - 1))) for y in range(MASK_BOT)])
            bot.putalpha(b.resize((W, MASK_BOT)))
            self._masks = {key: (ImageTk.PhotoImage(top), ImageTk.PhotoImage(bot))}
        return self._masks[key]

    def _chrome(self):
        """Always-on-top controls: run chip and the three window dots."""
        if self.toast is not None:
            self.toast.clear()
        self.cv.delete("chrome")
        W = self.W
        sm.WindowDots(self, W - 22 - CHROME_SHIFT, 33, d=20, gap=8, on_min=self.minimize, on_max=self.maximize,
                      on_close=self.quit_app, tags=("chrome",))
        self.chip = sm.Button(self, W - 158 - CHROME_SHIFT, 11, 44, 44, 22, icon="play", isz=22, cmd=self.toggle_run,
                              style=STYLE_GLASS, tags=("chrome",))
        self.refresh_run_ui()
        if self.toast is None:
            self.toast = sm.Toast(self, W / 2, self.H - 44, font=(FONT, 10, "bold"), hold=1.5,
                                  tags=("chrome",))
        else:
            self.toast.clear()
            self.toast.cx, self.toast.cy = W / 2, self.H - 44
        self._draw_status()

    def _mask(self):
        top, bot = self._mask_ph()
        self.cv.create_image(0, 0, image=top, anchor="nw", tags=("mask",))
        # state="disabled": the bottom fade lets clicks through to the cards under it
        self.cv.create_image(0, self.H - MASK_BOT, image=bot, anchor="nw", tags=("mask_b",), state="disabled")

    def _header(self, title, back=None, mask=False):
        if mask:
            self._mask()
        if back:
            sm.Button(self, 24 + CHROME_SHIFT, 11, 44, 44, 22, icon="back", isz=22, cmd=back)
        if title:
            f = (FONT, 14, "bold")
            w = min(sm.text_width(f, title) + 64, self.W - 360 - 2 * CHROME_SHIFT)
            sm.Button(self, (self.W - w) / 2, 11, w, 44, 22, text=sm.fit_text(f, title, w - 36), font=f)

    # ------------------------------------------------------------------ views, transition, scroll
    def _fade_overlay(self):
        """Transparent Toplevel carrying a copy of the background; its alpha is animated by the
        engine. Same picture as the canvas veil, but 256 alpha steps instead of 14 images."""
        if sys.platform != "win32":
            return None
        try:
            w, h = self.winfo_width(), self.winfo_height()
            ov = tk.Toplevel(self)
            ov.overrideredirect(True)
            ov.attributes("-topmost", True)
            ov.geometry(f"{w}x{h}+{self.winfo_x()}+{self.winfo_y()}")
            cv = tk.Canvas(ov, width=w, height=h, highlightthickness=0, bd=0)
            cv.pack(fill="both", expand=True)
            cv.create_image(0, 0, image=self.bg_ph, anchor="nw")
            ov.update_idletasks()
            u, g, _d = _win32()
            hwnd = u.GetParent(ov.winfo_id())
            ex = u.GetWindowLongPtrW(hwnd, -20) | 0x20               # WS_EX_TRANSPARENT: clicks pass through
            u.SetWindowLongPtrW(hwnd, -20, ex)
            r = 0 if self.zoomed else 2 * WIN_R
            u.SetWindowRgn(hwnd, g.CreateRoundRectRgn(0, 0, w + 1, h + 1, r, r), True)
            ov.attributes("-alpha", 1.0)
            ov.lift()
            return ov
        except (OSError, AttributeError, tk.TclError):
            try:
                ov.destroy()
            except Exception:
                pass
            return None

    def show(self, builder, direction=1, animate=True):
        cv = self.cv
        self.builder = builder
        cv.delete("view")
        cv.delete("veil")
        self.engine.reset_blur()
        cv.configure(cursor="")
        self.view_run, self.dot_item = [], None
        self.scroll_cur = self.scroll_tgt = 0.0
        self.content_h = 0
        before = set(cv.find_all())
        builder()
        for i in cv.find_all():
            if i not in before:
                cv.addtag_withtag("view", i)
        self.refresh_run_ui()
        if animate:
            ov = self._fade_overlay()
            if ov is not None:
                self.engine.veil_window(ov, TRANSITION)
                self.engine.wake(TRANSITION + 0.5)
            else:
                fr = self._veil_frames()
                veil = cv.create_image(0, 0, image=fr[-1], anchor="nw", tags=("veil",))
                self.engine.veil(veil, fr, TRANSITION)
                self.engine.wake(TRANSITION + 0.5)
            self.engine.slide("view", 70 * direction, TRANSITION)
        cv.tag_raise("chrome")

    def _wheel(self, e):
        self.engine.wake(3.0)
        if self.content_h > self.H:
            self.scroll_tgt = max(self.H - self.content_h, min(0, self.scroll_tgt + e.delta / 120 * 100))

    def _scroll_step(self, dt):
        d = self.scroll_tgt - self.scroll_cur
        self.engine.freeze_glow = d != 0                # fewer things to repaint while scrolling
        if d == 0:
            return
        self.engine.wake(3.0)                         # keep 1000 Hz while the scroll is settling
        if abs(d) < 0.4:
            new = self.scroll_tgt
        else:
            new = self.scroll_cur + d * min(1.0, dt * 11)
        mv = round(new) - round(self.scroll_cur)
        speed = abs(new - self.scroll_cur) / max(dt, 1e-3)
        self.scroll_cur = new
        if mv:
            self.cv.move("scroll", 0, mv)
            self.engine.mark()
        if BLUR_K_SCROLL:
            self.engine.set_blur("y", speed * BLUR_K_SCROLL)

    def home(self, direction=1):
        self.tab = None
        self.show(self._home_build, direction)

    def _home_build(self):
        W, H = self.W, self.H
        s = min(1.0, (W - 60) / 980)
        bw, bh = int(270 * s * HOME_W), int(170 * s * HOME_H)
        sw, sh = int(160 * s * HOME_W), int(112 * s * HOME_H)
        gap = int(20 * s)
        total = bw + 2 * sw + 2 * gap
        x0 = (W - total) // 2
        cy = H * 0.54
        sm.ShimmerText(self, W / 2, int(cy - bh / 2 - 46), "Выберите что хотите", px=TITLE_PX,
                       fallback_font=(FONT, 12, "bold"))
        big, small = (FONT, max(12, int(22 * s)), "bold"), (FONT, max(10, int(15 * s)), "bold")
        for name, x, y, w, h, f in (("Ножи", x0, cy - sh / 2, sw, sh, small),
                                    ("Оружия", x0 + sw + gap, cy - bh / 2, bw, bh, big),
                                    ("Перчатки", x0 + sw + 2 * gap + bw, cy - sh / 2, sw, sh, small)):
            sm.Button(self, x, y, w, h, h * 0.32, text=name, font=f, cmd=lambda n=name: self.open_tab(n))
        # Agents sits directly under Weapons, a bit smaller than the other tiles
        aw, ah = int(180 * s), int(52 * s)
        sm.Button(self, x0 + sw + gap + (bw - aw) / 2, cy + bh / 2 + 14, aw, ah, ah * 0.3,
                  text="Агенты", font=small, cmd=lambda: self.open_tab(AGENT_CAT))
        by = int(H - 64)                     # sync sits much lower, near the bottom edge
        bw2 = int(250 * s)
        label = "Синхронизация: вкл" if self._sync_path else "Настроить синхронизацию"
        sm.Button(self, (W - bw2) / 2, by, bw2, 42, 21, text=label,
                  font=(FONT, 10, "bold"), cmd=self.setup_sync)

    # ------------------------------------------------------------------ auto sync (one shared file)
    def _load_sync(self):
        try:
            d = json.loads(SYNC_SETTINGS.read_text(encoding="utf-8"))
            self._sync_path = str(d.get("path") or "")
            self._sync_last = str(d.get("last") or "")
        except (OSError, ValueError):
            pass
        if not self._sync_path:
            env = os.environ.get("FLS_SYNC")
            candidates = [Path(env)] if env else []
            candidates += [HERE / "los_santos_sync.json",
                           Path.home() / "Documents" / "los_santos_sync.json"]
            for p in candidates:
                if p.is_file():
                    self._sync_path, self._sync_last = str(p), ""
                    self._save_sync()
                    break

    def _save_sync(self):
        try:
            SYNC_SETTINGS.write_text(json.dumps({"path": self._sync_path, "last": self._sync_last}, indent=1),
                                     encoding="utf-8")
        except OSError:
            pass

    def _profile_raw(self):
        raw = self.sel.raw(self.account, self.cat["knife_ids"])
        raw.pop("expected_client_sha256", None)
        raw["account_id"] = 0                      # the receiver puts in his own Account ID
        return raw

    def sync_push(self):
        """Any local change is written to the shared file; the friend's UI picks it up by itself."""
        if not self._sync_path or not self.account:
            return False
        try:
            data = json.dumps({"kind": "los_santos_sync", "version": 2,
                               "updated": time.strftime("%Y-%m-%d %H:%M:%S"),
                               "author": int(self.account), "profile": self._profile_raw()},
                              ensure_ascii=False, indent=1).encode("utf-8")
            Path(self._sync_path).write_bytes(data)
            self._sync_last = hashlib.sha256(data).hexdigest()
            self._save_sync()
            return True
        except Exception:  # noqa: BLE001 — sync must never break the UI
            return False

    def _sync_poll(self):
        if not self._sync_path or not self.account:
            return
        try:
            p = Path(self._sync_path)
            if not p.is_file():
                return
            data = p.read_bytes()
            h = hashlib.sha256(data).hexdigest()
            if h == self._sync_last:
                return
            d = json.loads(data.decode("utf-8"))
            if d.get("kind") != "los_santos_sync":
                return
            if int(d.get("author", 0)) == int(self.account):   # our own write from another instance
                self._sync_last = h
                self._save_sync()
                return
            prof = d.get("profile")
            if not isinstance(prof, dict) or "skins" not in prof:
                return
            acct = int(self.account)
            core.normalize_config({**prof, "account_id": acct, "expected_client_sha256": ""})
            self.sel.load({**prof, "account_id": acct})
            self.autosave()
            if self.engine_on:
                self.refresh_n += 1
                self.export_cfg(True)
            self._sync_last = h
            self._save_sync()
            self.status(f"профиль друга подхвачен автоматически: {len(self.sel.skins)} оружий")
            if self.builder:
                self.show(self.builder, 1, animate=False)
        except Exception as e:  # noqa: BLE001
            self.status(f"синхронизация: {e}")

    def _sync_tick(self):
        self.after(1500, self._sync_tick)
        self._sync_poll()

    def setup_sync(self):
        if self._sync_path:
            if not messagebox.askyesno("Синхронизация", "Отключить автоматическую синхронизацию?"):
                return
            self._sync_path, self._sync_last = "", ""
            self._save_sync()
            self.status("синхронизация отключена")
            self.home(-1)
            return
        path = filedialog.asksaveasfilename(
            title="Общий файл: OneDrive / Dropbox / Яндекс.Диск / сетевая папка",
            initialfile="los_santos_sync.json", defaultextension=".json",
            filetypes=[("JSON", "*.json")])
        if not path:
            return
        self._sync_path, self._sync_last = str(path), ""
        self._save_sync()
        self._sync_poll()
        self.status("синхронизация включена: профили подхватятся сами")
        self.home(-1)

    # ------------------------------------------------------------------ agents: own tab, T/CT switch on top
    def open_agents_list(self, team, direction=1):
        self.tab = AGENT_CAT
        self._agent_team = team
        self.show(lambda t=team: self._agents_build(t), direction)

    def _agents_build(self, team):
        W = self.W
        bx = (W - 268) / 2
        ty = MASK_END + 8                   # below the top fade, so the buttons are clickable
        for i, (key, label) in enumerate((("T", "Террористы · T"), ("CT", "Контртеррористы · КТ"))):
            on = team == key
            sm.Button(self, bx + i * 136, ty, 128, 34, 17, text=label, font=(FONT, 10, "bold"),
                      style=STYLE_ACTIVE if on else STYLE_GLASS, glow=on,
                      tags=("scroll",), cmd=lambda t=key: self.open_agents_list(t))
        items = [a for a in self.cat["categories"].get(AGENT_CAT, []) if a.get("team") == team]
        cw, ch, gap = 188, 120, 12          # shorter vertically than the old 178-px tiles
        cols = max(1, (W - 60 + gap) // (cw + gap))
        used = min(cols, len(items))
        x0 = (W - (used * cw + (used - 1) * gap)) // 2
        y0 = ty + 46
        f = (FONT, 9, "bold")
        for n, a in enumerate(items):
            row, col = divmod(n, cols)
            x, y = x0 + col * (cw + gap), y0 + row * (ch + gap)
            picked = self.sel.chosen(AGENT_CAT, a)
            b = sm.Button(self, x, y, cw, ch, 22, glow=picked,
                          style=STYLE_ACTIVE if picked else STYLE_GLASS, tags=("scroll",),
                          cmd=lambda a=a: self.choose_agent(a))
            pic = sm.Pic(self, x + cw / 2, y + 52, tags=b.tags)
            wait = sm.Label(self, x + cw / 2, y + 52, "…", (FONT, 10), MUTED, tags=b.tags)
            sm.Label(self, x + cw / 2, y + ch - 18, a["name"], f, FG, maxw=cw - 18, tags=b.tags)
            self.icons.get(a.get("icon"), (150, 80), lambda ph, pil, p=pic, w=wait: self._put(p, w, ph, pil))
        self.content_h = y0 + (-(-len(items) // cols)) * (ch + gap) + 30
        self._header(f"Агенты · {team}", back=lambda: self.home(-1), mask=True)

    def open_tab(self, name, direction=1):
        if name == AGENT_CAT:
            self.open_agents_list(self._agent_team, direction)
            return
        self.tab = name
        self.show(lambda: self._tab_build(name), direction)

    def _tab_build(self, name):
        W = self.W
        items = [(c, it) for c in TABS[name] for it in self.cat["categories"].get(c, [])
                 if it.get("skins") or c != KNIFE_CAT]
        cw, ch, gap = 300, 64, 16
        cols = max(1, min(3, (W - 80 + gap) // (cw + gap)))
        x0 = (W - (cols * cw + (cols - 1) * gap)) // 2
        y0 = max(HDR + 14, (self.H - (-(-len(items) // cols)) * (ch + gap)) // 2)
        f = (FONT, 12, "bold")
        for n, (cat, item) in enumerate(items):
            row, col = divmod(n, cols)
            chosen = self.sel.chosen(cat, item)
            sm.Button(self, x0 + col * (cw + gap), y0 + row * (ch + gap), cw, ch, 32,
                      text=sm.fit_text(f, item["name"], cw - 40), font=f, glow=bool(chosen),
                      style=STYLE_ACTIVE if chosen else STYLE_GLASS, tags=("scroll",),
                      cmd=lambda c=cat, i=item: self.skins_view(c, i))
        self.content_h = y0 + (-(-len(items) // cols)) * (ch + gap) + 30
        self._header(name, back=lambda: self.home(-1), mask=True)

    def skins_view(self, cat, item, direction=1):
        self.show(lambda: self._skins_build(cat, item), direction)

    def _skins_build(self, cat, item):
        W = self.W
        cur = self.sel.entry(cat, item)
        skins = item["skins"]
        cw, ch, gap = 216, 206, 18
        cols = max(1, (W - 60 + gap) // (cw + gap))
        used = min(cols, len(skins))
        x0 = (W - (used * cw + (used - 1) * gap)) // 2
        y0 = max(HDR + 16, (self.H - (-(-len(skins) // cols)) * (ch + gap)) // 2)
        f = (FONT, 10, "bold")
        for n, s in enumerate(skins):
            row, col = divmod(n, cols)
            x, y = x0 + col * (cw + gap), y0 + row * (ch + gap)
            picked = bool(cur and cur["paint_kit"] == s["paint"])
            b = sm.Button(self, x, y, cw, ch, 30, glow=picked, style=STYLE_ACTIVE if picked else STYLE_GLASS,
                          tags=("scroll",), cmd=lambda s=s: self.detail_view(cat, item, s))
            pic = sm.Pic(self, x + cw / 2, y + 16 + 62, tags=b.tags)
            wait = sm.Label(self, x + cw / 2, y + 16 + 62, "…", (FONT, 11), MUTED, tags=b.tags)
            sm.Label(self, x + cw / 2, y + ch - 36, s["name"], f, FG, maxw=cw - 32, tags=b.tags)
            self.icons.get(s.get("icon"), (cw - 32, 124),
                           lambda ph, pil, p=pic, w=wait: self._put(p, w, ph, pil))
        self.content_h = y0 + (-(-len(skins) // cols)) * (ch + gap) + 30
        self._header(item["name"], back=lambda: self.open_tab(self.tab, -1), mask=True)

    def _put(self, pic, wait, ph, pil=None):
        if not pic.alive:
            return
        if ph is None:
            wait.set("нет картинки")
        else:
            pic.set(pil, ph)
            wait.delete()

    def detail_view(self, cat, item, skin, direction=1):
        e = self.sel.entry(cat, item)
        mine = e if e and e["paint_kit"] == skin["paint"] else None
        state = {"wear": mine["wear"] if mine else 0.0001,
                 "st": bool(mine and mine["stattrak"] >= 0) and cat not in (GLOVE_CAT,)}
        self.show(lambda: self._detail_build(cat, item, skin, state), direction)

    def _detail_build(self, cat, item, skin, state):
        W, H, cv = self.W, self.H, self.cv
        oy = max(0, (H - 650) // 2 - 10)
        lx = max(10, (W - 780) // 2)
        rx = lx + 520

        # picture panel
        sm.Button(self, lx, 86 + oy, 480, 270, 34)
        pic = sm.Pic(self, lx + 240, 86 + oy + 135)
        wait = sm.Label(self, lx + 240, 86 + oy + 135, "…", (FONT, 12), MUTED)
        self.icons.get(skin.get("icon"), (432, 226), lambda ph, pil: self._put(pic, wait, ph, pil))

        # wear slider panel
        sy = 374 + oy
        sm.Button(self, lx, sy, 480, 60, 30)
        sm.Label(self, lx + 26, sy + 30, "Износ", (FONT, 11, "bold"), FG, anchor="w")
        val = sm.Label(self, lx + 480 - 24, sy + 30, f"{state['wear']:.4f}", (FONT, 11, "bold"), FG, anchor="e")

        def on_wear(v):
            state["wear"] = v
            val.set(f"{v:.4f}")
        slider = sm.Slider(self, lx + 104, sy + 30, 262, 0.0001, 1.0, 0.0001, state["wear"], on_wear)

        # wear presets + StatTrak
        py = 448 + oy
        pw, pg = 62, 10
        has_st = cat != GLOVE_CAT
        total = len(WEAR) * pw + (len(WEAR) - 1) * pg + ((104 + pg) if has_st else 0)
        px = lx + (480 - total) // 2
        for name, v in WEAR:
            sm.Button(self, px, py, pw, 42, 21, text=name, font=(FONT, 10, "bold"),
                      cmd=lambda v=v: slider.set(v))
            px += pw + pg
        if has_st:
            stb = sm.Button(self, px, py, 104, 42, 21, text="StatTrak", font=(FONT, 10, "bold"),
                            cmd=lambda: flip())

            def paint_st():
                on = state["st"]
                stb.update(style=STYLE_ACTIVE if on else STYLE_GLASS, fg=FG if on else MUTED)

            def flip():
                state["st"] = not state["st"]
                paint_st()
            paint_st()

        # main buttons
        by = 506 + oy
        sm.Button(self, lx, by, 232, 56, 28, text="Выбрать Скин", font=(FONT, 12, "bold"), style=STYLE_ACTIVE,
                  cmd=lambda: self.choose(cat, item, skin, state["wear"], state["st"]))
        sm.Button(self, lx + 248, by, 232, 56, 28, text="Отменить Скин", font=(FONT, 12, "bold"),
                  cmd=lambda: self.cancel(cat, item))
        if cat not in (GLOVE_CAT, KNIFE_CAT):      # gloves and knives have no sticker slots in CS:GO
            sm.Button(self, lx, by + 64, 480, 42, 21, text="Наклейки (6 слотов)", font=(FONT, 11, "bold"),
                      cmd=lambda: self._stickers_for(cat, item, skin, state))

        # engine panel
        ey = 86 + oy
        sm.Button(self, rx, ey, 260, 270, 34)
        self.dot_item = sm.Label(self, rx + 130, ey + 44, "", (FONT, 10, "bold"), MUTED)
        rb = sm.Button(self, rx + 24, ey + 78, 212, 52, 26, icon="play", isz=20, text="Запустить",
                       font=(FONT, 11, "bold"), cmd=self.toggle_run, style=STYLE_ACTIVE)
        self.view_run.append(rb)
        sm.Button(self, rx + 24, ey + 146, 212, 40, 20, text="mp_restartgame 1 → буфер", font=(FONT, 9),
                  cmd=self.copy_restart)
        sm.Label(self, rx + 130, ey + 224, "Перчатки появляются сразу\n(без респауна)", (FONT, 9), MUTED)
        self._header(f"{item['name']}  |  {skin['name']}", back=lambda: self.skins_view(cat, item, -1))

    # ------------------------------------------------------------------ F2: fps counter
    def _toggle_fps(self, _e=None):
        if self._fps_item is None:
            self._fps_item = -1
            self.engine.hooks.append(self._fps_step)
        else:
            self.engine.hooks.remove(self._fps_step)
            if self.cv.type(self._fps_item):
                self.cv.delete(self._fps_item)
            self._fps_item = None

    def _fps_step(self, _dt):
        now = time.perf_counter()
        if now - self._fps_t < 0.25 or self._fps_item is None:
            return
        self._fps_t = now
        if self._fps_item == -1 or not self.cv.type(self._fps_item):
            self._fps_item = self.cv.create_text(18, self.H - 16, anchor="sw", fill="#ffd34a",
                                                 font=(FONT, 10, "bold"), tags=("chrome",))
        self.cv.itemconfigure(self._fps_item, text=f"{self.engine.render_fps:.0f} кадров/с · {self.engine.fps:.0f} тик/с · F2 - скрыть")
        self.cv.tag_raise(self._fps_item)

    # ------------------------------------------------------------------ selection
    def _stickers_for(self, cat, item, skin, state):
        """Stickers belong to a chosen skin: apply the skin first if it is not selected yet."""
        if self.sel.entry(cat, item) is None:
            self.choose(cat, item, skin, state["wear"], state["st"])
        self.open_stickers(cat, item)

    def open_stickers(self, cat, item, slot=0):
        self._st_cat, self._st_item, self._st_slot = cat, item, int(slot)
        self._st_page = 0
        self.show(lambda: self._stickers_build(cat, item), 1)

    def _sticker_name(self, kit):
        if not kit:
            return "— пусто —"
        for k in self.cat.get("sticker_kits", []):
            if k["id"] == kit:
                return sm.fit_text((FONT, 9), k["name"], 150)
        return str(kit)

    def _stickers_build(self, cat, item):
        W = self.W
        kits = self.cat.get("sticker_kits", [])
        cur = (self.sel.entry(cat, item) or {}).get("stickers") or [0] * 5
        PER = 160
        pages = max(1, (-(-len(kits) // PER)))
        self._st_page = max(0, min(pages - 1, self._st_page))
        page = kits[self._st_page * PER:(self._st_page + 1) * PER]

        sw, sh, sg = 150, 36, 8
        cols = max(1, min(5, (W - 80 + sg) // (sw + sg)))
        x0 = (W - (cols * sw + (cols - 1) * sg)) // 2
        for i in range(5):
            col, row = i % 3, i // 3
            active = i == self._st_slot
            sm.Button(self, x0 + col * (sw + sg), 104 + row * (sh + sg), sw, sh, 18,
                      text=f"{i + 1}: {self._sticker_name(cur[i])}", font=(FONT, 9, "bold"),
                      style=STYLE_ACTIVE if active else STYLE_GLASS, glow=active,
                      cmd=lambda i=i: self.open_stickers(cat, item, i))

        by = 104 + 2 * (sh + sg) + 8
        sm.Button(self, x0, by, 150, 36, 18, text="Убрать наклейку", font=(FONT, 9, "bold"),
                  cmd=lambda: self._apply_sticker(cat, item, 0))
        sm.Button(self, x0 + sw + sg, by, 150, 36, 18, text="Назад", font=(FONT, 9, "bold"),
                  cmd=lambda: self.skins_view(cat, item, -1))
        sm.Button(self, x0 + 2 * (sw + sg), by, 150, 36, 18,
                  text=f"Страница {self._st_page + 1}/{pages}", font=(FONT, 9, "bold"),
                  cmd=lambda: self._sticker_page(cat, item, pages))

        cw, ch, gap = 210, 40, 8
        cols2 = max(1, (W - 60 + gap) // (cw + gap))
        used = min(cols2, len(page))
        gx = (W - (used * cw + (used - 1) * gap)) // 2
        gy = by + 48
        f = (FONT, 9, "bold")
        for n, k in enumerate(page):
            row, col = divmod(n, cols2)
            picked = cur[self._st_slot] == k["id"]
            sm.Button(self, gx + col * (cw + gap), gy + row * (ch + gap), cw, ch, 18,
                      text=sm.fit_text(f, k["name"], cw - 24), font=f,
                      style=STYLE_ACTIVE if picked else STYLE_GLASS, glow=picked,
                      tags=("scroll",), cmd=lambda kid=k["id"]: self._apply_sticker(cat, item, kid))
        self.content_h = gy + (-(-len(page) // cols2)) * (ch + gap) + 30
        self._header(f"Наклейки: {item['name']} — слот {self._st_slot + 1}",
                     back=lambda: self.skins_view(cat, item, -1), mask=True)

    def _sticker_page(self, cat, item, pages):
        self._st_page = (self._st_page + 1) % pages
        self.show(lambda: self._stickers_build(cat, item), 1)

    def _apply_sticker(self, cat, item, kit):
        self.sel.set_sticker(cat, item, self._st_slot, kit)
        self.autosave()
        try:
            self.after_change(f"наклейка {self._st_slot + 1}: {self._sticker_name(kit)}", True)
        except Exception as e:  # noqa: BLE001
            self.status(f"наклейка не применена: {e}")
        self.show(lambda: self._stickers_build(cat, item), -1)

    def choose_agent(self, item):
        # T and CT are two independent slots - picking a CT agent must not erase the T one.
        team = "CT" if str(item.get("team", "")).upper() == "CT" else "T"
        side = "КТ" if team == "CT" else "T"
        if self.sel.chosen(AGENT_CAT, item):
            self.sel.clear(AGENT_CAT, item)
            msg = f"агент {side} сброшен: {item['name']}"
        else:
            self.sel.set(AGENT_CAT, item, 0, 0.0001, 0)
            msg = f"агент {side} выбран: {item['name']}"
        other = self.sel.agents["CT" if team == "T" else "T"]
        if other:
            msg += f" | вторая команда: {other.get('name')}"
        msg += " (ещё раз по тому же — сбросить)"
        self.after_change(msg, True)
        # stay in the agent gallery so the portraits remain visible after a pick
        self.show(lambda t=team: self._agents_build(t), 1)

    def choose(self, cat, item, skin, wear, stat):
        self.sel.set(cat, item, skin["paint"], wear, 0, 0 if stat else None)
        self.after_change(f"выбрано: {item['name']} | {skin['name']}", cat != GLOVE_CAT)

    def cancel(self, cat, item):
        self.sel.clear(cat, item)
        self.after_change(f"сброшено: {item['name']}", True)

    def after_change(self, msg, full_update=True):
        self.autosave()
        self.sync_push()                          # every local change is published for the friend
        self.status(msg)
        if full_update:
            self.refresh_n += 1
        try:
            self.export_cfg(True)                 # inventory.txt обновляется при любом выборе
        except Exception as e:  # noqa: BLE001
            self.status(f"инвентарь не записан: {e}")

    # ------------------------------------------------------------------ engine (same flow as gui.py)
    def export_cfg(self, enabled):
        """Записать выбор в inventory.txt вместо конфига DLL.

        Раньше здесь писался csgo_skins.json с seq_map для подмены netvars.
        Теперь конфиг игры не трогается вовсе: GC сам отдаёт инвентарь.
        """
        if not enabled:
            return  # «выключить» — это возврат оригинального csgo.exe
        raw = self.sel.raw(self.account or 0, self.cat["knife_ids"])
        core.normalize_config(raw)
        gc_bridge.write_inventory(raw, self.cat)

    def _seq_ready(self, msg):
        self.status(msg)
        if self.engine_on:
            try:
                self.export_cfg(True)             # same refresh number: no extra full update
            except Exception as e:  # noqa: BLE001
                self.status(f"конфиг не применён: {e}")

    def refresh_run_ui(self):
        on = self.engine_on
        style = STYLE_GREEN if on else STYLE_GLASS
        if self.chip is not None and self.chip.alive:
            self.chip.update(icon="stop" if on else "play", style=style)
        for b in list(self.view_run):
            if b.alive:
                b.update(text="Остановить" if on else "Запустить", icon="stop" if on else "play",
                         style=STYLE_GREEN if on else STYLE_ACTIVE)
            else:
                self.view_run.remove(b)
        if self.dot_item is not None and self.dot_item.alive:
            self.dot_item.set("● движок включён" if on else "● движок выключен", OKC if on else MUTED)

    def copy_restart(self):
        self.clipboard_clear()
        self.clipboard_append("mp_restartgame 1")
        self.status("скопировано: вставь в консоль игры (только офлайн/боты)")

    def toggle_run(self):
        """Запуск/остановка csgo_gc. Кнопка «Запустить» больше не инжектит DLL."""
        if self.engine_on:
            self.engine_on = False
            try:
                gc_bridge.restore()
            except Exception as e:  # noqa: BLE001
                messagebox.showerror("GC", str(e))
                return
            self.refresh_run_ui()
            self.status("GC выключен: восстановлен оригинальный csgo.exe")
            return
        try:
            self.export_cfg(True)
            gc_bridge.launch()
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("GC", str(e))
            return
        self.engine_on = True
        self.refresh_run_ui()
        self.status("csgo_gc запущен • инвентарь записан в inventory.txt")


def main():
    hide_console()
    App().mainloop()


if __name__ == "__main__":
    main()
