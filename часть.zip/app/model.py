"""Selection state of the GUI, kept free of tkinter so it can be tested."""

KNIFE_CAT = "Ножи"
GLOVE_CAT = "Перчатки"
AGENT_CAT = "Агенты"


def _stickers(v):
    out = [0] * 5
    if isinstance(v, (list, tuple)):
        for i, x in enumerate(v[:5]):
            try:
                out[i] = max(0, min(100000, int(x)))
            except (TypeError, ValueError):
                pass
    return out


class Selection:
    def __init__(self):
        self.skins = {}      # str(defidx) -> entry
        self.knife = None
        self.gloves = None
        self.agents = {"T": None, "CT": None}   # one agent per team: {"defidx", "model", "name", "team"}

    @staticmethod
    def _team(item):
        return "CT" if str((item or {}).get("team", "")).upper() == "CT" else "T"

    @staticmethod
    def make_entry(paint, wear, seed, stat, stickers=None):
        e = {"paint_kit": int(paint), "wear": round(float(wear), 4), "seed": int(seed),
             "stattrak": int(stat) if stat is not None and int(stat) >= 0 else -1}
        e["stickers"] = _stickers(stickers)
        return e

    def set(self, cat, item, paint, wear, seed, stat=None, stickers=None):
        e = self.make_entry(paint, wear, seed, stat, stickers)
        if cat == KNIFE_CAT:
            old = self.knife or {}
            if stickers is None:
                e["stickers"] = _stickers(old.get("stickers"))
            self.knife = {**e, "defidx": item["defidx"], "model": item.get("model")}
        elif cat == GLOVE_CAT:
            e["stattrak"] = -1
            self.gloves = {**e, "defidx": item["defidx"], "model": item.get("model")}
        elif cat == AGENT_CAT:
            team = self._team(item)
            self.agents[team] = {"defidx": int(item["defidx"]), "model": item.get("model"),
                                 "name": item.get("name"), "team": team}
        else:
            key = str(item["defidx"])
            if stickers is None and key in self.skins:
                e["stickers"] = _stickers(self.skins[key].get("stickers"))
            self.skins[key] = e

    def set_sticker(self, cat, item, slot, kit):
        """slot 0..5, kit 0 removes the sticker."""
        if not 0 <= int(slot) < 5:
            return
        e = self.entry(cat, item)
        if e is None:
            return
        st = _stickers(e.get("stickers"))
        st[int(slot)] = max(0, min(100000, int(kit)))
        e["stickers"] = st

    def clear(self, cat, item):
        if cat == KNIFE_CAT:
            self.knife = None
        elif cat == GLOVE_CAT:
            self.gloves = None
        elif cat == AGENT_CAT:
            self.agents[self._team(item)] = None
        else:
            self.skins.pop(str(item["defidx"]), None)

    def entry(self, cat, item):
        if cat == KNIFE_CAT:
            k = self.knife
            return k if k and k["defidx"] == item["defidx"] else None
        if cat == GLOVE_CAT:
            g = self.gloves
            return g if g and g["defidx"] == item["defidx"] else None
        if cat == AGENT_CAT:
            a = self.agents.get(self._team(item))
            return a if a and a["defidx"] == int(item["defidx"]) else None
        return self.skins.get(str(item["defidx"]))

    def chosen(self, cat, item):
        return self.entry(cat, item) is not None

    def raw(self, account_id, knife_ids):
        return {"account_id": int(account_id), "expected_client_sha256": "",
                "knife_ids": list(knife_ids), "skins": dict(self.skins),
                "knife": self.knife, "gloves": self.gloves, "agents": dict(self.agents),
                 "agent": self.agents.get("CT") or self.agents.get("T")}

    def load(self, raw):
        self.skins = {str(k): v for k, v in raw.get("skins", {}).items()}
        for e in self.skins.values():
            if isinstance(e, dict):
                e["stickers"] = _stickers(e.get("stickers"))
        for key in ("knife", "gloves"):
            e = raw.get(key)
            if isinstance(e, dict):
                e["stickers"] = _stickers(e.get("stickers"))
        self.knife = raw.get("knife") or None
        self.gloves = raw.get("gloves") or None
        self.agents = {"T": None, "CT": None}
        ag = raw.get("agents")
        if isinstance(ag, dict):
            for team in ("T", "CT"):
                e = ag.get(team)
                if isinstance(e, dict):
                    self.agents[team] = e
        else:
            e = raw.get("agent")
            if isinstance(e, dict):
                self.agents[self._team(e)] = e

    def counts(self):
        return len(self.skins), bool(self.knife), bool(self.gloves)
