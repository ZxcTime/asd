"""
Steam helpers (Windows registry). Everything returns None when not available, so
the GUI works the same on any machine and just asks the user instead.

  HKCU\\Software\\Valve\\Steam                 SteamPath    -> Steam install dir
  HKCU\\Software\\Valve\\Steam\\ActiveProcess  ActiveUser   -> 32-bit account id of the
                                                             logged-in user (0 if Steam is closed)
"""
from pathlib import Path

from build_catalog import CatalogError, decode, parse_kv

# Папка legacy-клиента первой, старое имя оставлено как запасной вариант.
GAME_DIRS = [Path("steamapps") / "common" / "csgo legacy",
             Path("steamapps") / "common" / "Counter-Strike Global Offensive"]


def resolve_csgo_dir(picked):
    """Accepts either '.../csgo legacy' or '.../csgo legacy/csgo' -> path of the 'csgo' folder."""
    p = Path(picked)
    if (p / "csgo").is_dir() and not (p / "scripts").is_dir():
        return p / "csgo"
    return p


def _winreg():
    try:
        import winreg
        return winreg
    except ImportError:
        return None


def _query(subkey, name):
    wr = _winreg()
    if wr is None:
        return None
    try:
        with wr.OpenKey(wr.HKEY_CURRENT_USER, subkey) as k:
            return wr.QueryValueEx(k, name)[0]
    except OSError:
        return None


def steam_path():
    v = _query(r"Software\Valve\Steam", "SteamPath")
    return Path(v) if v else None


def active_account_id():
    v = _query(r"Software\Valve\Steam\ActiveProcess", "ActiveUser")
    return int(v) if isinstance(v, int) and v > 0 else None


def library_dirs(steam):
    libs = [steam]
    vdf = steam / "steamapps" / "libraryfolders.vdf"
    try:
        kv = parse_kv(decode(vdf.read_bytes())).get("libraryfolders", {})
    except OSError:
        return libs
    for v in kv.values():
        p = v.get("path") if isinstance(v, dict) else v  # new format: dict, old: plain string
        if isinstance(p, str) and p:
            libs.append(Path(p))
    return libs


def find_csgo_dir():
    """-> (path to the 'csgo' folder, is_legacy_client) or (None, False).
    is_legacy_client means csgo.exe exists, which this tool needs."""
    steam = steam_path()
    if steam is None:
        return None, False
    first = None
    for lib in library_dirs(steam):
        for game_dir in GAME_DIRS:
            root = lib / game_dir
            cand = root / "csgo"
            if cand.is_dir():
                if (root / "csgo.exe").exists():
                    return cand, True
                first = first or cand
    return first, False
