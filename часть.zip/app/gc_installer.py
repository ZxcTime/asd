"""Установка / удаление csgo_gc в CS:GO Legacy.
ВНИМАНИЕ: заменяет csgo.exe! Всегда делает бэкап.

Использование:
    python gc_installer.py install
    python gc_installer.py uninstall
    python gc_installer.py status
"""
import os
import shutil
import sys
import hashlib

GAME = r"C:\Program Files (x86)\Steam\steamapps\common\csgo legacy"
GC_EXE = r"C:\Users\User\Desktop\Los_Santos_GC\csgo_gc_release\csgo.exe"
GC_DIR = r"C:\Users\User\Desktop\Los_Santos_GC\csgo_gc_release\csgo_gc"
BACKUP = r"C:\Users\User\Desktop\Los_Santos_GC\backup"


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def game_csgo():
    return os.path.join(GAME, "csgo.exe")


def game_gc_dir():
    return os.path.join(GAME, "csgo", "csgo_gc")


def game_steam_inf():
    return os.path.join(GAME, "csgo", "steam.inf")


def ensure_backup():
    os.makedirs(BACKUP, exist_ok=True)
    exe = game_csgo()
    bpath = os.path.join(BACKUP, "csgo.exe.original")
    if os.path.exists(exe) and not os.path.exists(bpath):
        shutil.copy2(exe, bpath)
        print(f"[backup] csgo.exe -> {bpath}")
    # csgo_gc меняет appid в steam.inf — сохраняем оригинал для отката
    inf = game_steam_inf()
    ibpath = os.path.join(BACKUP, "steam.inf.original")
    if os.path.exists(inf) and not os.path.exists(ibpath):
        shutil.copy2(inf, ibpath)
        print(f"[backup] steam.inf -> {ibpath}")
    return bpath


def cmd_install():
    ensure_backup()
    # 1. заменить csgo.exe
    shutil.copy2(GC_EXE, game_csgo())
    print(f"[install] csgo.exe replaced (gc sha={sha(GC_EXE)[:16]})")
    # 2. скопировать папку csgo_gc (config, inventory, price_sheet)
    dst = game_gc_dir()
    if os.path.exists(dst):
        shutil.rmtree(dst)
    shutil.copytree(GC_DIR, dst)
    print(f"[install] csgo_gc/ copied -> {dst}")
    print("[install] DONE. Запусти CS:GO через Steam.")
    print("[install] Если появится окно VAC - запусти с -steam")


def cmd_uninstall():
    bpath = os.path.join(BACKUP, "csgo.exe.original")
    if os.path.exists(bpath):
        shutil.copy2(bpath, game_csgo())
        print("[uninstall] original csgo.exe restored")
    else:
        print("[uninstall] WARNING: backup not found!")
    ibpath = os.path.join(BACKUP, "steam.inf.original")
    if os.path.exists(ibpath):
        shutil.copy2(ibpath, game_steam_inf())
        print("[uninstall] original steam.inf restored")
    dst = game_gc_dir()
    if os.path.exists(dst):
        shutil.rmtree(dst)
        print("[uninstall] csgo_gc/ removed")
    print("[uninstall] DONE")


def cmd_status():
    exe = game_csgo()
    print(f"game: {GAME}")
    print(f"csgo.exe: {os.path.getsize(exe)} bytes sha={sha(exe)[:16]}")
    print(f"gc exe sha: {sha(GC_EXE)[:16]}")
    print(f"installed: {'YES' if sha(exe) == sha(GC_EXE) else 'NO'}")
    print(f"backup: {os.path.exists(os.path.join(BACKUP, 'csgo.exe.original'))}")
    print(f"gc dir in game: {os.path.exists(game_gc_dir())}")
    inv = os.path.join(game_gc_dir(), "inventory.txt")
    if os.path.exists(inv):
        print(f"inventory.txt: {os.path.getsize(inv)} bytes")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    {"install": cmd_install, "uninstall": cmd_uninstall, "status": cmd_status}.get(cmd, cmd_status)()
